export type CampaignCategory = 
  | "SMA" 
  | "Cancer" 
  | "Cardiac" 
  | "Transplant" 
  | "Rare Disease" 
  | "Pediatric" 
  | "Emergency";

export type VerificationStatus = 
  | "pending_verification"
  | "field_agent_assigned"
  | "verified_active"
  | "treatment_ongoing"
  | "completed"
  | "rejected";

export interface TreatmentItem {
  id: string;
  name: string;
  cost: number;
  category: "Surgery" | "ICU Stay" | "Medication/Gene Therapy" | "Diagnostics" | "Post-Op Rehab";
}

export interface DocumentProof {
  id: string;
  title: string;
  type: "Aadhaar" | "Medical Certificate" | "Hospital Estimate" | "Doctor Prescription" | "Diagnosis Report";
  url: string;
  uploadDate: string;
  verified: boolean;
  notes?: string;
  fileName?: string;
  fileSize?: string;
  fileDataUrl?: string;
}

export interface VerificationReport {
  agentId: string;
  agentName: string;
  agentPhone: string;
  visitTimestamp: string;
  gpsLocation: {
    lat: number;
    lng: number;
    addressName: string;
  };
  hospitalAdmissionNo: string;
  homeVisitCompleted: boolean;
  hospitalBedVerified: boolean;
  doctorConfirmed: boolean;
  doctorRegNo: string;
  auditScore: number; // 0 - 100
  reportSummary: string;
  photos: string[];
}

export interface CampaignUpdate {
  id: string;
  date: string;
  title: string;
  content: string;
  imageUrl?: string;
  author: string;
  role: "Hospital" | "Family" | "Field Agent";
}

export interface PatientPaymentDetails {
  upiId?: string;
  accountNumber?: string;
  ifscCode?: string;
  bankName?: string;
  accountHolderName?: string;
  qrCodeUrl?: string;
  extraNotes?: string;
}

export interface DonorEntry {
  id: string;
  name: string;
  amount: number;
  type: "ad" | "direct";
  timestamp: string;
  message?: string;
  anonymous?: boolean;
  adsWatchedCount?: number;
  transactionId?: string;
  paymentProofUrl?: string;
  paymentMode?: string;
}

export interface PatientCampaign {
  id: string;
  patientName: string;
  patientAge: number;
  gender: "Male" | "Female" | "Other";
  guardianName: string;
  contactPhone: string;
  diagnosis: string;
  category: CampaignCategory;
  hospitalName: string;
  hospitalCity: string;
  doctorName: string;
  doctorRegNo: string;
  requiredAmount: number;
  collectedAmount: number;
  adRevenueAmount: number;
  directDonationAmount: number;
  adWatchCount: number;
  shareCount: number;
  verifiedBadge: boolean;
  status: VerificationStatus;
  emergencyPriority: boolean;
  story: string;
  patientPhoto: string;
  coverPhoto: string;
  treatmentBreakdown: TreatmentItem[];
  verificationReport?: VerificationReport;
  documents: DocumentProof[];
  updates: CampaignUpdate[];
  donorList: DonorEntry[];
  paymentDetails?: PatientPaymentDetails;
  createdAt: string;
}

export interface TransparencyLedgerEntry {
  id: string;
  timestamp: string;
  patientId: string;
  patientName: string;
  type: "AD_REVENUE" | "DIRECT_DONATION" | "HOSPITAL_DISBURSAL";
  grossAmount: number;
  patientFund95: number;
  ops3: number;
  admin2: number;
  transactionHash: string;
  sponsorName?: string;
  paymentMode?: string;
}

export interface UserSupportProfile {
  name: string;
  adsWatched: number;
  adRevenueGenerated: number;
  directDonationsGiven: number;
  campaignsShared: number;
  impactPoints: number;
  badges: string[];
}

export type UserRole = "supporter" | "patient" | "hospital" | "ngo" | "field_agent" | "super_admin";

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  mobile: string;
  passwordHash?: string;
  role: UserRole;
  aadhaar?: string;
  hospitalRegNo?: string;
  ngoRegNo?: string;
  createdAt: string;
  lastLogin: string;
  twoFactorEnabled?: boolean;
  deviceVerified?: boolean;
  avatarUrl?: string;
  isVerified?: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  ipAddress: string;
  deviceInfo: string;
  status: "SUCCESS" | "FAILED" | "BLOCKED";
}

export interface AdSponsor {
  id: string;
  brandName: string;
  logoUrl: string;
  campaignTitle: string;
  videoDurationSeconds: number;
  payoutPerView: number;
  bannerText: string;
  callToAction: string;
  category: string;
  videoUrl?: string;
  imageUrl?: string;
  audioUrl?: string;
  externalLink?: string;
  adType?: "video" | "image" | "audio" | "link" | "hybrid";
}
