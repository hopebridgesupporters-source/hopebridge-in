import React, { useState, useEffect } from "react";
import { HopeBridgeLogo } from "./components/HopeBridgeLogo";
import { PatientCampaign, TransparencyLedgerEntry, UserSupportProfile, VerificationReport, CampaignUpdate } from "./types";
import { initialCampaigns, initialLedger, initialUserProfile } from "./data/mockData";
import { Header } from "./components/Header";
import { SupporterHub } from "./components/SupporterHub";
import { RewardedAdModal } from "./components/RewardedAdModal";
import { DirectDonateModal } from "./components/DirectDonateModal";
import { PatientRegistrationModal } from "./components/PatientRegistrationModal";
import { FieldAgentPortal } from "./components/FieldAgentPortal";
import { HospitalPortal } from "./components/HospitalPortal";
import { AdminFraudGuard } from "./components/AdminFraudGuard";
import { PublicLedger } from "./components/PublicLedger";
import { AiMedicalAssistant } from "./components/AiMedicalAssistant";
import { CampaignDetailModal } from "./components/CampaignDetailModal";
import { ReceiptModal } from "./components/ReceiptModal";
import { AboutModal } from "./components/AboutModal";
import { ContactSection } from "./components/ContactSection";
import { LoginPage } from "./components/LoginPage";
import { SuperAdminModal } from "./components/SuperAdminModal";
import { WelcomePage } from "./components/WelcomePage";
import { authService } from "./services/authService";
import { UserAccount } from "./types";
import { Share2, Check, Heart, ShieldCheck, Lock, Sparkles, Info, Mail } from "lucide-react";

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>("supporter");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Global App State with LocalStorage Persistence
  const [campaigns, setCampaigns] = useState<PatientCampaign[]>(() => {
    try {
      const saved = localStorage.getItem("hopebridge_campaigns");
      return saved ? JSON.parse(saved) : initialCampaigns;
    } catch {
      return initialCampaigns;
    }
  });

  const [ledger, setLedger] = useState<TransparencyLedgerEntry[]>(() => {
    try {
      const saved = localStorage.getItem("hopebridge_ledger");
      return saved ? JSON.parse(saved) : initialLedger;
    } catch {
      return initialLedger;
    }
  });

  const [userProfile, setUserProfile] = useState<UserSupportProfile>(initialUserProfile);

  useEffect(() => {
    try {
      localStorage.setItem("hopebridge_campaigns", JSON.stringify(campaigns));
    } catch (e) {
      console.warn("Storage warning:", e);
    }
  }, [campaigns]);

  useEffect(() => {
    try {
      localStorage.setItem("hopebridge_ledger", JSON.stringify(ledger));
    } catch (e) {
      console.warn("Storage warning:", e);
    }
  }, [ledger]);

  // Auth & Welcome State
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => authService.getCurrentSession());
  const [isWelcomeOpen, setIsWelcomeOpen] = useState<boolean>(true);
  const [isLoginOpen, setIsLoginOpen] = useState<boolean>(false);
  const [isSuperAdminOpen, setIsSuperAdminOpen] = useState<boolean>(false);

  // Active Modal States
  const [activeAdCampaign, setActiveAdCampaign] = useState<PatientCampaign | null>(null);
  const [activeDonateCampaign, setActiveDonateCampaign] = useState<PatientCampaign | null>(null);
  const [activeDetailCampaign, setActiveDetailCampaign] = useState<PatientCampaign | null>(null);
  const [activeReceipt, setActiveReceipt] = useState<any | null>(null);
  const [isAboutOpen, setIsAboutOpen] = useState<boolean>(false);
  const [aboutDefaultTab, setAboutDefaultTab] = useState<"about" | "terms" | "privacy">("about");
  const [shareToast, setShareToast] = useState<string | null>(null);

  const handleOpenAboutTab = (tab: "about" | "terms" | "privacy") => {
    setAboutDefaultTab(tab);
    setIsAboutOpen(true);
  };

  // Automatic role redirection upon successful sign in
  const handleSuccessLogin = (user: UserAccount) => {
    setCurrentUser(user);
    
    // Redirect based on user's role
    switch (user.role) {
      case "patient":
        setCurrentTab("register");
        break;
      case "hospital":
      case "ngo":
        setCurrentTab("hospital");
        break;
      case "field_agent":
        setCurrentTab("agent");
        break;
      case "super_admin":
        setCurrentTab("admin");
        setIsSuperAdminOpen(true);
        break;
      case "supporter":
      default:
        setCurrentTab("supporter");
        break;
    }
  };

  const handleTabChange = (tab: string) => {
    // Security check for restricted operational tabs when user is unauthenticated
    if (["register", "agent", "hospital", "admin"].includes(tab) && !currentUser) {
      setIsLoginOpen(true);
      return;
    }
    setCurrentTab(tab);
  };

  const handleLogout = () => {
    authService.logout();
    setCurrentUser(null);
  };

  // Compute total aggregates
  const totalAdRevenue = campaigns.reduce((acc, c) => acc + c.adRevenueAmount, 0);
  const totalDirectDonations = campaigns.reduce((acc, c) => acc + c.directDonationAmount, 0);
  const totalAdsWatched = campaigns.reduce((acc, c) => acc + c.adWatchCount, 0);
  const verifiedCount = campaigns.filter((c) => c.verifiedBadge).length;

  // Handlers
  const handleWatchAd = (campaign: PatientCampaign) => {
    setActiveAdCampaign(campaign);
  };

  const handleDonate = (campaign: PatientCampaign) => {
    setActiveDonateCampaign(campaign);
  };

  const handleShare = (campaign: PatientCampaign) => {
    const text = `Support ${campaign.patientName} (${campaign.diagnosis}) simply by watching 15-second ads! 95% of ad funds go directly to ${campaign.hospitalName} account on HopeBridge.`;
    navigator.clipboard?.writeText?.(text);
    setShareToast(`Campaign share link copied! +₹10 matching grant added from HopeBridge Sponsor Pool.`);

    // Increment campaign share count
    setCampaigns((prev) =>
      prev.map((c) => (c.id === campaign.id ? { ...c, shareCount: c.shareCount + 1 } : c))
    );

    setTimeout(() => setShareToast(null), 4000);
  };

  const handleAdCompleted = (campaignId: string, payout: number, sponsorName: string) => {
    const patient95 = Number((payout * 0.95).toFixed(2));
    const ops3 = Number((payout * 0.03).toFixed(2));
    const admin2 = Number((payout * 0.02).toFixed(2));

    const targetCamp = campaigns.find((c) => c.id === campaignId);
    const patientName = targetCamp ? targetCamp.patientName : "Patient";

    // 1. Update Campaign Stats
    setCampaigns((prev) =>
      prev.map((c) => {
        if (c.id === campaignId) {
          return {
            ...c,
            collectedAmount: c.collectedAmount + payout,
            adRevenueAmount: c.adRevenueAmount + payout,
            adWatchCount: c.adWatchCount + 1,
            donorList: [
              {
                id: `d-${Date.now()}`,
                name: "Ad Supporter",
                amount: payout,
                type: "ad",
                timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                adsWatchedCount: 1,
              },
              ...(c.donorList || []),
            ],
          };
        }
        return c;
      })
    );

    // 2. Add Entry to Ledger
    const newLedgerEntry: TransparencyLedgerEntry = {
      id: `tx-${Date.now()}`,
      timestamp: new Date().toLocaleString(),
      patientId: campaignId,
      patientName,
      type: "AD_REVENUE",
      grossAmount: payout,
      patientFund95: patient95,
      ops3: ops3,
      admin2: admin2,
      transactionHash: `0x${Math.random().toString(16).substring(2, 10)}...ad`,
      sponsorName,
      paymentMode: "Rewarded Ad Settlement",
    };

    setLedger((prev) => [newLedgerEntry, ...prev]);

    // 3. Update User Profile
    setUserProfile((prev) => ({
      ...prev,
      adsWatched: prev.adsWatched + 1,
      adRevenueGenerated: prev.adRevenueGenerated + payout,
      impactPoints: prev.impactPoints + 15,
    }));
  };

  const handleDonationCompleted = (
    campaignId: string,
    amount: number,
    donorName: string,
    message: string,
    tax80G: boolean,
    panNumber: string,
    utrNumber?: string,
    paymentProofUrl?: string,
    paymentMode?: string
  ) => {
    const patient95 = Number((amount * 0.95).toFixed(2));
    const ops3 = Number((amount * 0.03).toFixed(2));
    const admin2 = Number((amount * 0.02).toFixed(2));

    const targetCamp = campaigns.find((c) => c.id === campaignId);
    const patientName = targetCamp ? targetCamp.patientName : "Patient";
    const hospitalName = targetCamp ? targetCamp.hospitalName : "Fortis Hospital";

    // 1. Update Campaign Stats & Donor List
    setCampaigns((prev) =>
      prev.map((c) => {
        if (c.id === campaignId) {
          const updatedCollected = c.collectedAmount + amount;
          const updatedDirect = c.directDonationAmount + amount;
          return {
            ...c,
            collectedAmount: updatedCollected,
            directDonationAmount: updatedDirect,
            donorList: [
              {
                id: `d-${Date.now()}`,
                name: donorName,
                amount,
                type: "direct",
                timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                message,
                transactionId: utrNumber || `UTR-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
                paymentProofUrl,
                paymentMode: paymentMode || "UPI Direct Escrow",
              },
              ...(c.donorList || []),
            ],
          };
        }
        return c;
      })
    );

    // 2. Ledger Entry for Public Transparency
    const newLedgerEntry: TransparencyLedgerEntry = {
      id: `tx-${Date.now()}`,
      timestamp: new Date().toLocaleString(),
      patientId: campaignId,
      patientName,
      type: "DIRECT_DONATION",
      grossAmount: amount,
      patientFund95: patient95,
      ops3: ops3,
      admin2: admin2,
      transactionHash: utrNumber || `UTR-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      sponsorName: donorName,
      paymentMode: paymentMode ? `${paymentMode} (Direct Bank/QR Escrow)` : "UPI Direct Escrow",
    };

    setLedger((prev) => [newLedgerEntry, ...prev]);

    // 3. User Profile Update
    setUserProfile((prev) => ({
      ...prev,
      directDonationsGiven: prev.directDonationsGiven + amount,
      impactPoints: prev.impactPoints + Math.round(amount / 10),
    }));

    // 4. Close Donate Modal & Show Receipt
    setActiveDonateCampaign(null);

    if (tax80G) {
      setActiveReceipt({
        receiptNo: `HB-80G-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        donorName,
        amount,
        patientName,
        hospitalName,
        panNumber: panNumber || "ABCDE1234F",
        date: new Date().toLocaleDateString(),
      });
    }

    setShareToast(`Thank you ${donorName}! Your ₹${amount.toLocaleString("en-IN")} donation was added to ${patientName}'s fund!`);
    setTimeout(() => setShareToast(null), 5000);
  };

  const handleGrantVerifiedBadge = (campaignId: string, report: VerificationReport) => {
    setCampaigns((prev) =>
      prev.map((c) => {
        if (c.id === campaignId) {
          return {
            ...c,
            verifiedBadge: true,
            status: "verified_active",
            verificationReport: report,
          };
        }
        return c;
      })
    );
  };

  const handleCampaignCreated = (newCampaign: PatientCampaign) => {
    setCampaigns((prev) => [newCampaign, ...prev]);
    setCurrentTab("supporter");
    setShareToast(`New campaign for ${newCampaign.patientName} created in Pending Verification status! Assigned to Field Agent.`);
    setTimeout(() => setShareToast(null), 5000);
  };

  const handleAddUpdate = (campaignId: string, update: CampaignUpdate) => {
    setCampaigns((prev) =>
      prev.map((c) => {
        if (c.id === campaignId) {
          return {
            ...c,
            updates: [update, ...(c.updates || [])],
          };
        }
        return c;
      })
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col antialiased selection:bg-blue-600 selection:text-white">
      {/* Toast Notification */}
      {shareToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white border border-emerald-500/50 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom duration-300">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Check className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold">{shareToast}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={handleTabChange}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        totalAdRevenue={totalAdRevenue}
        totalDirectDonations={totalDirectDonations}
        totalAdsWatched={totalAdsWatched}
        verifiedCount={verifiedCount}
        userImpactPoints={userProfile.impactPoints}
        onOpenAbout={() => setIsAboutOpen(true)}
        currentUser={currentUser}
        onOpenLogin={() => setIsLoginOpen(true)}
        onLogout={handleLogout}
        onOpenSuperAdmin={() => setIsSuperAdminOpen(true)}
        onOpenWelcome={() => setIsWelcomeOpen(true)}
      />

      {/* Main Content Router */}
      <main className="flex-1 pb-24 bg-slate-50">
        {currentTab === "supporter" && (
          <SupporterHub
            campaigns={campaigns}
            onWatchAd={handleWatchAd}
            onDonate={handleDonate}
            onShare={handleShare}
            onViewDetails={(c) => setActiveDetailCampaign(c)}
            searchQuery={searchQuery}
          />
        )}

        {currentTab === "register" && (
          <PatientRegistrationModal
            onCampaignCreated={handleCampaignCreated}
            onClose={() => setCurrentTab("supporter")}
          />
        )}

        {currentTab === "agent" && (
          <FieldAgentPortal
            campaigns={campaigns}
            onGrantVerifiedBadge={handleGrantVerifiedBadge}
          />
        )}

        {currentTab === "hospital" && (
          <HospitalPortal
            campaigns={campaigns}
            onAddUpdate={handleAddUpdate}
          />
        )}

        {currentTab === "admin" && (
          <AdminFraudGuard
            campaigns={campaigns}
            totalAdRevenue={totalAdRevenue}
            totalDirectDonations={totalDirectDonations}
            totalAdsWatched={totalAdsWatched}
          />
        )}

        {currentTab === "ledger" && <PublicLedger ledger={ledger} />}

        {currentTab === "ai_guidance" && <AiMedicalAssistant />}
      </main>

      {/* Circled Verification Information Bar at Bottom of Page */}
      <div className="bg-emerald-50 py-3 px-4 text-xs text-emerald-950 border-0">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 font-medium">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white uppercase tracking-wider shrink-0 border-0">
              100% VERIFIED
            </span>
            <span className="text-slate-800 font-semibold">
              India's Most Trusted Medical Platform: Every patient verified on-site by field agents & hospital doctors.
            </span>
          </div>
          <div className="flex items-center gap-4 text-emerald-900 font-bold">
            <span className="flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-emerald-600" /> 95% Direct Patient Fund
            </span>
            <span className="text-emerald-300">•</span>
            <span className="flex items-center gap-1 text-amber-800">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Impact: {userProfile.impactPoints} Points
            </span>
          </div>
        </div>
      </div>

      {/* Classy Borderless About HopeBridge Feature Banner at Bottom of Page */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 my-8">
        <div 
          onClick={() => setIsAboutOpen(true)}
          className="bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl cursor-pointer hover:scale-[1.005] transition-all border-0 relative overflow-hidden group"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 relative z-10">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold border-0">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>About HopeBridge Platform</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                India's Verified Medical Assistance Ecosystem
              </h3>
              <p className="text-xs sm:text-sm text-teal-100/90 leading-relaxed">
                HopeBridge connects supporters, patients, field agents, and hospital escrow accounts into a transparent healthcare ecosystem. Every rupee generated via rewarded ads goes directly towards settling hospital bills with zero leakages.
              </p>
            </div>

            <div className="shrink-0">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsAboutOpen(true);
                }}
                className="px-5 py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-xs sm:text-sm rounded-2xl shadow-lg transition-all border-0 flex items-center gap-2 cursor-pointer"
              >
                <Info className="w-4 h-4 text-slate-950" />
                <span>About HopeBridge</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Global Contact Us Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 my-8" id="contact-us">
        <ContactSection variant="full" />
      </div>

      {/* Footer */}
      <footer className="bg-white text-slate-800 py-8 px-4 text-xs border-0">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-6 text-slate-600">
          <div className="space-y-2">
            <HopeBridgeLogo 
              size="sm" 
              layout="horizontal" 
              onClick={() => setCurrentTab("supporter")} 
            />
            <p className="text-[11px] text-slate-500 max-w-md">
              India's Verified Medical Assistance Ecosystem through Rewarded Ads, Voluntary Donations & Field Verification.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-[11px] font-medium">
            <button
              onClick={() => handleOpenAboutTab("about")}
              className="text-teal-800 font-bold hover:bg-teal-100 transition-colors flex items-center gap-1.5 bg-teal-50 px-3.5 py-2 rounded-xl border-0 cursor-pointer shadow-2xs"
            >
              <Info className="w-3.5 h-3.5 text-teal-600" />
              <span>About HopeBridge</span>
            </button>

            <button
              onClick={() => handleOpenAboutTab("terms")}
              className="text-slate-700 font-bold hover:bg-slate-100 transition-colors flex items-center gap-1.5 bg-slate-100 px-3.5 py-2 rounded-xl border-0 cursor-pointer shadow-2xs"
            >
              <span>Terms & Conditions</span>
            </button>

            <button
              onClick={() => handleOpenAboutTab("privacy")}
              className="text-slate-700 font-bold hover:bg-slate-100 transition-colors flex items-center gap-1.5 bg-slate-100 px-3.5 py-2 rounded-xl border-0 cursor-pointer shadow-2xs"
            >
              <span>Privacy Policy</span>
            </button>

            <a
              href="mailto:hopebridgesupporters@gmail.com"
              className="text-teal-800 font-bold hover:bg-teal-100 transition-colors flex items-center gap-1.5 bg-teal-50 px-3.5 py-2 rounded-xl border-0 cursor-pointer shadow-2xs"
            >
              <Mail className="w-3.5 h-3.5 text-teal-600" />
              <span>Contact Us</span>
            </a>

            <span className="text-slate-300">•</span>
            <span className="text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-xl border-0">
              <ShieldCheck className="w-4 h-4 text-emerald-600" /> 100% Escrow Protected
            </span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        defaultTab={aboutDefaultTab}
      />

      <RewardedAdModal
        campaign={activeAdCampaign}
        onClose={() => setActiveAdCampaign(null)}
        onAdCompleted={handleAdCompleted}
      />

      <DirectDonateModal
        campaign={activeDonateCampaign}
        onClose={() => setActiveDonateCampaign(null)}
        onDonationCompleted={handleDonationCompleted}
      />

      <CampaignDetailModal
        campaign={activeDetailCampaign}
        onClose={() => setActiveDetailCampaign(null)}
        onWatchAd={handleWatchAd}
        onDonate={handleDonate}
        onShare={handleShare}
      />

      <ReceiptModal
        receiptData={activeReceipt}
        onClose={() => setActiveReceipt(null)}
      />

      <LoginPage
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onSuccessLogin={handleSuccessLogin}
        onOpenSuperAdmin={() => {
          setIsLoginOpen(false);
          setIsSuperAdminOpen(true);
        }}
      />

      <SuperAdminModal
        isOpen={isSuperAdminOpen}
        onClose={() => setIsSuperAdminOpen(false)}
        campaigns={campaigns}
        onUpdateCampaigns={setCampaigns}
        onAdminAuthenticated={(adminUser) => {
          setCurrentUser(adminUser);
          setCurrentTab("admin");
        }}
      />

      <WelcomePage
        isOpen={isWelcomeOpen}
        onClose={() => setIsWelcomeOpen(false)}
        onGetStarted={() => {
          setIsWelcomeOpen(false);
          setIsLoginOpen(true);
        }}
        onLearnMore={() => {
          setIsWelcomeOpen(false);
          handleOpenAboutTab("about");
        }}
        onOpenTerms={() => {
          setIsWelcomeOpen(false);
          handleOpenAboutTab("terms");
        }}
        onOpenPrivacy={() => {
          setIsWelcomeOpen(false);
          handleOpenAboutTab("privacy");
        }}
      />
    </div>
  );
}
