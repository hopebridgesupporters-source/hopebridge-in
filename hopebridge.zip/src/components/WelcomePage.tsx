import React, { useState } from "react";
import { HopeBridgeLogo } from "./HopeBridgeLogo";
import { ContactSection } from "./ContactSection";
import { 
  Heart, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  Info, 
  Lock, 
  Building2, 
  BarChart3, 
  CheckCircle2, 
  Users,
  ShieldAlert,
  ChevronRight,
  ExternalLink,
  Mail,
  X
} from "lucide-react";

interface WelcomePageProps {
  isOpen: boolean;
  onClose: () => void;
  onGetStarted: () => void;
  onLearnMore: () => void;
  onOpenTerms?: () => void;
  onOpenPrivacy?: () => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  isOpen,
  onClose,
  onGetStarted,
  onLearnMore,
  onOpenTerms,
  onOpenPrivacy,
}) => {
  const [showSecurityNotice, setShowSecurityNotice] = useState<boolean>(false);
  const [showContactModal, setShowContactModal] = useState<boolean>(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-white min-h-screen w-full flex flex-col justify-between p-6 sm:p-12 lg:p-16 animate-fade-in antialiased selection:bg-teal-600 selection:text-white">
      
      {/* Top Header Logo & Platform Status Bar */}
      <div className="max-w-6xl mx-auto w-full flex flex-col sm:flex-row items-center justify-between border-b border-slate-100 pb-6 shrink-0 gap-4">
        <div className="flex justify-center w-full sm:w-auto">
          <HopeBridgeLogo 
            size="md" 
            layout="horizontal" 
            onClick={onClose} 
          />
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs font-semibold text-slate-500 bg-slate-50 px-3.5 py-1.5 rounded-full">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>256-Bit Encrypted Operations</span>
        </div>
      </div>

      {/* Main Hero Section - Pure Full Screen Center */}
      <div className="max-w-4xl mx-auto w-full my-auto py-6 sm:py-10 text-center space-y-6">
        
        {/* Prominent Official Top Center HopeBridge Logo */}
        <div className="flex justify-center my-2">
          <HopeBridgeLogo 
            size="xl" 
            layout="vertical" 
            onClick={onClose} 
          />
        </div>

        {/* Main Branding Pill */}
        <div className="inline-flex items-center gap-2 bg-teal-50 border border-teal-100/80 rounded-full px-4 py-1.5 text-xs font-bold text-teal-800">
          <Sparkles className="w-3.5 h-3.5 text-teal-600" />
          <span>Healthcare Crowdfunding Platform</span>
        </div>

        {/* Title & Subtitle */}
        <div className="space-y-4 max-w-3xl mx-auto">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.15]">
            Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-700 via-emerald-700 to-teal-800">HopeBridge</span>
          </h1>

          <p className="text-lg sm:text-xl font-medium text-slate-700 max-w-2xl mx-auto leading-relaxed">
            A trusted platform connecting people who need medical support with those who want to help.
          </p>

          <p className="text-sm text-slate-500 max-w-2xl mx-auto leading-relaxed pt-2">
            HopeBridge securely verifies medical cases, protects user privacy, and makes fundraising transparent so every contribution reaches those who need it most.
          </p>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 max-w-md mx-auto">
          <button
            onClick={() => {
              onClose();
              onGetStarted();
            }}
            className="w-full sm:w-auto px-10 py-4 bg-teal-800 hover:bg-teal-900 text-white font-bold text-sm uppercase tracking-wider rounded-2xl shadow-xl shadow-teal-800/25 hover:shadow-teal-800/40 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-3 cursor-pointer group"
          >
            <span>Get Started</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => {
              setShowSecurityNotice(true);
            }}
            className="w-full sm:w-auto px-8 py-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Info className="w-4 h-4 text-slate-600" />
            <span>Learn More</span>
          </button>
        </div>

        {/* Security Notice Modal/Overlay for Secured Operations */}
        {showSecurityNotice && (
          <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 text-left border border-slate-100 shadow-2xl relative">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-800 flex items-center justify-center">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Secured Platform Operations</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  To protect patient confidential records and hospital billing systems, HopeBridge requires authenticated access or verified guest clearance before opening full operational features.
                </p>
              </div>

              <div className="space-y-2 text-xs bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                <div className="flex items-center gap-2 text-slate-800 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>ISO-27001 Medical Compliance</span>
                </div>
                <div className="flex items-center gap-2 text-slate-800 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Direct Escrow Billing Protection</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <button
                  onClick={() => {
                    setShowSecurityNotice(false);
                    onClose();
                    onGetStarted();
                  }}
                  className="flex-1 px-4 py-3 bg-teal-800 hover:bg-teal-900 text-white font-bold text-xs uppercase rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Sign In First</span>
                </button>
                <button
                  onClick={() => {
                    setShowSecurityNotice(false);
                    onClose();
                    onLearnMore();
                  }}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  Guest Overview
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 4 Premium Feature Cards */}
        <div className="pt-8 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
            Four Core Pillars of HopeBridge
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left max-w-5xl mx-auto">
            <div className="p-5 bg-slate-50/80 hover:bg-slate-50 transition-colors rounded-2xl space-y-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">✓ Verified Medical Cases</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Physical on-site agent verification and hospital counters validate every case estimate.
              </p>
            </div>

            <div className="p-5 bg-slate-50/80 hover:bg-slate-50 transition-colors rounded-2xl space-y-2">
              <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">✓ Secure Donations</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                100% bank-grade encrypted channels directed exclusively to patient escrow accounts.
              </p>
            </div>

            <div className="p-5 bg-slate-50/80 hover:bg-slate-50 transition-colors rounded-2xl space-y-2">
              <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center">
                <Building2 className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">✓ Trusted Healthcare Partners</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Direct billing integration with Fortis, Apollo, AIIMS, and Manipal hospitals.
              </p>
            </div>

            <div className="p-5 bg-slate-50/80 hover:bg-slate-50 transition-colors rounded-2xl space-y-2">
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">✓ Transparent Fundraising</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Zero-commission ad support and public ledger audit trails for all contributions.
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Footer Links */}
      <div className="max-w-6xl mx-auto w-full pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-4 shrink-0">
        <div className="flex items-center gap-1.5 font-medium">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>© 2026 HopeBridge Foundation. All rights reserved.</span>
        </div>

        <div className="flex items-center gap-6 font-semibold">
          <button
            onClick={() => onOpenPrivacy ? onOpenPrivacy() : alert("HopeBridge Privacy Policy")}
            className="hover:text-slate-900 transition-colors cursor-pointer border-0 bg-transparent"
          >
            Privacy Policy
          </button>
          <button
            onClick={() => onOpenTerms ? onOpenTerms() : alert("HopeBridge Terms & Conditions")}
            className="hover:text-slate-900 transition-colors cursor-pointer border-0 bg-transparent"
          >
            Terms & Conditions
          </button>
          <button
            onClick={() => setShowContactModal(true)}
            className="hover:text-teal-800 font-bold transition-colors cursor-pointer flex items-center gap-1 border-0 bg-transparent"
          >
            <Mail className="w-3.5 h-3.5 text-teal-600" />
            <span>Contact Us</span>
          </button>
        </div>
      </div>

      {/* Contact Us Modal */}
      {showContactModal && (
        <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl border border-slate-100 space-y-4">
            <button
              onClick={() => setShowContactModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors"
              aria-label="Close Contact Modal"
            >
              <X className="w-5 h-5" />
            </button>

            <ContactSection variant="card" />

            <div className="pt-2 text-center">
              <button
                onClick={() => setShowContactModal(false)}
                className="px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

