import React from "react";

interface HopeBridgeLogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  layout?: "vertical" | "horizontal" | "icon";
  showText?: boolean;
  onClick?: () => void;
  className?: string;
  darkText?: boolean;
}

export const HopeBridgeLogo: React.FC<HopeBridgeLogoProps> = ({
  size = "md",
  layout = "horizontal",
  showText = true,
  onClick,
  className = "",
  darkText = true,
}) => {
  // Sizing mappings
  const svgSizes = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-20 h-20",
    xl: "w-32 h-32",
  };

  const textSizes = {
    sm: "text-sm tracking-[3px]",
    md: "text-lg tracking-[4px]",
    lg: "text-2xl tracking-[6px]",
    xl: "text-4xl tracking-[8px]",
  };

  const containerGaps = {
    sm: "gap-2",
    md: "gap-3",
    lg: "gap-4",
    xl: "gap-5",
  };

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center justify-center select-none ${
        layout === "vertical" ? "flex-col text-center" : "flex-row"
      } ${containerGaps[size]} ${
        onClick ? "cursor-pointer hover:opacity-90 active:scale-[0.98] transition-all" : ""
      } ${className}`}
      title="Hope Bridge"
    >
      <style>{`
        .hb-logo-wrapper {
          --brand-dark: #0f172a;
          --india-saffron: #ff9933;
          --india-green: #138808;
          --heart-red: #dc2626;
          --gold-coin: #d97706;
          --node-red: #ef4444;
          --node-green: #22c55e;
          --node-blue: #3b82f6;
        }

        /* 🌍 FULL EARTH SPHERE ROTATION WITH SOLID LINES */
        .hb-whole-earth-sphere {
          transform-origin: 100px 100px;
          transform-style: preserve-3d;
          animation: hbRollWholeEarth 10s linear infinite;
        }

        @keyframes hbRollWholeEarth {
          0% { transform: rotateY(0deg) rotateX(-5deg); }
          100% { transform: rotateY(360deg) rotateX(-5deg); }
        }

        /* Fluid connection light beams crossing points */
        .hb-leaping-beam {
          fill: none;
          stroke-width: 3.5;
          stroke-linecap: round;
          stroke-dasharray: 120;
          stroke-dashoffset: 120;
          animation: hbBeamTravel 3s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }

        .hb-beam-saffron { stroke: var(--india-saffron); animation-delay: 0s; }
        .hb-beam-green { stroke: var(--india-green); animation-delay: 1.5s; }

        @keyframes hbBeamTravel {
          0% { stroke-dashoffset: 120; }
          50% { stroke-dashoffset: 0; }
          100% { stroke-dashoffset: -120; }
        }

        /* Donation relief drop tokens tracking down to center */
        .hb-donation-coin {
          fill: var(--gold-coin);
          opacity: 0;
          animation: hbDropToHeart 3s cubic-bezier(0.6, -0.28, 0.735, 0.045) infinite;
        }

        .hb-coin-left { animation-delay: 0.6s; }
        .hb-coin-right { animation-delay: 2.1s; }

        @keyframes hbDropToHeart {
          0% { transform: translate(0, 0) scale(0.6); opacity: 0; }
          15% { opacity: 1; transform: scale(1); }
          45% { transform: translate(var(--target-x), var(--target-y)) scale(0.8); opacity: 1; filter: drop-shadow(0 2px 4px rgba(217, 119, 6, 0.4)); }
          50%, 100% { transform: translate(var(--target-x), var(--target-y)) scale(0); opacity: 0; }
        }

        /* Target Point Nodes Animation Configurations */
        .hb-grid-node {
          transform-origin: center;
          animation: hbNodePulseEffect 3s ease-in-out infinite;
        }

        .hb-node-west  { fill: var(--node-red); transform-origin: 43px 100px; animation-delay: 0s; }
        .hb-node-north { fill: var(--node-green); transform-origin: 100px 43px; animation-delay: 1.5s; }
        .hb-node-east  { fill: var(--node-blue); transform-origin: 157px 100px; animation-delay: 3s; }

        @keyframes hbNodePulseEffect {
          0%, 100% { transform: scale(1); opacity: 0.9; filter: drop-shadow(0 0 0px transparent); }
          50% { transform: scale(1.4); opacity: 1; filter: drop-shadow(0 2px 8px currentColor); }
        }

        /* Active Core Charity Heart Vault */
        .hb-central-heart {
          fill: var(--heart-red);
          transform-origin: 100px 100px;
          animation: hbDynamicHeartPulse 1.5s ease-in-out infinite;
        }

        @keyframes hbDynamicHeartPulse {
          0%, 100% { transform: scale(1); filter: drop-shadow(0 2px 4px rgba(220, 38, 38, 0.2)); }
          20% { transform: scale(1.3); filter: drop-shadow(0 4px 12px rgba(220, 38, 38, 0.5)); }
          40% { transform: scale(0.95); }
          60% { transform: scale(1.1); }
        }
      `}</style>

      {/* SVG LOGO ELEMENT */}
      <div className={`hb-logo-wrapper shrink-0 ${svgSizes[size]}`}>
        <svg
          className="w-full h-full overflow-visible"
          viewBox="0 0 200 200"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Planetary Outer Atmosphere Line */}
          <circle cx="100" cy="100" r="65" fill="none" stroke="var(--brand-dark)" strokeWidth="0.75" />

          {/* LAYER 1: UNIFIED 3D DARK EARTH BALL */}
          <g className="hb-whole-earth-sphere">
            {/* Main Outer Structural Profile Ring */}
            <circle cx="100" cy="100" r="64.5" fill="none" stroke="var(--brand-dark)" strokeWidth="2.5" />
            
            {/* Latitudes (Solid Dark Horizontal Lines) */}
            <path d="M 43,73 Q 100,90 157,73" fill="none" stroke="var(--brand-dark)" strokeWidth="1.75" />
            <path d="M 43,127 Q 100,110 157,127" fill="none" stroke="var(--brand-dark)" strokeWidth="1.75" />
            <line x1="35" y1="100" x2="165" y2="100" stroke="var(--brand-dark)" strokeWidth="1.75" />

            {/* Longitudes (Solid Dark Vertical Lines) */}
            <line x1="100" y1="35" x2="100" y2="165" stroke="var(--brand-dark)" strokeWidth="2.5" />
            <ellipse cx="100" cy="100" rx="43" ry="65" fill="none" stroke="var(--brand-dark)" strokeWidth="1.75" />
            <ellipse cx="100" cy="100" rx="20" ry="65" fill="none" stroke="var(--brand-dark)" strokeWidth="1.75" />
          </g>

          {/* LAYER 2: INTERACTIVE DATA OVERLAY SYSTEM */}
          <g className="hb-donation-overlay">
            {/* Three Custom Colored Anchors: Red (West), Green (North), Blue (East) */}
            <circle className="hb-grid-node hb-node-west" cx="43" cy="100" r="5" color="#ef4444" />
            <circle className="hb-grid-node hb-node-north" cx="100" cy="43" r="5" color="#22c55e" />
            <circle className="hb-grid-node hb-node-east" cx="157" cy="100" r="5" color="#3b82f6" />

            {/* Arrow-free Leaping Support Rays */}
            <path className="hb-leaping-beam hb-beam-saffron" d="M 43,100 C 40,65 70,45 100,43" />
            <path className="hb-leaping-beam hb-beam-green" d="M 100,43 C 130,45 160,65 157,100" />

            {/* Dropping Financial Support Gold Coins */}
            <circle
              className="hb-donation-coin hb-coin-left"
              cx="68"
              cy="50"
              r="4.5"
              style={{ "--target-x": "32px", "--target-y": "50px" } as React.CSSProperties}
            />
            <circle
              className="hb-donation-coin hb-coin-right"
              cx="132"
              cy="50"
              r="4.5"
              style={{ "--target-x": "-32px", "--target-y": "50px" } as React.CSSProperties}
            />

            {/* Central Charity Donation Receiver Vault (Heart) */}
            <path
              className="hb-central-heart"
              d="M 100,107 C 100,107 96,103 93,100 C 90,97 90,94 93,92 C 96,90 99,92 100,94 C 101,92 104,90 107,92 C 110,94 110,97 107,100 C 104,103 100,107 100,107 Z"
            />
          </g>
        </svg>
      </div>

      {/* TYPOGRAPHY BRAND TITLE */}
      {showText && layout !== "icon" && (
        <div className="leading-none whitespace-nowrap">
          <span
            className={`font-extrabold uppercase font-sans ${textSizes[size]} ${
              darkText ? "text-slate-900" : "text-white"
            }`}
          >
            Hope Bridge
          </span>
        </div>
      )}
    </div>
  );
};
