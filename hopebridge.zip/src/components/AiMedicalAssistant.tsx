import React, { useState } from "react";
import { 
  Sparkles, 
  Search, 
  BookOpen, 
  Award, 
  CheckCircle2, 
  Send,
  Building2,
  FileText
} from "lucide-react";

export const AiMedicalAssistant: React.FC = () => {
  const [disease, setDisease] = useState<string>("Spinal Muscular Atrophy (SMA)");
  const [state, setState] = useState<string>("Delhi NCR");
  const [estimatedCost, setEstimatedCost] = useState<string>("15000000");
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<any>(null);

  const handleSearchSchemes = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch("/api/ai/guidance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ disease, state, estimatedCost }),
      });

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      setResult({
        governmentSchemes: [
          {
            name: "Ayushman Bharat PM-JAY",
            coverage: "Up to ₹5,00,000 per family per year",
            eligibility: "BPL families and SECC 2011 category holders",
          },
          {
            name: "Rashtriya Arogya Nidhi (RAN) - Rare Diseases",
            coverage: "Financial assistance up to ₹15,00,000 to ₹20,00,000",
            eligibility: "Patients with rare diseases receiving treatment in super-specialty AIIMS/government hospitals",
          },
          {
            name: "Chief Minister's Relief Fund (CMRF)",
            coverage: "₹50,000 to ₹3,00,000 depending on state grant",
            eligibility: "State residents with income certificate below state threshold",
          },
        ],
        storyTips: [
          "State the exact hospital doctor quote and ICU per-day costs",
          "Explain that 95% of ad views go directly to the hospital account",
          "Provide regular medical updates with doctor signatures",
        ],
        adFundraisingEstimate:
          "By sharing your campaign with 1,000 supporters watching 2 ads daily, your campaign can raise ~₹70,000/day in verified ad funding!",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 text-slate-900 p-6 sm:p-8 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-purple-50 text-purple-800 border border-purple-200 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>AI Health Policy & Campaign Assistant</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Find Government Schemes & Optimize Campaign
          </h2>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
            Discover Government Relief Funds (Ayushman Bharat, RAN, CMRF) alongside community ad-fundraising to cover expensive surgeries and rare disease treatments.
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Form Column */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 border-b pb-3">
            Search Available Government Medical Assistance
          </h3>

          <form onSubmit={handleSearchSchemes} className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Disease / Medical Condition
              </label>
              <input
                type="text"
                required
                value={disease}
                onChange={(e) => setDisease(e.target.value)}
                placeholder="e.g. Leukemia, SMA, Liver Failure, VSD Heart"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Resident State / Region
              </label>
              <input
                type="text"
                required
                value={state}
                onChange={(e) => setState(e.target.value)}
                placeholder="e.g. Maharashtra, Karnataka, Delhi NCR"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:border-purple-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Estimated Treatment Cost (₹)
              </label>
              <input
                type="number"
                required
                value={estimatedCost}
                onChange={(e) => setEstimatedCost(e.target.value)}
                placeholder="e.g. 1500000"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:border-purple-500 font-bold"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-2xl shadow-lg transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2"
            >
              {loading ? (
                <span>Querying Policy Database...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Find Government Schemes & Advice</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Column */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 space-y-6 shadow-sm">
          {!result ? (
            <div className="text-center p-12 text-slate-400 space-y-2">
              <BookOpen className="w-10 h-10 mx-auto text-slate-300" />
              <h4 className="text-sm font-bold text-slate-600">No Query Submitted Yet</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Enter disease and state details on the left to receive AI policy analysis and campaign advice.
              </p>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Government Schemes List */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Award className="w-4 h-4 text-emerald-600" />
                  Government Financial Relief Schemes
                </h3>

                <div className="space-y-3 text-xs">
                  {result.governmentSchemes?.map((sch: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1"
                    >
                      <h4 className="font-bold text-emerald-950 text-sm">{sch.name}</h4>
                      <p className="text-emerald-800 font-semibold">
                        Coverage: {sch.coverage}
                      </p>
                      <p className="text-emerald-700 text-[11px]">
                        Eligibility: {sch.eligibility}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Ad Model Projection */}
              {result.adFundraisingEstimate && (
                <div className="bg-purple-50 border border-purple-200 p-4 rounded-2xl space-y-1 text-xs">
                  <span className="font-bold text-purple-900 block flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-purple-600" /> Community Ad Revenue Projection
                  </span>
                  <p className="text-purple-800 leading-relaxed">
                    {result.adFundraisingEstimate}
                  </p>
                </div>
              )}

              {/* Storytelling Tips */}
              {result.storyTips && (
                <div className="space-y-2 text-xs">
                  <h4 className="font-bold text-slate-900">Campaign Storytelling Best Practices:</h4>
                  <ul className="space-y-1.5 list-disc list-inside text-slate-700">
                    {result.storyTips.map((tip: string, idx: number) => (
                      <li key={idx}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
