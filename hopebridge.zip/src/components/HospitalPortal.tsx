import React, { useState } from "react";
import { PatientCampaign, CampaignUpdate } from "../types";
import { 
  Building2, 
  FileCheck2, 
  PlusCircle, 
  CheckCircle2, 
  DollarSign, 
  Stethoscope, 
  Clock, 
  ShieldCheck,
  Send
} from "lucide-react";

interface HospitalPortalProps {
  campaigns: PatientCampaign[];
  onAddUpdate: (campaignId: string, update: CampaignUpdate) => void;
}

export const HospitalPortal: React.FC<HospitalPortalProps> = ({
  campaigns,
  onAddUpdate,
}) => {
  const [selectedCampaignId, setSelectedCampaignId] = useState<string>(
    campaigns[0]?.id || ""
  );

  const selectedCampaign =
    campaigns.find((c) => c.id === selectedCampaignId) || campaigns[0];

  const [updateTitle, setUpdateTitle] = useState<string>("");
  const [updateContent, setUpdateContent] = useState<string>("");
  const [postSuccess, setPostSuccess] = useState<boolean>(false);

  if (!selectedCampaign) return null;

  const handlePostUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateTitle || !updateContent) return;

    const newUpdate: CampaignUpdate = {
      id: `up-${Date.now()}`,
      date: new Date().toISOString().split("T")[0],
      title: updateTitle,
      content: updateContent,
      author: `${selectedCampaign.hospitalName} Medical Desk`,
      role: "Hospital",
    };

    onAddUpdate(selectedCampaign.id, newUpdate);
    setUpdateTitle("");
    setUpdateContent("");
    setPostSuccess(true);
    setTimeout(() => setPostSuccess(false), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Hospital Portal Header */}
      <div className="bg-white border border-slate-200 text-slate-900 p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-700 border border-teal-200 flex items-center justify-center">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Hospital & NGO Verification Portal</h2>
            <p className="text-xs text-slate-500">
              Direct Hospital Desk Integration • Verified Billing & Escrow Disbursal
            </p>
          </div>
        </div>

        <div className="bg-emerald-50 px-4 py-2 rounded-2xl border border-emerald-200 text-xs text-emerald-800 font-bold flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Zero-Leakage Escrow: All funds transferred directly to Hospital Accounts</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Left: Patient List */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-3xl p-5 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900">Hospital Patient Roster</h3>

          <div className="space-y-3">
            {campaigns.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedCampaignId(c.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  c.id === selectedCampaign.id
                    ? "bg-slate-900 text-white border-slate-900 shadow"
                    : "bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100"
                }`}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold opacity-80">{c.hospitalName}</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    ₹{(c.collectedAmount / 100000).toFixed(1)}L Collected
                  </span>
                </div>
                <h4 className="font-bold text-sm mt-1">{c.patientName}</h4>
                <p className="text-xs opacity-70 line-clamp-1">{c.diagnosis}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Hospital Desk Controls */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-6 space-y-6 shadow-sm">
          <div className="flex items-center justify-between border-b pb-4">
            <div>
              <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
                Active Hospital Patient
              </span>
              <h2 className="text-xl font-black text-slate-900">{selectedCampaign.patientName}</h2>
              <p className="text-xs text-slate-500">
                Doctor: <strong>{selectedCampaign.doctorName}</strong> ({selectedCampaign.doctorRegNo})
              </p>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-bold block uppercase">
                Escrow Funds Ready to Disburse
              </span>
              <span className="text-emerald-700 font-black text-lg">
                ₹{(selectedCampaign?.collectedAmount ?? 0).toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          {/* Treatment Cost Items Breakdown */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Hospital Verified Treatment Quotation
            </h3>
            <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Treatment / Procedure</th>
                    <th className="p-3">Category</th>
                    <th className="p-3 text-right">Cost (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {selectedCampaign.treatmentBreakdown?.map((item) => (
                    <tr key={item.id}>
                      <td className="p-3 font-semibold">{item.name}</td>
                      <td className="p-3 text-slate-500">{item.category}</td>
                      <td className="p-3 text-right font-bold font-mono">
                        ₹{(item?.cost ?? 0).toLocaleString("en-IN")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Post Hospital Update Form */}
          <form onSubmit={handlePostUpdate} className="bg-slate-50 border border-slate-200 p-5 rounded-2xl space-y-3">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <PlusCircle className="w-4 h-4 text-emerald-600" />
              Post Official Medical Progress Note to Campaign Page
            </h3>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Update Headline
              </label>
              <input
                type="text"
                required
                value={updateTitle}
                onChange={(e) => setUpdateTitle(e.target.value)}
                placeholder="e.g. ICU Stay Completed & VSD Heart Surgery Scheduled for Friday"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Medical Details / Doctor Note
              </label>
              <textarea
                rows={3}
                required
                value={updateContent}
                onChange={(e) => setUpdateContent(e.target.value)}
                placeholder="Share patient health progress, test results, or drug application updates for supporters..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
              />
            </div>

            {postSuccess && (
              <div className="text-xs text-emerald-800 bg-emerald-100 p-2 rounded-lg font-bold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Medical note published to public campaign wall!
              </div>
            )}

            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center gap-2 shadow transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Publish Official Hospital Update</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
