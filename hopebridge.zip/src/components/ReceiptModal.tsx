import React from "react";
import { 
  X, 
  Printer, 
  Download, 
  ShieldCheck, 
  CheckCircle2, 
  Building2 
} from "lucide-react";

interface ReceiptModalProps {
  receiptData: {
    receiptNo: string;
    donorName: string;
    donorEmail?: string;
    amount: number;
    patientName: string;
    hospitalName: string;
    panNumber: string;
    date: string;
  } | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  receiptData,
  onClose,
}) => {
  if (!receiptData) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white text-slate-900 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative border border-slate-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Official Section 80G Tax Exemption Receipt
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Canvas Body */}
        <div className="p-6 space-y-6 text-xs" id="receipt-print-area">
          {/* Top Logo */}
          <div className="flex items-center justify-between border-b pb-4">
            <div>
              <h2 className="text-xl font-black text-slate-900">
                Hope<span className="text-emerald-600">Bridge</span> Foundation
              </h2>
              <p className="text-[10px] text-slate-500">
                Registered Medical Relief Trust • Reg No: IV-1829/2024
              </p>
              <p className="text-[10px] text-slate-500">
                80G Exemption Approval No: AAATH8912EF20241
              </p>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">
                Receipt Number
              </span>
              <span className="font-mono font-bold text-emerald-700 text-xs">
                {receiptData.receiptNo}
              </span>
              <span className="text-[10px] text-slate-500 block">
                Date: {receiptData.date}
              </span>
            </div>
          </div>

          {/* Receipt Details Table */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="flex justify-between border-b pb-2">
              <span className="text-slate-500">Donor Full Name:</span>
              <span className="font-bold text-slate-900">{receiptData.donorName}</span>
            </div>

            {receiptData.panNumber && (
              <div className="flex justify-between border-b pb-2">
                <span className="text-slate-500">PAN Number (80G Tax Benefit):</span>
                <span className="font-mono font-bold text-slate-900">{receiptData.panNumber}</span>
              </div>
            )}

            <div className="flex justify-between border-b pb-2">
              <span className="text-slate-500">Supported Patient:</span>
              <span className="font-bold text-slate-900">{receiptData.patientName}</span>
            </div>

            <div className="flex justify-between border-b pb-2">
              <span className="text-slate-500">Verified Hospital Escrow:</span>
              <span className="font-semibold text-slate-800">{receiptData.hospitalName}</span>
            </div>

            <div className="flex justify-between pt-1">
              <span className="text-slate-700 font-bold">Total Donated Amount:</span>
              <span className="font-black font-mono text-emerald-700 text-base">
                ₹{(receiptData?.amount ?? 0).toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          {/* Tax Note */}
          <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-[11px] text-emerald-900">
            <p className="font-semibold">
              ✓ Eligible for 50% Tax Exemption under Section 80G of the Income Tax Act, 1961.
            </p>
            <p className="text-[10px] text-emerald-800 mt-0.5">
              100% of this donation was deposited into HopeBridge Escrow for direct transfer to {receiptData.hospitalName}.
            </p>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl transition-colors text-xs"
          >
            Close Receipt
          </button>
        </div>
      </div>
    </div>
  );
};
