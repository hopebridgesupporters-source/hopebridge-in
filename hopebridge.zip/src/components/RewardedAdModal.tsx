import React, { useState, useEffect } from "react";
import { PatientCampaign, AdSponsor } from "../types";
import { initialSponsors } from "../data/mockData";
import confetti from "canvas-confetti";
import { 
  Tv, 
  X, 
  Play, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  Building2, 
  Lock,
  ExternalLink,
  Award,
  AlertCircle,
  Image as ImageIcon,
  Video,
  Music
} from "lucide-react";

interface RewardedAdModalProps {
  campaign: PatientCampaign | null;
  onClose: () => void;
  onAdCompleted: (campaignId: string, payout: number, sponsorName: string) => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  campaign,
  onClose,
  onAdCompleted,
}) => {
  // Read dynamic sponsors created/edited by Super Admin
  const [sponsors] = useState<AdSponsor[]>(() => {
    try {
      const stored = localStorage.getItem("hopebridge_sponsors");
      return stored ? JSON.parse(stored) : initialSponsors;
    } catch {
      return initialSponsors;
    }
  });

  const [selectedSponsor, setSelectedSponsor] = useState<AdSponsor>(sponsors[0] || initialSponsors[0]);
  const [adState, setAdState] = useState<"SELECT" | "WATCHING" | "QUIZ" | "COMPLETED">("SELECT");
  const [secondsLeft, setSecondsLeft] = useState<number>(15);
  const [quizAnswer, setQuizAnswer] = useState<string | null>(null);

  useEffect(() => {
    let timer: any;
    if (adState === "WATCHING" && secondsLeft > 0) {
      timer = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (adState === "WATCHING" && secondsLeft === 0) {
      setAdState("QUIZ");
    }
    return () => clearInterval(timer);
  }, [adState, secondsLeft]);

  if (!campaign) return null;

  const handleStartAd = (sponsor: AdSponsor) => {
    setSelectedSponsor(sponsor);
    setSecondsLeft(sponsor.videoDurationSeconds || 15);
    setAdState("WATCHING");
  };

  const handleCompleteQuiz = () => {
    setAdState("COMPLETED");

    // Trigger celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    onAdCompleted(campaign.id, selectedSponsor.payoutPerView, selectedSponsor.brandName);
  };

  const grossPayout = selectedSponsor.payoutPerView;
  const patientShare = Number((grossPayout * 0.95).toFixed(2));
  const opsShare = Number((grossPayout * 0.03).toFixed(2));
  const adminShare = Number((grossPayout * 0.02).toFixed(2));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl relative animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
              <Tv className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Rewarded Ad Support Engine</h3>
              <p className="text-[11px] text-slate-400">
                Helping <strong className="text-emerald-400">{campaign.patientName}</strong> ({campaign.hospitalName})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: Select Sponsor */}
        {adState === "SELECT" && (
          <div className="p-6 space-y-5">
            <div className="text-center space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-400 bg-purple-950/80 border border-purple-800 px-3 py-1 rounded-full">
                Verified Sponsor Network
              </span>
              <h2 className="text-xl font-black text-white">Choose an Ad Campaign to Watch</h2>
              <p className="text-xs text-slate-300">
                Watching a 15-second sponsor video credits <strong className="text-emerald-400">₹30 - ₹50</strong> directly into {campaign.hospitalName}'s account.
              </p>
            </div>

            <div className="space-y-3">
              {sponsors.map((sponsor) => (
                <div
                  key={sponsor.id}
                  onClick={() => handleStartAd(sponsor)}
                  className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-purple-500/50 p-4 rounded-2xl cursor-pointer transition-all flex items-center justify-between gap-4 group"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={sponsor.logoUrl}
                      alt={sponsor.brandName}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-xl object-cover bg-slate-700 shrink-0 border border-slate-600"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-purple-400 block uppercase">
                          {sponsor.category}
                        </span>
                        {sponsor.imageUrl && (
                          <span className="text-[9px] bg-purple-950 text-purple-300 px-1.5 py-0.2 rounded border border-purple-800">
                            Photo Ad
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
                        {sponsor.brandName}
                      </h4>
                      <p className="text-xs text-slate-400 line-clamp-1">
                        {sponsor.campaignTitle}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs text-slate-400 block">Generates</span>
                    <span className="text-emerald-400 font-black text-base">
                      +₹{sponsor.payoutPerView}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {sponsor.videoDurationSeconds}s watch
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                100% Transparency: 95% of ad funds go to patient hospital escrow, 3% to field audits, 2% admin.
              </span>
            </div>
          </div>
        )}

        {/* STEP 2: Watching Ad */}
        {adState === "WATCHING" && (
          <div className="p-6 space-y-6 text-center">
            {/* Rich Media Player Box */}
            <div className="relative min-h-[220px] max-h-[360px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 flex flex-col items-center justify-center p-4 space-y-3">
              <div className="absolute top-3 right-3 z-20 bg-slate-900/90 text-amber-300 font-mono text-xs font-bold px-3 py-1.5 rounded-full border border-amber-500/30 flex items-center gap-1.5 shadow-lg backdrop-blur-sm">
                <Lock className="w-3 h-3 text-amber-400" />
                <span>Ad Playing: {secondsLeft}s remaining</span>
              </div>

              {/* Photo Banner View (Supports any size) */}
              {selectedSponsor.imageUrl ? (
                <div className="w-full h-full min-h-[160px] flex items-center justify-center overflow-hidden rounded-xl bg-slate-900 relative">
                  <img
                    src={selectedSponsor.imageUrl}
                    alt={selectedSponsor.brandName}
                    referrerPolicy="no-referrer"
                    className="w-full max-h-[220px] object-contain rounded-lg"
                  />
                </div>
              ) : selectedSponsor.videoUrl ? (
                /* Video Player View */
                <div className="w-full aspect-video rounded-xl overflow-hidden bg-black flex items-center justify-center">
                  <iframe
                    src={selectedSponsor.videoUrl}
                    title={selectedSponsor.brandName}
                    className="w-full h-full border-0"
                    allow="autoplay; encrypted-media"
                  />
                </div>
              ) : (
                /* Standard Graphic Placeholder */
                <div className="w-16 h-16 rounded-full bg-purple-600/30 text-purple-300 border border-purple-500/40 flex items-center justify-center animate-pulse my-2">
                  <Play className="w-8 h-8 fill-current ml-1" />
                </div>
              )}

              {/* Audio Track Indicator */}
              {selectedSponsor.audioUrl && (
                <div className="w-full bg-slate-900 border border-amber-500/30 p-2 rounded-xl flex items-center justify-center gap-2 text-xs text-amber-300">
                  <Music className="w-4 h-4 animate-bounce" />
                  <span>Playing Sponsor Audio Clip</span>
                  <audio src={selectedSponsor.audioUrl} autoPlay loop className="hidden" />
                </div>
              )}

              <div className="max-w-md space-y-1">
                <span className="text-xs text-purple-400 font-bold uppercase tracking-wider">
                  Sponsored by {selectedSponsor.brandName}
                </span>
                <h3 className="text-sm font-bold text-white">
                  "{selectedSponsor.bannerText}"
                </h3>
              </div>

              {/* External Link Button */}
              {selectedSponsor.externalLink && (
                <a
                  href={selectedSponsor.externalLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white px-3.5 py-1.5 rounded-xl transition-all shadow"
                >
                  <span>{selectedSponsor.callToAction || "Visit Sponsor Site"}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              {/* Progress Bar */}
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
                <div
                  style={{
                    width: `${(((selectedSponsor.videoDurationSeconds || 15) - secondsLeft) / (selectedSponsor.videoDurationSeconds || 15)) * 100}%`,
                  }}
                  className="bg-purple-500 h-full transition-all duration-1000 ease-linear"
                />
              </div>
            </div>

            <p className="text-xs text-slate-400">
              Please watch the full sponsor message. Do not close or switch tabs to ensure ad revenue is validly credited to <strong className="text-white">{campaign.patientName}</strong>.
            </p>
          </div>
        )}

        {/* STEP 3: Simple Anti-Fraud Verification Quiz */}
        {adState === "QUIZ" && (
          <div className="p-6 space-y-5">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Ad Completed! Confirm Your Support</h3>
              <p className="text-xs text-slate-300">
                To prevent automated bot fraud, answer this quick 1-second question to release the <strong className="text-emerald-400">₹{selectedSponsor.payoutPerView}</strong> contribution.
              </p>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3">
              <p className="text-xs font-bold text-slate-200">
                Question: Where is 95% of this ad revenue transferred?
              </p>

              <div className="space-y-2 text-xs font-medium">
                <button
                  onClick={() => setQuizAnswer("correct")}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                    quizAnswer === "correct"
                      ? "bg-emerald-600/20 border-emerald-500 text-emerald-300"
                      : "bg-slate-900 border-slate-700 hover:border-slate-600 text-slate-300"
                  }`}
                >
                  <span>Directly to {campaign.hospitalName}'s Verified Escrow Account</span>
                  {quizAnswer === "correct" && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                </button>

                <button
                  onClick={() => setQuizAnswer("wrong")}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                    quizAnswer === "wrong"
                      ? "bg-rose-600/20 border-rose-500 text-rose-300"
                      : "bg-slate-900 border-slate-700 hover:border-slate-600 text-slate-300"
                  }`}
                >
                  <span>To an unverified personal bank account</span>
                  {quizAnswer === "wrong" && <AlertCircle className="w-4 h-4 text-rose-400" />}
                </button>
              </div>
            </div>

            {quizAnswer === "correct" && (
              <button
                onClick={handleCompleteQuiz}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black py-3 rounded-xl shadow-lg transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <span>Claim & Credit ₹{selectedSponsor.payoutPerView} to Campaign</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {/* STEP 4: Success Receipt */}
        {adState === "COMPLETED" && (
          <div className="p-6 space-y-6 text-center">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
              <Award className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <span className="text-xs text-emerald-400 font-bold uppercase tracking-widest">
                Impact Generated!
              </span>
              <h2 className="text-2xl font-black text-white">
                ₹{grossPayout} Credited to {campaign.patientName}
              </h2>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Thank you! Your ad view was verified and added to the public ledger.
              </p>
            </div>

            {/* Transparent Breakdown Card */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 text-xs space-y-2 text-left">
              <div className="flex justify-between border-b border-slate-700 pb-2">
                <span className="text-slate-400">Sponsor Payout:</span>
                <span className="font-bold text-white">₹{grossPayout}.00 ({selectedSponsor.brandName})</span>
              </div>
              <div className="flex justify-between text-emerald-400 font-bold">
                <span>95% Patient Hospital Fund:</span>
                <span>₹{patientShare}</span>
              </div>
              <div className="flex justify-between text-amber-400 text-[11px]">
                <span>3% Field Verification & Ops:</span>
                <span>₹{opsShare}</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>2% Platform Tech & Admin:</span>
                <span>₹{adminShare}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl border border-slate-700 text-xs transition-colors"
            >
              Close & Return to Campaigns
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
