import React, { useState } from "react";
import { PatientCampaign, VerificationReport } from "../types";
import { 
  UserCheck, 
  MapPin, 
  Hospital, 
  CheckSquare, 
  Camera, 
  ShieldCheck, 
  FileCheck, 
  Upload, 
  PhoneCall, 
  Clock,
  Sparkles,
  AlertCircle,
  Building2,
  Stethoscope
} from "lucide-react";

interface FieldAgentPortalProps {
  campaigns: PatientCampaign[];
  onGrantVerifiedBadge: (campaignId: string, report: VerificationReport) => void;
}

export const FieldAgentPortal: React.FC<FieldAgentPortalProps> = ({
  campaigns,
  onGrantVerifiedBadge,
}) => {
  const agentName = "Suresh Kumar (Senior Field Auditor)";
  const agentId = "agt-101";

  const [selectedCampaignId, setSelectedCampaignId] = useState<string>(
    campaigns[0]?.id || ""
  );

  const selectedCampaign = campaigns.find((c) => c.id === selectedCampaignId) || campaigns[0];

  // Checklist state for active audit
  const [homeVisitDone, setHomeVisitDone] = useState<boolean>(true);
  const [hospitalBedDone, setHospitalBedDone] = useState<boolean>(true);
  const [doctorConfirmedDone, setDoctorConfirmedDone] = useState<boolean>(true);
  const [estimateMatchedDone, setEstimateMatchedDone] = useState<boolean>(true);
  const [aadhaarVerifiedDone, setAadhaarVerifiedDone] = useState<boolean>(true);

  const [gpsAddress, setGpsAddress] = useState<string>(
    selectedCampaign?.hospitalName
      ? `${selectedCampaign.hospitalName}, Bed 204, ${selectedCampaign.hospitalCity}`
      : "Fortis Hospital Sector 44, Gurugram"
  );
  const [doctorRegInput, setDoctorRegInput] = useState<string>(
    selectedCampaign?.doctorRegNo || "MCI-34892"
  );
  const [hospitalAdmissionNo, setHospitalAdmissionNo] = useState<string>(
    `ADM-${Date.now().toString().slice(-6)}`
  );
  const [auditSummaryText, setAuditSummaryText] = useState<string>(
    `Physically visited hospital bed and met attending doctor. Original estimate letterhead verified with hospital billing counter. Aadhaar identity cross-matched in person.`
  );

  // Field Agent Uploaded Proof Photos/Documents
  const [agentUploadedFiles, setAgentUploadedFiles] = useState<
    Array<{ name: string; size: string; dataUrl: string; type: string }>
  >([
    {
      name: "hospital_bedside_audit.jpg",
      size: "1.2 MB",
      dataUrl: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600&auto=format&fit=crop&q=80",
      type: "image/jpeg",
    },
    {
      name: "official_estimate_billing_seal.jpg",
      size: "850 KB",
      dataUrl: "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=600&auto=format&fit=crop&q=80",
      type: "image/jpeg",
    },
  ]);

  const handleAgentFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const dataUrl = evt.target?.result as string;
        const formattedSize =
          file.size >= 1024 * 1024
            ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
            : `${Math.round(file.size / 1024)} KB`;

        setAgentUploadedFiles((prev) => [
          ...prev,
          {
            name: file.name,
            size: formattedSize,
            dataUrl,
            type: file.type,
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveAgentFile = (index: number) => {
    setAgentUploadedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const [auditSuccessMsg, setAuditSuccessMsg] = useState<string>("");

  if (!selectedCampaign) {
    return (
      <div className="max-w-4xl mx-auto p-8 text-center text-slate-500">
        No active campaign applications pending agent verification.
      </div>
    );
  }

  const handleGrantBadge = () => {
    const report: VerificationReport = {
      agentId,
      agentName,
      agentPhone: "+91 91234 56789",
      visitTimestamp: new Date().toLocaleString(),
      gpsLocation: {
        lat: 28.4595,
        lng: 77.0266,
        addressName: gpsAddress,
      },
      hospitalAdmissionNo,
      homeVisitCompleted: homeVisitDone,
      hospitalBedVerified: hospitalBedDone,
      doctorConfirmed: doctorConfirmedDone,
      doctorRegNo: doctorRegInput,
      auditScore: 100,
      reportSummary: auditSummaryText,
      photos: agentUploadedFiles.map((f) => f.dataUrl),
    };

    onGrantVerifiedBadge(selectedCampaign.id, report);
    setAuditSuccessMsg(`VERIFIED PATIENT BADGE granted to ${selectedCampaign.patientName}! Campaign is now live.`);
    setTimeout(() => setAuditSuccessMsg(""), 5000);
  };

  const allChecklistPassed =
    homeVisitDone &&
    hospitalBedDone &&
    doctorConfirmedDone &&
    estimateMatchedDone &&
    aadhaarVerifiedDone;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Agent Mobile Header Banner */}
      <div className="bg-white border border-slate-200 text-slate-900 p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 border border-amber-200 flex items-center justify-center">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900">{agentName}</h2>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-200">
                ACTIVE FIELD AGENT
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Agent ID: {agentId} • Region: NCR & North India • GPS Location Active
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs bg-slate-50 text-slate-700 px-4 py-2 rounded-2xl border border-slate-200 font-medium">
          <MapPin className="w-4 h-4 text-rose-600 animate-bounce" />
          <span>GPS Geotag Verified (28.4595° N, 77.0266° E)</span>
        </div>
      </div>

      {auditSuccessMsg && (
        <div className="bg-emerald-600 text-white p-4 rounded-2xl font-bold text-xs flex items-center justify-between shadow-lg animate-in fade-in">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5" />
            <span>{auditSuccessMsg}</span>
          </div>
        </div>
      )}

      {/* Main Audit Desk Grid */}
      <div className="grid lg:grid-cols-12 gap-6">
        {/* Left Column: Assigned Case Queue */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-3xl p-5 space-y-4 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between">
            <span>Assigned Verification Queue</span>
            <span className="text-xs bg-slate-100 text-slate-700 font-bold px-2 py-0.5 rounded-full">
              {campaigns.length} Cases
            </span>
          </h3>

          <div className="space-y-3 max-h-[600px] overflow-y-auto scrollbar-thin">
            {campaigns.map((c) => {
              const isSelected = c.id === selectedCampaign.id;
              return (
                <div
                  key={c.id}
                  onClick={() => setSelectedCampaignId(c.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                    isSelected
                      ? "bg-slate-900 text-white border-slate-900 shadow-md"
                      : "bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        c.verifiedBadge
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {c.verifiedBadge ? "✓ VERIFIED LIVE" : "PENDING AUDIT"}
                    </span>
                    <span className="text-[11px] opacity-70">₹{(c.requiredAmount / 100000).toFixed(1)}L Goal</span>
                  </div>

                  <h4 className="font-bold text-sm leading-tight">{c.patientName}</h4>
                  <p className="text-xs opacity-80 line-clamp-1">{c.diagnosis}</p>

                  <div className="text-[11px] opacity-70 flex items-center gap-1 pt-1">
                    <Building2 className="w-3 h-3" />
                    <span>{c.hospitalName} ({c.hospitalCity})</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Physical Verification Workstation */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-6 space-y-6 shadow-sm">
          {/* Selected Patient Header */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <img
                src={selectedCampaign.patientPhoto}
                alt={selectedCampaign.patientName}
                referrerPolicy="no-referrer"
                className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-slate-200"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-black text-slate-900">
                    {selectedCampaign.patientName}
                  </h2>
                  {selectedCampaign.verifiedBadge && (
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" /> BADGE GRANTED
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  {selectedCampaign.diagnosis} • Hospital: <strong>{selectedCampaign.hospitalName}</strong>
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Goal Amount</span>
              <span className="text-emerald-700 font-black text-base">
                ₹{(selectedCampaign?.requiredAmount ?? 0).toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          {/* Physical Verification Audit Checklist */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-emerald-600" />
              On-Site Physical Audit Checklist
            </h3>

            <div className="grid sm:grid-cols-2 gap-3 text-xs">
              <label className="bg-slate-50 border border-slate-200 p-3 rounded-2xl flex items-center gap-3 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={aadhaarVerifiedDone}
                  onChange={(e) => setAadhaarVerifiedDone(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="font-bold text-slate-800 block">Patient Govt ID / Aadhaar Matched</span>
                  <span className="text-[10px] text-slate-500">Physical card cross-checked with guardian</span>
                </div>
              </label>

              <label className="bg-slate-50 border border-slate-200 p-3 rounded-2xl flex items-center gap-3 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={hospitalBedDone}
                  onChange={(e) => setHospitalBedDone(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="font-bold text-slate-800 block">Hospital Bed / ICU Admission Verified</span>
                  <span className="text-[10px] text-slate-500">Physically visited bedside in hospital</span>
                </div>
              </label>

              <label className="bg-slate-50 border border-slate-200 p-3 rounded-2xl flex items-center gap-3 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={doctorConfirmedDone}
                  onChange={(e) => setDoctorConfirmedDone(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="font-bold text-slate-800 block">Attending Doctor Consultation</span>
                  <span className="text-[10px] text-slate-500">Doctor confirmed diagnosis & estimate</span>
                </div>
              </label>

              <label className="bg-slate-50 border border-slate-200 p-3 rounded-2xl flex items-center gap-3 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={estimateMatchedDone}
                  onChange={(e) => setEstimateMatchedDone(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="font-bold text-slate-800 block">Hospital Billing Counter Estimate Verified</span>
                  <span className="text-[10px] text-slate-500">Cross-verified cost quotation with billing desk</span>
                </div>
              </label>
            </div>
          </div>

          {/* Audit Data Inputs */}
          <div className="grid sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Hospital GPS Address & Bed No.
              </label>
              <input
                type="text"
                value={gpsAddress}
                onChange={(e) => setGpsAddress(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Doctor Registration Number
              </label>
              <input
                type="text"
                value={doctorRegInput}
                onChange={(e) => setDoctorRegInput(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Field Agent Physical Audit Summary Report
            </label>
            <textarea
              rows={3}
              value={auditSummaryText}
              onChange={(e) => setAuditSummaryText(e.target.value)}
              className="w-full p-3 text-xs border border-slate-200 rounded-xl focus:border-emerald-500"
            />
          </div>

          {/* On-Site Proof Files & Photos Uploaded */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 block">
                  On-Site Audit Photos & Proof Documents ({agentUploadedFiles.length})
                </span>
                <span className="text-[10px] text-slate-500">
                  Upload camera geotagged photos, hospital billing receipts, and signed doctor letters (Any size).
                </span>
              </div>
              <label className="cursor-pointer bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded-xl text-xs inline-flex items-center gap-1 transition-colors shadow-sm">
                <Camera className="w-3.5 h-3.5" />
                <span>Upload Proof File</span>
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf,.doc,.docx"
                  onChange={handleAgentFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {agentUploadedFiles.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {agentUploadedFiles.map((file, idx) => (
                  <div
                    key={idx}
                    className="relative group bg-white border border-slate-200 rounded-xl overflow-hidden p-1 space-y-1 text-center shadow-xs"
                  >
                    {file.type.startsWith("image/") ? (
                      <img
                        src={file.dataUrl}
                        alt={file.name}
                        className="w-full h-20 object-cover rounded-lg border border-slate-100"
                      />
                    ) : (
                      <div className="w-full h-20 bg-emerald-50 rounded-lg flex flex-col items-center justify-center text-emerald-800 p-2">
                        <FileCheck className="w-6 h-6 mb-1 text-emerald-600" />
                        <span className="text-[9px] font-bold uppercase truncate max-w-full">
                          {file.name.split('.').pop()}
                        </span>
                      </div>
                    )}
                    <div className="px-1 text-left">
                      <span className="text-[10px] font-bold text-slate-800 truncate block">
                        {file.name}
                      </span>
                      <span className="text-[9px] text-slate-400 block">{file.size}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveAgentFile(idx)}
                      className="absolute top-2 right-2 bg-rose-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] font-bold shadow hover:bg-rose-700"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-slate-400 italic">
                No proof files attached. Click "Upload Proof File" to attach photos or documents.
              </p>
            )}
          </div>

          {/* Action Button */}
          <button
            onClick={handleGrantBadge}
            disabled={!allChecklistPassed}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black py-3.5 rounded-2xl shadow-xl transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-5 h-5" />
            <span>Approve Physical Audit & Grant VERIFIED PATIENT Badge</span>
          </button>
        </div>
      </div>
    </div>
  );
};
