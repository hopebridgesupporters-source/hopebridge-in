import React, { useState } from "react";
import { PatientCampaign } from "../types";
import { 
  X, 
  ShieldCheck, 
  MapPin, 
  Building2, 
  Tv, 
  Heart, 
  Share2, 
  FileCheck2, 
  Stethoscope, 
  Clock,
  User,
  CheckCircle2,
  FileText,
  Eye,
  Download,
  ExternalLink
} from "lucide-react";

interface CampaignDetailModalProps {
  campaign: PatientCampaign | null;
  onClose: () => void;
  onWatchAd: (campaign: PatientCampaign) => void;
  onDonate: (campaign: PatientCampaign) => void;
  onShare: (campaign: PatientCampaign) => void;
}

export const CampaignDetailModal: React.FC<CampaignDetailModalProps> = ({
  campaign,
  onClose,
  onWatchAd,
  onDonate,
  onShare,
}) => {
  const [activePreviewDoc, setActivePreviewDoc] = useState<{
    title: string;
    url: string;
    type: string;
  } | null>(null);

  if (!campaign) return null;

  const percentage = Math.min(
    100,
    Math.round((campaign.collectedAmount / campaign.requiredAmount) * 100)
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white text-slate-900 rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative border border-slate-200">
        {/* Sticky Header */}
        <div className="p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between sticky top-0 bg-slate-50/95 backdrop-blur z-20">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> VERIFIED PATIENT
            </span>
            <span className="text-xs text-slate-500 font-medium">
              {campaign.hospitalName} • {campaign.hospitalCity}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {/* Patient Header Summary */}
          <div className="grid md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-4 relative rounded-2xl overflow-hidden aspect-square bg-slate-900 border">
              <img
                src={campaign.patientPhoto}
                alt={campaign.patientName}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="md:col-span-8 space-y-3">
              <div>
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
                  {campaign.category} • {campaign.patientAge} Years Old ({campaign.gender})
                </span>
                <h1 className="text-2xl font-black text-slate-900 leading-tight">
                  {campaign.patientName}
                </h1>
                <p className="text-xs text-slate-600 font-semibold mt-1">
                  {campaign.diagnosis}
                </p>
              </div>

              {/* Progress Summary */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-slate-500 text-[10px] block font-bold uppercase">Raised</span>
                    <span className="text-emerald-700 font-black text-lg">
                      ₹{(campaign?.collectedAmount ?? 0).toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 text-[10px] block font-bold uppercase">Target Goal</span>
                    <span className="text-slate-800 font-bold text-sm">
                      ₹{(campaign?.requiredAmount ?? 0).toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>

                <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden flex">
                  <div
                    style={{
                      width: `${Math.min(
                        100,
                        (((campaign?.adRevenueAmount || 0) / (campaign?.requiredAmount || 1))) * 100
                      )}%`,
                    }}
                    className="bg-purple-600 h-full"
                  />
                  <div
                    style={{
                      width: `${Math.min(
                        100,
                        (((campaign?.directDonationAmount || 0) / (campaign?.requiredAmount || 1))) * 100
                      )}%`,
                    }}
                    className="bg-emerald-500 h-full"
                  />
                </div>

                <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                  <span className="text-purple-700 font-bold">
                    Ad Pool: ₹{((campaign?.adRevenueAmount || 0) / 100000).toFixed(1)}L ({(campaign?.adWatchCount ?? 0).toLocaleString()} ads)
                  </span>
                  <span className="font-bold text-slate-800">{percentage}% Goal Achieved</span>
                </div>
              </div>

              {/* Action Buttons Row */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  onClick={() => {
                    onClose();
                    onWatchAd(campaign);
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow"
                >
                  <Tv className="w-4 h-4" />
                  <span>Watch Ads to Support</span>
                </button>

                <button
                  onClick={() => {
                    onClose();
                    onDonate(campaign);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow"
                >
                  <Heart className="w-4 h-4 fill-current" />
                  <span>Donate</span>
                </button>

                <button
                  onClick={() => onShare(campaign)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 border"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Share</span>
                </button>
              </div>
            </div>
          </div>

          {/* Field Verification Certificate Block */}
          {campaign.verificationReport && (
            <div className="bg-emerald-50 border border-emerald-200 p-5 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileCheck2 className="w-5 h-5 text-emerald-700" />
                  <h3 className="font-bold text-emerald-950 text-sm">
                    On-Site Physical Verification Certificate
                  </h3>
                </div>
                <span className="bg-emerald-200 text-emerald-950 font-bold text-[10px] px-2 py-0.5 rounded">
                  GPS Audit 100% Passed
                </span>
              </div>

              <p className="text-xs text-emerald-900 leading-relaxed">
                "{campaign.verificationReport.reportSummary}"
              </p>

              <div className="grid sm:grid-cols-3 gap-2 text-[11px] text-emerald-800 border-t border-emerald-200/80 pt-2 font-medium">
                <div>
                  Field Agent: <strong>{campaign.verificationReport.agentName.split("(")[0]}</strong>
                </div>
                <div>
                  Attending Doctor: <strong>{campaign.doctorName}</strong> ({campaign.doctorRegNo})
                </div>
                <div>
                  Verified Date: <strong>{campaign.verificationReport.visitTimestamp}</strong>
                </div>
              </div>
            </div>
          )}

          {/* Patient Story */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-slate-900">Patient Journey & Background Story</h3>
            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50 p-4 rounded-2xl border border-slate-100">
              {campaign.story}
            </p>
          </div>

          {/* Treatment Cost Quotation Breakdown */}
          {campaign.treatmentBreakdown && campaign.treatmentBreakdown.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-900">
                Hospital Cost Estimate Breakdown
              </h3>
              <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-3">Item / Service</th>
                      <th className="p-3">Category</th>
                      <th className="p-3 text-right">Cost (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-800">
                    {campaign.treatmentBreakdown.map((item) => (
                      <tr key={item.id}>
                        <td className="p-3 font-semibold">{item.name}</td>
                        <td className="p-3 text-slate-500">{item.category}</td>
                        <td className="p-3 text-right font-bold font-mono">
                          ₹{(item?.cost ?? 0).toLocaleString("en-IN")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Uploaded Documents & Verified Medical Records */}
          {campaign.documents && campaign.documents.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  Uploaded Identity & Medical Records ({campaign.documents.length})
                </h3>
                <span className="text-[10px] text-slate-400 font-medium">
                  Verified & Stored in Database
                </span>
              </div>

              <div className="grid sm:grid-cols-2 gap-3 text-xs">
                {campaign.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-2 hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                        {doc.type.slice(0, 3).toUpperCase()}
                      </div>
                      <div className="truncate">
                        <span className="font-bold text-slate-800 block truncate">{doc.title}</span>
                        <span className="text-[10px] text-slate-400 block">
                          {doc.uploadDate} {doc.notes ? `• ${doc.notes}` : ""}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        setActivePreviewDoc({
                          title: doc.title,
                          url: doc.fileDataUrl || doc.url,
                          type: doc.type,
                        })
                      }
                      className="shrink-0 text-xs font-bold text-emerald-700 hover:text-emerald-900 bg-white border border-slate-200 hover:bg-emerald-50 px-2.5 py-1.5 rounded-xl transition-colors flex items-center gap-1 shadow-2xs"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Patient Official Bank Details & QR Code Block */}
          {campaign.paymentDetails && (
            <div className="bg-slate-900 text-white rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <h3 className="font-bold text-xs text-slate-100">Patient QR Code & Bank Account Details</h3>
                </div>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
                  Direct Escrow
                </span>
              </div>

              <div className="grid sm:grid-cols-3 gap-3 items-center text-xs">
                {/* QR Code */}
                <div className="bg-white p-2 rounded-xl text-center flex flex-col items-center justify-center border border-slate-700 shrink-0">
                  <img
                    src={campaign.paymentDetails.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${encodeURIComponent(campaign.paymentDetails.upiId || 'patient@upi')}&pn=${encodeURIComponent(campaign.patientName)}&cu=INR`}
                    alt="Scan & Donate QR"
                    className="w-24 h-24 object-contain"
                  />
                  <span className="text-[9px] font-bold text-slate-700 mt-1">Scan via PhonePe / GPay</span>
                </div>

                {/* Account details */}
                <div className="sm:col-span-2 space-y-1.5">
                  {campaign.paymentDetails.upiId && (
                    <div className="bg-slate-800/80 p-2 rounded-lg flex items-center justify-between border border-slate-700">
                      <div>
                        <span className="text-[9px] text-slate-400 block uppercase">UPI ID</span>
                        <span className="font-mono text-xs font-bold text-emerald-400">{campaign.paymentDetails.upiId}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => navigator.clipboard?.writeText?.(campaign.paymentDetails?.upiId || "")}
                        className="bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-bold px-2 py-1 rounded"
                      >
                        Copy
                      </button>
                    </div>
                  )}

                  {campaign.paymentDetails.accountNumber && (
                    <div className="bg-slate-800/80 p-2 rounded-lg flex items-center justify-between border border-slate-700">
                      <div>
                        <span className="text-[9px] text-slate-400 block uppercase">A/C No ({campaign.paymentDetails.bankName || "Hospital Bank"})</span>
                        <span className="font-mono text-xs font-bold text-amber-300">{campaign.paymentDetails.accountNumber}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => navigator.clipboard?.writeText?.(campaign.paymentDetails?.accountNumber || "")}
                        className="bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-bold px-2 py-1 rounded"
                      >
                        Copy
                      </button>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-1.5 text-[10px] text-slate-300">
                    <div className="bg-slate-800/50 p-1.5 rounded border border-slate-700/60">
                      <span className="text-slate-400 block text-[9px]">IFSC CODE</span>
                      <span className="font-mono font-bold text-slate-200">{campaign.paymentDetails.ifscCode || 'UTIB0000812'}</span>
                    </div>
                    <div className="bg-slate-800/50 p-1.5 rounded border border-slate-700/60 truncate">
                      <span className="text-slate-400 block text-[9px]">A/C HOLDER</span>
                      <span className="font-bold text-slate-200 truncate block">{campaign.paymentDetails.accountHolderName || campaign.patientName}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Donor Message Wall */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900">
              Supporters & Community Messages ({campaign.donorList?.length || 0})
            </h3>
            <div className="space-y-2 max-h-56 overflow-y-auto scrollbar-thin">
              {campaign.donorList?.map((d) => (
                <div key={d.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
                  <div className="flex justify-between items-center font-bold">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-900">{d.name}</span>
                      {d.transactionId && (
                        <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-200 font-mono font-bold px-1.5 py-0.5 rounded">
                          {d.transactionId}
                        </span>
                      )}
                    </div>
                    <span className="text-emerald-700 font-mono font-black text-sm">₹{(d?.amount ?? 0).toLocaleString("en-IN")}</span>
                  </div>
                  {d.message && <p className="text-slate-700 text-[11px] italic">"{d.message}"</p>}
                  
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                    <span>{d.timestamp} {d.paymentMode ? `• via ${d.paymentMode}` : ""}</span>
                    {d.paymentProofUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          setActivePreviewDoc({
                            title: `Payment Proof (${d.name})`,
                            url: d.paymentProofUrl!,
                            type: "Payment Screenshot",
                          })
                        }
                        className="text-amber-800 font-bold hover:underline flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3 text-amber-600" />
                        <span>View Proof</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Document Full View Modal */}
      {activePreviewDoc && (
        <div className="fixed inset-0 z-60 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-4 shadow-2xl relative border border-slate-200">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded uppercase">
                  {activePreviewDoc.type} Document
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {activePreviewDoc.title}
                </h3>
              </div>
              <button
                onClick={() => setActivePreviewDoc(null)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[65vh] overflow-auto rounded-2xl border border-slate-200 bg-slate-900 flex items-center justify-center p-2 min-h-[250px]">
              {activePreviewDoc.url && (activePreviewDoc.url.startsWith("data:image/") || activePreviewDoc.url.startsWith("http")) ? (
                <img
                  src={activePreviewDoc.url}
                  alt={activePreviewDoc.title}
                  className="max-h-[60vh] max-w-full object-contain rounded-xl"
                />
              ) : activePreviewDoc.url && activePreviewDoc.url.startsWith("data:application/pdf") ? (
                <iframe
                  src={activePreviewDoc.url}
                  title={activePreviewDoc.title}
                  className="w-full h-[55vh] rounded-xl bg-white"
                />
              ) : (
                <div className="text-center p-8 text-white space-y-3">
                  <FileText className="w-12 h-12 text-emerald-400 mx-auto" />
                  <p className="text-xs font-semibold">
                    Document File Stored in Patient Verification Vault
                  </p>
                  <a
                    href={activePreviewDoc.url}
                    download={activePreviewDoc.title}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Raw File</span>
                  </a>
                </div>
              )}
            </div>

            <div className="flex justify-between items-center text-xs text-slate-500 pt-1">
              <span>Status: Digitally Verified & Hashed</span>
              {activePreviewDoc.url && (
                <a
                  href={activePreviewDoc.url}
                  download={activePreviewDoc.title}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-700 hover:underline font-bold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Document</span>
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
