import React, { useState } from "react";
import { Mail, Check, Copy, ExternalLink, MessageSquareHeart } from "lucide-react";

interface ContactSectionProps {
  className?: string;
  variant?: "card" | "full" | "compact";
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  className = "",
  variant = "card",
}) => {
  const [copied, setCopied] = useState(false);
  const officialEmail = "hopebridgesupporters@gmail.com";

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(officialEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (variant === "compact") {
    return (
      <div className={`bg-teal-50/70 border border-teal-100 rounded-2xl p-4 sm:p-5 ${className}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-sm">
            <Mail className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-bold uppercase tracking-wider text-teal-900">
              Contact Us
            </h4>
            <a
              href={`mailto:${officialEmail}`}
              className="text-sm font-bold text-teal-800 hover:text-teal-950 transition-colors truncate block underline decoration-teal-300 underline-offset-4"
            >
              {officialEmail}
            </a>
          </div>
          <button
            onClick={handleCopy}
            className="p-2 bg-white hover:bg-teal-100 text-teal-700 rounded-lg border border-teal-200 transition-colors cursor-pointer shrink-0 text-xs font-semibold flex items-center gap-1"
            title="Copy email address"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>
    );
  }

  return (
    <section className={`bg-gradient-to-b from-slate-50 to-teal-50/30 border border-slate-200/80 rounded-3xl p-6 sm:p-8 ${className}`}>
      <div className="max-w-3xl mx-auto space-y-6 text-center sm:text-left">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-800 text-white flex items-center justify-center shrink-0 shadow-md shadow-teal-800/20">
            <Mail className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-teal-100/80 text-teal-800 text-xs font-bold border border-teal-200">
              <MessageSquareHeart className="w-3.5 h-3.5 text-teal-600" />
              <span>Official Support Channel</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Contact Us
            </h2>
            <p className="text-sm text-slate-600 font-medium max-w-xl">
              Have questions regarding patient verification, campaign donations, or platform support? Get in touch with our team.
            </p>
          </div>
        </div>

        {/* Email Highlight Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 w-full sm:w-auto">
            <div className="w-11 h-11 rounded-xl bg-teal-50 text-teal-700 border border-teal-100 flex items-center justify-center shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Official Support Email
              </span>
              <a
                href={`mailto:${officialEmail}`}
                className="text-base sm:text-lg font-bold text-teal-900 hover:text-teal-700 transition-colors break-all sm:break-normal flex items-center gap-1.5 group"
              >
                <span>{officialEmail}</span>
                <ExternalLink className="w-4 h-4 text-teal-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0 justify-end">
            <a
              href={`mailto:${officialEmail}`}
              className="flex-1 sm:flex-none px-5 py-2.5 bg-teal-800 hover:bg-teal-900 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Mail className="w-4 h-4" />
              <span>Send Email</span>
            </a>

            <button
              onClick={handleCopy}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
              title="Copy email to clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-500" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Operational Note */}
        <p className="text-[11px] text-slate-500 text-center sm:text-left pt-1">
          ✓ Verified emails are monitored by HopeBridge platform compliance officers.
        </p>

      </div>
    </section>
  );
};
