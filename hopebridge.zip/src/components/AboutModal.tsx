import React, { useState, useEffect } from "react";
import { X, ShieldCheck, FileText, Info, Lock } from "lucide-react";
import { HopeBridgeLogo } from "./HopeBridgeLogo";
import { ContactSection } from "./ContactSection";

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: "about" | "terms" | "privacy";
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose, defaultTab = "about" }) => {
  const [activeTab, setActiveTab] = useState<"about" | "terms" | "privacy">(defaultTab);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(defaultTab);
    }
  }, [isOpen, defaultTab]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 overflow-y-auto">
      {/* Backdrop - Click outside to close */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Container */}
      <div className="relative w-full sm:max-w-3xl bg-white min-h-screen sm:min-h-0 sm:max-h-[90vh] sm:rounded-3xl shadow-2xl flex flex-col z-10 overflow-hidden animate-in fade-in zoom-in-95 duration-200 border-0">
        
        {/* Sticky Top Bar with Close Button & Nav Tabs */}
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 z-20">
          <div className="flex items-center gap-3">
            <HopeBridgeLogo 
              size="sm" 
              layout="horizontal" 
              onClick={onClose} 
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl w-full sm:w-auto border-0">
            <button
              onClick={() => setActiveTab("about")}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border-0 cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === "about"
                  ? "bg-teal-700 text-white shadow-sm"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Info className="w-3.5 h-3.5" />
              <span>About Us</span>
            </button>

            <button
              onClick={() => setActiveTab("terms")}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border-0 cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === "terms"
                  ? "bg-teal-700 text-white shadow-sm"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Terms & Conditions</span>
            </button>

            <button
              onClick={() => setActiveTab("privacy")}
              className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border-0 cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === "privacy"
                  ? "bg-teal-700 text-white shadow-sm"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Privacy Policy</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors focus:outline-none cursor-pointer border-0 absolute top-3 right-3 sm:static"
            aria-label="Close Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-8 bg-white text-slate-800">
          
          {/* TAB 1: ABOUT HOPEBRIDGE */}
          {activeTab === "about" && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="text-center space-y-3 pb-2 border-b border-slate-100">
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  ABOUT HOPEBRIDGE
                </h2>
                <p className="text-sm sm:text-base font-semibold text-teal-700 tracking-wide">
                  Connecting Hearts • Restoring Hope • Saving Lives
                </p>
                <p className="text-slate-600 text-sm leading-relaxed max-w-xl mx-auto pt-2 font-normal">
                  HopeBridge is a trusted medical fundraising platform that helps verified patients receive life-saving treatment through community support, transparent fundraising, and responsible technology.
                </p>
              </div>

              {/* Mission & Vision Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="bg-slate-50 p-5 rounded-2xl space-y-3 border-0">
                  <div className="flex items-center gap-2 text-teal-800 font-bold text-base border-b border-slate-200/60 pb-2">
                    <span className="text-teal-600 text-lg">◈</span>
                    <h3>Our Mission</h3>
                  </div>
                  <ul className="space-y-2.5 text-xs sm:text-sm text-slate-700 font-medium">
                    <li className="flex items-center gap-2.5">
                      <span className="text-teal-600 font-bold shrink-0">◈</span>
                      <span>Support Verified Patients</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <span className="text-teal-600 font-bold shrink-0">✦</span>
                      <span>Build Trust Through Transparency</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <span className="text-teal-600 font-bold shrink-0">◉</span>
                      <span>Connect Compassionate People</span>
                    </li>
                    <li className="flex items-center gap-2.5">
                      <span className="text-teal-600 font-bold shrink-0">✧</span>
                      <span>Help Save More Lives</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-slate-50 p-5 rounded-2xl space-y-3 border-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-teal-800 font-bold text-base border-b border-slate-200/60 pb-2">
                      <span className="text-teal-600 text-lg">⟡</span>
                      <h3>Our Vision</h3>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed pt-3">
                      To ensure that no patient loses hope because of financial limitations.
                    </p>
                  </div>
                  <div className="pt-4 border-t border-slate-200/40 text-xs text-slate-500 font-medium flex items-center gap-1.5">
                    <span className="text-teal-600 font-bold">✪</span>
                    <span>Equal healthcare access for every family</span>
                  </div>
                </div>
              </div>

              {/* Why HopeBridge? */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-slate-900 font-extrabold text-lg border-b border-slate-100 pb-2">
                  <span className="text-teal-700">❖</span>
                  <h3>Why HopeBridge?</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 border-0">
                    <span className="text-teal-600 font-bold text-base">◈</span>
                    <span>Verified Patients</span>
                  </div>
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 border-0">
                    <span className="text-teal-600 font-bold text-base">✦</span>
                    <span>Transparent Fund Tracking</span>
                  </div>
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 border-0">
                    <span className="text-teal-600 font-bold text-base">◉</span>
                    <span>Secure Platform</span>
                  </div>
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 border-0">
                    <span className="text-teal-600 font-bold text-base">✧</span>
                    <span>Trusted Community</span>
                  </div>
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 border-0">
                    <span className="text-teal-600 font-bold text-base">⬢</span>
                    <span>Hospital Partnerships</span>
                  </div>
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 border-0">
                    <span className="text-teal-600 font-bold text-base">❖</span>
                    <span>Privacy & Security</span>
                  </div>
                </div>
              </div>

              {/* Our Promise */}
              <div className="bg-teal-50/70 rounded-2xl p-6 text-center space-y-3 border-0">
                <h4 className="text-xs font-bold uppercase tracking-wider text-teal-800">
                  Our Promise
                </h4>
                <blockquote className="text-sm sm:text-base font-semibold text-slate-800 italic">
                  "Every life deserves hope. Every act of kindness creates a new beginning."
                </blockquote>
                <p className="text-xs sm:text-sm font-bold text-teal-900 pt-2 border-t border-teal-100/80">
                  HopeBridge — Building Bridges of Hope, One Life at a Time.
                </p>
              </div>

              {/* Contact Us Section */}
              <ContactSection variant="card" />
            </div>
          )}

          {/* TAB 2: TERMS AND CONDITIONS */}
          {activeTab === "terms" && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-slate-100 pb-4">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                  HopeBridge – Terms and Conditions
                </h2>
                <p className="text-xs text-slate-500 font-semibold mt-1">
                  Effective Date: July 25, 2026
                </p>
              </div>

              <div className="space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">1. Acceptance of Terms</h3>
                  <p>By accessing or using the HopeBridge website or mobile application ("Platform"), you agree to these Terms and Conditions. If you do not agree, you must not use the Platform.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">2. About HopeBridge</h3>
                  <p>HopeBridge is a technology platform that enables verified medical fundraising through voluntary donations, advertisement-supported fundraising (where permitted), campaign sharing, and partnerships with hospitals, NGOs, and organizations. HopeBridge is not a hospital, insurance provider, or medical treatment provider.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">3. Eligibility</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Users must be at least 18 years old or use the Platform through a parent or legal guardian.</li>
                    <li>All information provided must be accurate and complete.</li>
                    <li>Fake identities or fraudulent accounts are prohibited.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">4. Patient Verification</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Patients must submit genuine identity and medical documents.</li>
                    <li>HopeBridge may verify information with hospitals, doctors, government records, or authorized verification agents.</li>
                    <li>Physical verification may be conducted when required.</li>
                    <li>HopeBridge reserves the right to reject, suspend, or remove any campaign if verification fails or fraud is suspected.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">5. Fundraising</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Only verified patient campaigns may be published.</li>
                    <li>Funds are intended solely for the approved medical purpose.</li>
                    <li>Misuse of funds may result in campaign suspension, legal action, and recovery of funds where permitted by law.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">6. Donations</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Donations are voluntary and generally non-refundable unless required by applicable law.</li>
                    <li>Donors should verify campaign details before donating.</li>
                    <li>HopeBridge does not guarantee treatment outcomes or patient recovery.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">7. Advertisement-Based Support</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Advertisement-supported fundraising is subject to the policies of the advertising network.</li>
                    <li>Revenue generated from advertisements is variable and cannot be guaranteed.</li>
                    <li>Invalid activity, artificial traffic, bots, or attempts to manipulate advertisement revenue are strictly prohibited.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">8. Revenue Distribution</h3>
                  <p>HopeBridge may allocate platform revenue among patient support, operational expenses, verification, payment processing, and administration according to its published policies. Distribution percentages may change to ensure sustainability and legal compliance.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">9. Transparency</h3>
                  <p>HopeBridge aims to display fundraising progress and campaign information transparently. Administrative corrections may be made if errors are identified.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">10. User Responsibilities</h3>
                  <p>Users agree to:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Provide truthful information.</li>
                    <li>Respect other users.</li>
                    <li>Not upload illegal, offensive, or misleading content.</li>
                    <li>Not attempt to hack, abuse, or disrupt the Platform.</li>
                    <li>Comply with all applicable laws.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">11. Privacy</h3>
                  <p>Medical and personal information will be handled in accordance with the HopeBridge Privacy Policy and applicable data protection laws. Sensitive information will be collected only as necessary for verification and platform operations.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">12. Hospital and Partner Responsibilities</h3>
                  <p>Hospitals, NGOs, verification agents, and other partners must provide accurate information. False certifications or misleading information may result in removal from the Platform and legal action where applicable.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">13. Fraud Prevention</h3>
                  <p>HopeBridge may investigate suspected fraud, suspend accounts, remove campaigns, cooperate with law enforcement, and take other appropriate actions to protect users and the Platform.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">14. Intellectual Property</h3>
                  <p>All HopeBridge logos, trademarks, software, content, and branding are the property of HopeBridge or its licensors. Unauthorized copying, distribution, or commercial use is prohibited.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">15. Limitation of Liability</h3>
                  <p>HopeBridge provides the Platform on an "as is" and "as available" basis. To the fullest extent permitted by law, HopeBridge is not liable for treatment outcomes, medical decisions, delays, third-party services, or indirect or consequential damages.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">16. Third-Party Services</h3>
                  <p>The Platform may use third-party services including payment gateways, authentication providers, advertising networks, cloud services, analytics, and notification providers. Their separate terms and privacy policies also apply.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">17. Account Suspension</h3>
                  <p>HopeBridge may suspend or terminate any account that violates these Terms, engages in fraud, abuses the Platform, or poses a security risk.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">18. Changes to These Terms</h3>
                  <p>HopeBridge may update these Terms and Conditions at any time. Continued use of the Platform after changes become effective constitutes acceptance of the revised Terms.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">19. Governing Law</h3>
                  <p>These Terms shall be governed by the laws of India. Any disputes shall be subject to the jurisdiction of the competent courts in India.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">20. Contact Us</h3>
                  <p>For questions regarding these Terms and Conditions, please contact:</p>
                  <p className="font-semibold text-teal-800">HopeBridge Support<br />Email: hopebridgesupporters@gmail.com</p>
                </section>
              </div>
            </div>
          )}

          {/* TAB 3: PRIVACY POLICY */}
          {activeTab === "privacy" && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-slate-100 pb-4">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                  HopeBridge – Privacy Policy
                </h2>
                <p className="text-xs text-slate-500 font-semibold mt-1">
                  Effective Date: July 25, 2026
                </p>
              </div>

              <div className="space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">1. Introduction</h3>
                  <p>HopeBridge ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, store, share, and protect your personal information when you use the HopeBridge website or mobile application.</p>
                  <p>By using HopeBridge, you agree to this Privacy Policy.</p>
                </section>

                <section className="space-y-2">
                  <h3 className="font-bold text-slate-900 text-sm">2. Information We Collect</h3>
                  
                  <div className="space-y-1 bg-slate-50 p-3 rounded-xl border-0">
                    <span className="font-bold text-teal-800 block text-xs">Personal Information:</span>
                    <ul className="list-disc pl-5 space-y-0.5">
                      <li>Full Name</li>
                      <li>Date of Birth</li>
                      <li>Mobile Number</li>
                      <li>Email Address</li>
                      <li>Residential Address</li>
                      <li>Government-issued ID (such as Aadhaar or other accepted ID, where permitted)</li>
                      <li>Guardian information (if applicable)</li>
                      <li>Emergency contact details</li>
                    </ul>
                  </div>

                  <div className="space-y-1 bg-slate-50 p-3 rounded-xl border-0">
                    <span className="font-bold text-teal-800 block text-xs">Medical Information:</span>
                    <ul className="list-disc pl-5 space-y-0.5">
                      <li>Medical certificates</li>
                      <li>Diagnosis reports</li>
                      <li>Doctor prescriptions</li>
                      <li>Hospital estimates</li>
                      <li>Treatment updates</li>
                      <li>Medicine bills</li>
                      <li>Hospital details</li>
                      <li>Doctor information</li>
                    </ul>
                  </div>

                  <div className="space-y-1 bg-slate-50 p-3 rounded-xl border-0">
                    <span className="font-bold text-teal-800 block text-xs">Account Information:</span>
                    <ul className="list-disc pl-5 space-y-0.5">
                      <li>Username</li>
                      <li>Password (stored securely in encrypted form or managed through a secure authentication provider)</li>
                      <li>Login history</li>
                      <li>Device information</li>
                    </ul>
                  </div>

                  <div className="space-y-1 bg-slate-50 p-3 rounded-xl border-0">
                    <span className="font-bold text-teal-800 block text-xs">Technical Information:</span>
                    <ul className="list-disc pl-5 space-y-0.5">
                      <li>IP address</li>
                      <li>Browser type</li>
                      <li>Device type</li>
                      <li>Operating system</li>
                      <li>App version</li>
                      <li>Cookies and similar technologies</li>
                      <li>Analytics information</li>
                    </ul>
                  </div>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">3. How We Use Your Information</h3>
                  <p>We may use your information to:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Verify patient identity and eligibility.</li>
                    <li>Review and approve fundraising campaigns.</li>
                    <li>Process donations and payments.</li>
                    <li>Display verified campaign information.</li>
                    <li>Prevent fraud and misuse.</li>
                    <li>Improve our services.</li>
                    <li>Respond to customer support requests.</li>
                    <li>Comply with legal obligations.</li>
                  </ul>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">4. Information Sharing</h3>
                  <p>We may share information with:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Hospitals for verification.</li>
                    <li>Authorized verification agents.</li>
                    <li>Payment service providers.</li>
                    <li>Cloud hosting providers.</li>
                    <li>Government authorities or law enforcement when legally required.</li>
                    <li>Trusted service providers that support platform operations.</li>
                  </ul>
                  <p className="font-semibold text-teal-800 pt-1">We do not sell your personal information to third parties.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">5. Public Campaign Information</h3>
                  <p>When a campaign is approved, certain information may be publicly displayed, including:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Patient name (or initials where appropriate)</li>
                    <li>Disease or medical condition</li>
                    <li>Hospital name</li>
                    <li>Fundraising goal</li>
                    <li>Amount raised</li>
                    <li>Treatment updates</li>
                    <li>Campaign images or videos provided for fundraising</li>
                  </ul>
                  <p>Sensitive personal information will not be published unless necessary and authorized.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">6. Data Security</h3>
                  <p>We use reasonable technical and organizational measures to help protect your information, including:</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Encryption where appropriate.</li>
                    <li>Secure cloud storage.</li>
                    <li>Access controls.</li>
                    <li>Authentication and authorization.</li>
                    <li>Security monitoring and audit logs.</li>
                  </ul>
                  <p className="text-slate-500 italic">No internet-based system can guarantee absolute security.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">7. Data Retention</h3>
                  <p>We retain information only for as long as necessary to operate the Platform, meet legal requirements, resolve disputes, and prevent fraud.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">8. Your Rights</h3>
                  <p>Subject to applicable law, you may have the right to access, correct, or request deletion of eligible information, withdraw consent, or contact us regarding privacy concerns.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">9. Children's Privacy</h3>
                  <p>If a patient is under 18 years of age, a parent or legal guardian must manage the account and provide the required consent where applicable.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">10. Cookies and Analytics</h3>
                  <p>HopeBridge may use cookies and analytics tools to improve user experience, measure performance, enhance security, and understand platform usage.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">11. Third-Party Services</h3>
                  <p>HopeBridge may use third-party services such as payment gateways, authentication providers, cloud hosting, analytics, and advertising partners. Their separate terms apply.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">12. Policy Updates</h3>
                  <p>We may update this Privacy Policy from time to time. Changes become effective when published on the Platform.</p>
                </section>

                <section className="space-y-1">
                  <h3 className="font-bold text-slate-900 text-sm">13. Contact Us</h3>
                  <p>If you have questions about this Privacy Policy or your personal information, contact:</p>
                  <p className="font-semibold text-teal-800">HopeBridge Support<br />Email: hopebridgesupporters@gmail.com</p>
                </section>
              </div>
            </div>
          )}

        </div>

        {/* Footer Close Bar */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors shadow-sm cursor-pointer border-0"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

