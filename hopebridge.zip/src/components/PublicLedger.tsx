import React, { useState } from "react";
import { TransparencyLedgerEntry } from "../types";
import { 
  FileText, 
  Download, 
  Search, 
  CheckCircle2, 
  Lock, 
  ShieldCheck, 
  Tv, 
  Heart,
  Building2,
  ExternalLink
} from "lucide-react";

interface PublicLedgerProps {
  ledger: TransparencyLedgerEntry[];
}

export const PublicLedger: React.FC<PublicLedgerProps> = ({ ledger }) => {
  const [filterType, setFilterType] = useState<string>("ALL");
  const [searchTerm, setSearchTerm] = useState<string>("");

  const filtered = ledger.filter((entry) => {
    const matchesType = filterType === "ALL" ? true : entry.type === filterType;
    const term = searchTerm.toLowerCase();
    const matchesSearch =
      !term ||
      entry.patientName.toLowerCase().includes(term) ||
      entry.transactionHash.toLowerCase().includes(term) ||
      (entry.sponsorName && entry.sponsorName.toLowerCase().includes(term));

    return matchesType && matchesSearch;
  });

  const handleDownloadCsv = () => {
    const headers = "Transaction Hash,Timestamp,Patient Name,Type,Gross Amount (₹),95% Patient Fund (₹),3% Ops (₹),2% Admin (₹)\n";
    const rows = filtered
      .map(
        (e) =>
          `"${e.transactionHash}","${e.timestamp}","${e.patientName}","${e.type}",${e.grossAmount},${e.patientFund95},${e.ops3},${e.admin2}`
      )
      .join("\n");

    const blob = new Blob([headers + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `HopeBridge_Public_Ledger_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 text-slate-900 p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-cyan-100 text-cyan-700 border border-cyan-200 flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">100% Public Financial Audit Ledger</h2>
            <p className="text-xs text-slate-500">
              Every rupee received from Rewarded Ads & Direct Donations is immutably logged
            </p>
          </div>
        </div>

        <button
          onClick={handleDownloadCsv}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center gap-2 shadow-sm transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export Ledger as CSV</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white border border-slate-200 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1 text-xs">
          {["ALL", "AD_REVENUE", "DIRECT_DONATION", "HOSPITAL_DISBURSAL"].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                filterType === type
                  ? "bg-slate-900 text-white shadow"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              {type === "ALL" && "All Transactions"}
              {type === "AD_REVENUE" && "🎬 Ad Revenue Settlement"}
              {type === "DIRECT_DONATION" && "💳 Direct Donations"}
              {type === "HOSPITAL_DISBURSAL" && "🏥 Hospital Disbursals"}
            </button>
          ))}
        </div>

        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search hash, patient, sponsor..."
            className="w-full text-xs pl-9 pr-3 py-1.5 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Public Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="p-3.5">Transaction Hash & Date</th>
                <th className="p-3.5">Patient Campaign</th>
                <th className="p-3.5">Type & Source</th>
                <th className="p-3.5 text-right">Gross Amount</th>
                <th className="p-3.5 text-right text-emerald-700">95% Patient Fund</th>
                <th className="p-3.5 text-right text-amber-700">3% Field Ops</th>
                <th className="p-3.5 text-right text-slate-500">2% Admin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {filtered.map((entry) => (
                <tr key={entry.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3.5 font-mono">
                    <span className="font-bold block text-slate-900">{entry.transactionHash}</span>
                    <span className="text-[10px] text-slate-400">{entry.timestamp}</span>
                  </td>

                  <td className="p-3.5 font-bold text-slate-900">
                    {entry.patientName}
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[10px] ${
                        entry.type === "AD_REVENUE"
                          ? "bg-purple-100 text-purple-800"
                          : entry.type === "DIRECT_DONATION"
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-cyan-100 text-cyan-800"
                      }`}
                    >
                      {entry.type === "AD_REVENUE" && <Tv className="w-3 h-3" />}
                      {entry.type === "DIRECT_DONATION" && <Heart className="w-3 h-3" />}
                      {entry.type === "HOSPITAL_DISBURSAL" && <Building2 className="w-3 h-3" />}
                      {entry.type}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">
                      {entry.sponsorName} ({entry.paymentMode})
                    </span>
                  </td>

                  <td className="p-3.5 text-right font-bold font-mono text-slate-900">
                    ₹{(entry?.grossAmount ?? 0).toLocaleString("en-IN")}
                  </td>

                  <td className="p-3.5 text-right font-black font-mono text-emerald-700 bg-emerald-50/50">
                    ₹{(entry?.patientFund95 ?? 0).toLocaleString("en-IN")}
                  </td>

                  <td className="p-3.5 text-right font-mono text-amber-700">
                    ₹{(entry?.ops3 ?? 0).toLocaleString("en-IN")}
                  </td>

                  <td className="p-3.5 text-right font-mono text-slate-500">
                    ₹{(entry?.admin2 ?? 0).toLocaleString("en-IN")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
