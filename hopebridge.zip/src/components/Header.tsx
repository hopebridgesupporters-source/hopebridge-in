import React, { useState } from "react";
import { HopeBridgeLogo } from "./HopeBridgeLogo";
import { InspirationTicker } from "./InspirationTicker";
import { 
  ShieldCheck, 
  Tv, 
  HeartHandshake, 
  UserCheck, 
  Building2, 
  ShieldAlert, 
  FileText, 
  Sparkles,
  Search,
  CheckCircle2,
  Lock,
  Menu,
  X,
  ChevronRight,
  Info,
  LogOut,
  User,
  Mail
} from "lucide-react";

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  totalAdRevenue: number;
  totalDirectDonations: number;
  totalAdsWatched: number;
  verifiedCount: number;
  userImpactPoints: number;
  onOpenAbout: () => void;
  currentUser: any;
  onOpenLogin: () => void;
  onLogout: () => void;
  onOpenSuperAdmin: () => void;
  onOpenWelcome?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  searchQuery,
  setSearchQuery,
  totalAdRevenue,
  totalDirectDonations,
  totalAdsWatched,
  verifiedCount,
  userImpactPoints,
  onOpenAbout,
  currentUser,
  onOpenLogin,
  onLogout,
  onOpenSuperAdmin,
  onOpenWelcome
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const totalRaised = (totalAdRevenue || 0) + (totalDirectDonations || 0);

  const navItems = [
    {
      id: "supporter",
      title: "Support Patients",
      subtitle: "Watch 15s ads to direct 95% revenue to patient hospital bills",
      icon: HeartHandshake,
      badge: `${verifiedCount} Live`,
      badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200"
    },
    {
      id: "register",
      title: "Apply for Patient Aid",
      subtitle: "Submit a new patient case for verified ad fundraising",
      icon: Tv,
      badge: "Free Aid",
      badgeColor: "bg-blue-100 text-blue-800 border-blue-200"
    },
    {
      id: "agent",
      title: "Field Agent Desk",
      subtitle: "GPS geotagged bedside & doctor verification audit",
      icon: UserCheck,
      badge: "Audit Portal",
      badgeColor: "bg-amber-100 text-amber-800 border-amber-200"
    },
    {
      id: "hospital",
      title: "Hospital & NGO Portal",
      subtitle: "Direct hospital desk escrow & zero-leakage bill settlement",
      icon: Building2,
      badge: "Verified Escrow",
      badgeColor: "bg-teal-100 text-teal-800 border-teal-200"
    },
    {
      id: "admin",
      title: "Admin & Fraud Guard",
      subtitle: "AI ad fraud detection & platform financial governance",
      icon: ShieldAlert,
      badge: "Platform Control",
      badgeColor: "bg-slate-100 text-slate-800 border-slate-200"
    },
    {
      id: "ledger",
      title: "Public Audit Ledger",
      subtitle: "100% public transparent financial logs & CSV export",
      icon: FileText,
      badge: "100% Open Data",
      badgeColor: "bg-cyan-100 text-cyan-800 border-cyan-200"
    },
    {
      id: "ai_guidance",
      title: "AI Health & Schemes Helper",
      subtitle: "Find government funds (Ayushman Bharat, RAN, CMRF)",
      icon: Sparkles,
      badge: "AI Powered",
      badgeColor: "bg-purple-100 text-purple-800 border-purple-200"
    }
  ];

  // Filter navigation items based on current user's role
  const getRoleFilteredNavItems = () => {
    if (!currentUser) {
      return navItems.filter((i) => ["supporter", "register", "ledger", "ai_guidance"].includes(i.id));
    }
    switch (currentUser.role) {
      case "supporter":
        return navItems.filter((i) => ["supporter", "ledger", "ai_guidance"].includes(i.id));
      case "patient":
        return navItems.filter((i) => ["register", "supporter", "ledger", "ai_guidance"].includes(i.id));
      case "field_agent":
        return navItems.filter((i) => ["agent", "supporter", "ledger"].includes(i.id));
      case "hospital":
      case "ngo":
        return navItems.filter((i) => ["hospital", "supporter", "ledger"].includes(i.id));
      case "super_admin":
      default:
        return navItems;
    }
  };

  const visibleNavItems = getRoleFilteredNavItems();

  const handleSelectTab = (tabId: string) => {
    setCurrentTab(tabId);
    setIsMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white text-slate-900 border-b border-slate-200 shadow-sm">
      {/* HopeBridge Inspiration Ticker - Top of Homepage */}
      {currentTab === "supporter" && <InspirationTicker />}

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo Component & Hamburger Trigger */}
        <div className="flex items-center gap-3">
          {/* Hamburger Menu Toggle Button integrated directly with Logo */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 -ml-2 rounded-xl text-slate-700 hover:bg-slate-100 hover:text-blue-600 transition-colors flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
            title="Click to open menu"
            aria-label="Toggle navigation menu"
          >
            {isMenuOpen ? <X className="w-6 h-6 text-slate-900" /> : <Menu className="w-6 h-6 text-slate-900" />}
          </button>

          <div className="flex items-center gap-2">
            <HopeBridgeLogo 
              size="md" 
              layout="horizontal" 
              onClick={() => setCurrentTab("supporter")} 
            />
          </div>
        </div>

        {/* Global Live Ticker */}
        <div className="hidden lg:flex items-center gap-5 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-1.5 text-xs">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Total Disbursed</span>
            <span className="text-emerald-700 font-extrabold text-sm">₹{(totalRaised / 10000000).toFixed(2)} Cr</span>
          </div>
          <div className="h-6 w-px bg-slate-200" />
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Ad Revenue</span>
            <span className="text-purple-700 font-bold text-sm">₹{((totalAdRevenue || 0) / 100000).toFixed(1)} Lakhs</span>
          </div>
          <div className="h-6 w-px bg-slate-200" />
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Ads Watched</span>
            <span className="text-blue-700 font-bold text-sm">{(totalAdsWatched ?? 0).toLocaleString()}</span>
          </div>
        </div>

        {/* Search Input & Welcome Trigger */}
        <div className="flex items-center gap-2 max-w-md flex-1 justify-end">
          <div className="flex-1 max-w-xs relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search patient, SMA, Cancer..."
              className="w-full bg-slate-100 text-slate-900 placeholder-slate-400 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-200 focus:outline-none focus:border-blue-600 focus:bg-white transition-all"
            />
          </div>

          {/* Welcome Screen Trigger */}
          {onOpenWelcome && (
            <button
              onClick={onOpenWelcome}
              title="View Welcome Screen"
              className="hidden sm:flex items-center gap-1 text-[11px] font-semibold text-slate-600 hover:text-emerald-700 bg-slate-100 hover:bg-slate-200 px-3 py-2 rounded-xl transition-colors cursor-pointer shrink-0 border border-slate-200"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Welcome</span>
            </button>
          )}
        </div>
      </div>

      {/* Global Live Ticker on Mobile / Small screens if needed or kept clean */}


      {/* Hamburger Menu Overlay Drawer (Triggered by Logo Click) */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div 
            onClick={() => setIsMenuOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
          />

          {/* Drawer Content */}
          <div className="relative w-full max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 overflow-y-auto animate-in slide-in-from-left duration-300">
            {/* Drawer Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <HopeBridgeLogo 
                size="md" 
                layout="horizontal" 
                onClick={() => {
                  setCurrentTab("supporter");
                  setIsMenuOpen(false);
                }} 
              />
              <button
                onClick={() => setIsMenuOpen(false)}
                className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-200 rounded-xl transition-colors"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Platform Stats Summary inside Drawer */}
            <div className="p-4 bg-blue-50/60 border-b border-blue-100 grid grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-2.5 rounded-xl border border-blue-100 shadow-sm">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Disbursed</span>
                <span className="text-emerald-700 font-extrabold text-sm">₹{(totalRaised / 10000000).toFixed(2)} Cr</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-blue-100 shadow-sm">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">Ads Watched</span>
                <span className="text-blue-700 font-extrabold text-sm">{(totalAdsWatched ?? 0).toLocaleString()}</span>
              </div>
            </div>

            {/* Menu Label */}
            <div className="px-5 py-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50/50 border-b border-slate-100">
              Navigation & Role Modules
            </div>

            {/* Navigation List */}
            <div className="p-3 space-y-1.5 flex-1">
              {visibleNavItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full text-left p-3.5 rounded-2xl transition-all flex items-center justify-between group border-0 ${
                      isActive 
                        ? "bg-blue-600 text-white shadow-md font-bold" 
                        : "hover:bg-slate-100 text-slate-800"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border-0 ${
                        isActive ? "bg-white/20 text-white" : "bg-slate-100 text-slate-700 group-hover:bg-blue-100 group-hover:text-blue-700"
                      }`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold block">{item.title}</span>
                        </div>
                        <span className={`text-xs block line-clamp-1 ${isActive ? "text-blue-100" : "text-slate-500"}`}>
                          {item.subtitle}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border-0 ${
                        isActive 
                          ? "bg-white text-blue-800" 
                          : item.badgeColor
                      }`}>
                        {item.badge}
                      </span>
                      <ChevronRight className={`w-4 h-4 ${isActive ? "text-white" : "text-slate-400"}`} />
                    </div>
                  </button>
                );
              })}

              {/* User Account / Sign In / Sign Out Section - Bottom of Menu */}
              <div className="pt-4 mt-2 border-t border-slate-200 space-y-3">
                <div className="px-1 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Account & Access
                </div>
                {currentUser ? (
                  <div className="bg-slate-100 rounded-2xl p-3.5 space-y-3 border-0">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-teal-800 text-white font-bold flex items-center justify-center text-sm shrink-0 border-0">
                        {currentUser.name.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="font-bold text-slate-900 text-sm block truncate">
                          {currentUser.name}
                        </span>
                        <span className="text-xs text-teal-700 font-semibold uppercase block">
                          {currentUser.role}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        onLogout();
                      }}
                      className="w-full flex items-center justify-center gap-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs py-2.5 px-4 rounded-xl transition-colors cursor-pointer border-0"
                    >
                      <LogOut className="w-4 h-4 text-slate-600" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenLogin();
                    }}
                    className="w-full flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs py-3 px-4 rounded-xl transition-all shadow-sm cursor-pointer border-0"
                  >
                    <User className="w-4 h-4 text-emerald-200" />
                    <span>Sign In / Sign Up</span>
                  </button>
                )}

                {/* Independent Borderless About HopeBridge Button at Bottom */}
                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    onOpenAbout();
                  }}
                  className="w-full p-3 rounded-2xl text-left transition-all flex items-center gap-3 hover:bg-teal-50/80 bg-transparent text-teal-900 border-0 cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 bg-teal-100 text-teal-800 font-bold border-0">
                    <Info className="w-4 h-4 text-teal-700" />
                  </div>
                  <div className="flex-1">
                    <span className="text-xs font-bold block text-slate-900">About HopeBridge</span>
                    <span className="text-[10px] text-teal-700 block">Mission & Transparency Verified</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-teal-600" />
                </button>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 text-center space-y-2 text-xs text-slate-500">
              <a
                href="mailto:hopebridgesupporters@gmail.com"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold border-0 transition-colors cursor-pointer text-[11px]"
              >
                <Mail className="w-3.5 h-3.5 text-teal-600" />
                <span>Contact Us: hopebridgesupporters@gmail.com</span>
              </a>
              <div className="flex items-center justify-center gap-1.5 font-bold text-emerald-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>100% On-Site Verified Medical Aid</span>
              </div>
              <p className="text-[11px] text-slate-400">
                95% Ad Revenue transferred directly to verified hospital accounts
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

