import React from "react";

export const INSPIRATION_QUOTES: string[] = [
  "❤️ Someone is holding on to hope. Be the reason they don't let go.",
  "✦ HopeBridge — Connecting Hearts. Restoring Hope. Saving Lives.",
  "💙 Every heartbeat deserves hope. Together, we make it possible.",
  "❖ Every verified patient deserves a second chance. Your kindness makes it possible.",
  "💚 Be the Hope. Build the Bridge. Save a Life.",
  "✧ Every act of kindness gives someone another reason to hope.",
  "◈ Behind every patient is a family praying for hope.",
  "✤ Compassion is the bridge between suffering and healing.",
  "⟡ Hope grows stronger when hearts unite.",
  "❤️ Every heartbeat carries a dream. Help keep it alive.",
  "💙 HopeBridge — Where kindness becomes someone's second chance.",
  "💚 Together, we can turn hope into healing.",
  "✦ Every patient deserves hope. Every heart can make a difference.",
  "❖ Kindness is remembered long after wealth is forgotten.",
  "✧ One caring heart can change an entire family's future.",
  "◈ The greatest gift is giving someone another tomorrow.",
  "✤ Healing begins when humanity stands together.",
  "⟡ Hope grows stronger when compassionate hearts unite.",
  "✪ Behind every smile is a story. Help create a happier ending.",
  "✥ Every act of kindness echoes for a lifetime.",
  "◆ Hope is priceless. Compassion makes it possible.",
  "❈ One moment of generosity can become a lifetime of gratitude.",
  "✺ Together, we build bridges where hope once seemed impossible.",
  "◉ Your kindness can become someone's greatest blessing.",
  "✦ A helping hand today can create a brighter tomorrow.",
  "❖ Every life is valuable. Every act of compassion matters.",
  "✧ HopeBridge connects caring hearts with lives that need hope.",
  "❤️ Someone's tomorrow may begin with your kindness today.",
  "💙 Together, we are stronger than illness.",
  "💚 When hearts unite, miracles become possible.",
  "✪ Every journey to healing begins with hope.",
  "✤ HopeBridge — Building hope, restoring lives.",
  "◈ A small act of compassion can inspire endless hope.",
  "⟡ Let kindness be the bridge that changes a life.",
  "◆ Give hope. Share humanity. Change lives.",
  "✥ Every life deserves another sunrise.",
  "❈ Compassion is the language every heart understands.",
  "❤️ Hope begins with one caring soul.",
  "💙 Together, we don't just donate—we restore hope."
];

export const InspirationTicker: React.FC = () => {
  return (
    <div className="w-full h-[32px] bg-white relative overflow-hidden select-none flex items-center z-50">
      <style>{`
        @keyframes hb-ticker-scroll {
          0% {
            transform: translate3d(0, 0, 0);
          }
          100% {
            transform: translate3d(-50%, 0, 0);
          }
        }
        .animate-hb-ticker {
          display: flex;
          width: max-content;
          animation: hb-ticker-scroll 160s linear infinite;
          will-change: transform;
        }
        .animate-hb-ticker:hover,
        .animate-hb-ticker:active {
          animation-play-state: paused;
        }
      `}</style>

      {/* Left Edge Soft White Fade */}
      <div 
        className="pointer-events-none absolute left-0 top-0 bottom-0 w-12 sm:w-20 bg-gradient-to-r from-white via-white/80 to-transparent z-10" 
        aria-hidden="true" 
      />

      {/* Right Edge Soft White Fade */}
      <div 
        className="pointer-events-none absolute right-0 top-0 bottom-0 w-12 sm:w-20 bg-gradient-to-l from-white via-white/80 to-transparent z-10" 
        aria-hidden="true" 
      />

      {/* Scrolling Container with Duplicate Sets for Infinite Seamless Loop */}
      <div className="animate-hb-ticker flex items-center">
        {/* Set 1 */}
        <div className="flex items-center shrink-0">
          {INSPIRATION_QUOTES.map((quote, idx) => (
            <div
              key={`q1-${idx}`}
              className="inline-flex items-center text-[14px] font-semibold text-[#0F766E] tracking-[0.2px] whitespace-nowrap px-6"
            >
              <span>{quote}</span>
            </div>
          ))}
        </div>

        {/* Set 2 (Identical duplicate for 100% smooth loop) */}
        <div className="flex items-center shrink-0" aria-hidden="true">
          {INSPIRATION_QUOTES.map((quote, idx) => (
            <div
              key={`q2-${idx}`}
              className="inline-flex items-center text-[14px] font-semibold text-[#0F766E] tracking-[0.2px] whitespace-nowrap px-6"
            >
              <span>{quote}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
