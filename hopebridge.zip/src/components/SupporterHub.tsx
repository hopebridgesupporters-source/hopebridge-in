import React, { useState } from "react";
import { PatientCampaign, CampaignCategory } from "../types";
import { 
  Tv, 
  Heart, 
  Share2, 
  ShieldCheck, 
  Clock, 
  Building2, 
  MapPin, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles,
  ChevronRight,
  TrendingUp,
  FileCheck2,
  Lock
} from "lucide-react";

interface SupporterHubProps {
  campaigns: PatientCampaign[];
  onWatchAd: (campaign: PatientCampaign) => void;
  onDonate: (campaign: PatientCampaign) => void;
  onShare: (campaign: PatientCampaign) => void;
  onViewDetails: (campaign: PatientCampaign) => void;
  searchQuery: string;
}

export const SupporterHub: React.FC<SupporterHubProps> = ({
  campaigns,
  onWatchAd,
  onDonate,
  onShare,
  onViewDetails,
  searchQuery
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories: { label: string; value: string; icon?: string }[] = [
    { label: "All Verified Cases", value: "All" },
    { label: "🚨 Emergency Priority", value: "Emergency" },
    { label: "SMA Gene Therapy", value: "SMA" },
    { label: "Pediatric Cancer", value: "Cancer" },
    { label: "Open Heart Surgery", value: "Cardiac" },
    { label: "Organ Transplant", value: "Transplant" },
  ];

  // Filter campaigns based on category & search query
  const filteredCampaigns = campaigns.filter((c) => {
    const matchesCategory =
      selectedCategory === "All"
        ? true
        : selectedCategory === "Emergency"
        ? c.emergencyPriority
        : c.category === selectedCategory;

    const query = searchQuery.toLowerCase();
    const matchesSearch =
      !query ||
      c.patientName.toLowerCase().includes(query) ||
      c.diagnosis.toLowerCase().includes(query) ||
      c.hospitalName.toLowerCase().includes(query) ||
      c.category.toLowerCase().includes(query);

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Category Pills & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                selectedCategory === cat.value
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30 scale-105"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-700"
              }`}
            >
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <span className="font-bold text-slate-900">{filteredCampaigns.length}</span> verified medical campaign{filteredCampaigns.length === 1 ? "" : "s"}
        </div>
      </div>

      {/* Campaign Cards Grid */}
      {filteredCampaigns.length === 0 ? (
        <div className="bg-slate-50 border border-dashed border-slate-300 rounded-2xl p-12 text-center space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No campaigns found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            No patient records match your current search or category filter. Try clearing your search query or selecting a different category.
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCampaigns.map((campaign) => {
            const percentage = Math.min(
              100,
              Math.round((campaign.collectedAmount / campaign.requiredAmount) * 100)
            );
            const remaining = campaign.requiredAmount - campaign.collectedAmount;
            const adPercent = Math.round(
              (campaign.adRevenueAmount / campaign.collectedAmount) * 100
            ) || 0;

            return (
              <div
                key={campaign.id}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group relative"
              >
                {/* Image Section & Verified Badge */}
                <div className="relative h-48 overflow-hidden bg-slate-900">
                  <img
                    src={campaign.patientPhoto}
                    alt={campaign.patientName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
                    <span className="bg-emerald-600 text-white text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md flex items-center gap-1 border border-emerald-400/40">
                      <ShieldCheck className="w-3.5 h-3.5" /> VERIFIED PATIENT
                    </span>

                    {campaign.emergencyPriority && (
                      <span className="bg-rose-600 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse shadow-md">
                        Urgent Critical
                      </span>
                    )}
                  </div>

                  {/* Bottom Patient Name & Category Overlay */}
                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <span className="text-[10px] font-bold bg-slate-900/80 px-2 py-0.5 rounded text-emerald-300 uppercase tracking-wider">
                      {campaign.category} • {campaign.patientAge} yrs old
                    </span>
                    <h3 className="text-lg font-black text-white tracking-tight mt-1 truncate">
                      {campaign.patientName}
                    </h3>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  {/* Diagnosis & Hospital Info */}
                  <div className="space-y-2">
                    <p className="text-xs text-slate-700 font-semibold line-clamp-2 leading-relaxed">
                      {campaign.diagnosis}
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium pt-1">
                      <span className="flex items-center gap-1 truncate max-w-[60%]">
                        <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        {campaign.hospitalName}
                      </span>
                      <span className="flex items-center gap-1 shrink-0 text-slate-600">
                        <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        {campaign.hospitalCity}
                      </span>
                    </div>
                  </div>

                  {/* Field Verification Summary Tag */}
                  {campaign.verificationReport && (
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-[11px] text-emerald-900 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 truncate">
                        <FileCheck2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span className="truncate">
                          Verified by <strong>{campaign.verificationReport.agentName.split("(")[0]}</strong>
                        </span>
                      </div>
                      <span className="font-mono text-[10px] bg-emerald-200 text-emerald-950 font-bold px-1.5 py-0.5 rounded">
                        100% GPS Audit
                      </span>
                    </div>
                  )}

                  {/* Funding Progress Section */}
                  <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <div>
                        <span className="text-slate-500 text-[10px] block font-bold uppercase">Raised</span>
                        <span className="text-emerald-700 font-black text-sm">
                          ₹{(campaign.collectedAmount ?? 0).toLocaleString("en-IN")}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-500 text-[10px] block font-bold uppercase">Target</span>
                        <span className="text-slate-800 font-bold text-xs">
                          ₹{(campaign.requiredAmount ?? 0).toLocaleString("en-IN")}
                        </span>
                      </div>
                    </div>

                    {/* Stacked Progress Bar (Ad Revenue + Direct Donation) */}
                    <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden flex">
                      {/* Ad Revenue Component (Purple) */}
                      <div
                        style={{
                          width: `${Math.min(
                            100,
                            ((campaign.adRevenueAmount || 0) / (campaign.requiredAmount || 1)) * 100
                          )}%`,
                        }}
                        className="bg-purple-600 h-full transition-all duration-500"
                        title={`Ad Revenue: ₹${(campaign.adRevenueAmount ?? 0).toLocaleString("en-IN")}`}
                      />
                      {/* Direct Donation Component (Emerald) */}
                      <div
                        style={{
                          width: `${Math.min(
                            100,
                            ((campaign.directDonationAmount || 0) / (campaign.requiredAmount || 1)) * 100
                          )}%`,
                        }}
                        className="bg-emerald-500 h-full transition-all duration-500"
                        title={`Direct Donations: ₹${(campaign.directDonationAmount ?? 0).toLocaleString("en-IN")}`}
                      />
                    </div>

                    {/* Progress Breakdown Indicators */}
                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                      <span className="flex items-center gap-1 text-purple-700 font-semibold">
                        <span className="w-2 h-2 rounded-full bg-purple-600 inline-block" />
                        Ads: ₹{((campaign.adRevenueAmount || 0) / 100000).toFixed(1)}L ({(campaign.adWatchCount ?? 0).toLocaleString()} ads)
                      </span>
                      <span className="font-extrabold text-slate-800">
                        {percentage}% Funded
                      </span>
                    </div>
                  </div>

                  {/* Primary Call to Action Buttons */}
                  <div className="space-y-2 pt-1">
                    {/* Primary Button: Watch Ad to Help */}
                    <button
                      onClick={() => onWatchAd(campaign)}
                      className="w-full bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-700 hover:to-indigo-800 text-white font-bold py-2.5 px-4 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 group/btn"
                    >
                      <Tv className="w-4 h-4 text-purple-200 group-hover/btn:scale-110 transition-transform" />
                      <span className="text-xs">Watch Ads to Support</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onDonate(campaign)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                      >
                        <Heart className="w-3.5 h-3.5 fill-current" />
                        <span>Direct Donate</span>
                      </button>

                      <button
                        onClick={() => onViewDetails(campaign)}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1 transition-colors border border-slate-200"
                      >
                        <span>View Details</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
