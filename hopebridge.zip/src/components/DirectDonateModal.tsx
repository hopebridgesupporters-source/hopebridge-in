import React, { useState } from "react";
import { PatientCampaign } from "../types";
import confetti from "canvas-confetti";
import { 
  Heart, 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  CreditCard, 
  QrCode as QrCodeIcon, 
  Building2, 
  FileText,
  Lock,
  Copy,
  Check,
  UploadCloud,
  ExternalLink
} from "lucide-react";

interface DirectDonateModalProps {
  campaign: PatientCampaign | null;
  onClose: () => void;
  onDonationCompleted: (
    campaignId: string, 
    amount: number, 
    donorName: string, 
    message: string,
    tax80G: boolean,
    panNumber: string,
    utrNumber?: string,
    paymentProofUrl?: string,
    paymentMode?: string
  ) => void;
}

export const DirectDonateModal: React.FC<DirectDonateModalProps> = ({
  campaign,
  onClose,
  onDonationCompleted,
}) => {
  const [amount, setAmount] = useState<number>(500);
  const [customAmount, setCustomAmount] = useState<string>("");
  const [paymentMode, setPaymentMode] = useState<string>("UPI");
  const [transactionId, setTransactionId] = useState<string>("");
  const [donorName, setDonorName] = useState<string>("");
  const [donorEmail, setDonorEmail] = useState<string>("");
  const [donorMessage, setDonorMessage] = useState<string>("");
  const [want80G, setWant80G] = useState<boolean>(true);
  const [panNumber, setPanNumber] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Proof screenshot upload state
  const [proofFile, setProofFile] = useState<{
    name: string;
    size: string;
    dataUrl: string;
  } | null>(null);

  if (!campaign) return null;

  const quickAmounts = [100, 250, 500, 1000, 2500, 5000];

  const paymentDetails = campaign.paymentDetails || {
    upiId: `${campaign.patientName.toLowerCase().replace(/[^a-z0-9]/g, "")}@upi`,
    accountNumber: "926010048123901",
    ifscCode: "UTIB0000812",
    bankName: `${campaign.hospitalName} Escrow Branch`,
    accountHolderName: `${campaign.hospitalName} - A/C ${campaign.patientName}`,
    qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${encodeURIComponent(campaign.patientName.toLowerCase().replace(/[^a-z0-9]/g, "") + "@upi")}&pn=${encodeURIComponent(campaign.patientName)}&cu=INR`,
    extraNotes: "100% Direct Hospital Escrow Account."
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard?.writeText?.(text);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const handleProofUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const sizeStr = file.size >= 1024 * 1024 
        ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` 
        : `${Math.round(file.size / 1024)} KB`;

      setProofFile({
        name: file.name,
        size: sizeStr,
        dataUrl
      });
    };
    reader.readAsDataURL(file);
  };

  const handleDonateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAmount = customAmount ? parseInt(customAmount, 10) || 0 : amount;

    if (finalAmount < 10) return;

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      confetti({
        particleCount: 120,
        spread: 90,
        origin: { y: 0.6 },
      });

      onDonationCompleted(
        campaign.id,
        finalAmount,
        donorName.trim() || "Kind Supporter",
        donorMessage,
        want80G,
        panNumber,
        transactionId.trim() || `UTR-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        proofFile?.dataUrl,
        paymentMode
      );
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white text-slate-900 rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative border border-slate-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 sticky top-0 bg-slate-50/95 backdrop-blur z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold shrink-0">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">Direct Patient Bank & QR Code Donation</h3>
              <p className="text-[11px] text-slate-500">
                100% Tax Deductible (Section 80G) • Direct Hospital Escrow
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleDonateSubmit} className="p-6 space-y-5">
          {/* Patient Summary Header */}
          <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl flex items-center gap-3">
            <img
              src={campaign.patientPhoto}
              alt={campaign.patientName}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-xl object-cover shrink-0 border border-emerald-200"
            />
            <div className="text-xs space-y-0.5">
              <span className="font-black text-emerald-950 block">
                Supporting {campaign.patientName} ({campaign.patientAge} yrs)
              </span>
              <p className="text-emerald-800 text-[11px] line-clamp-1">
                {campaign.hospitalName} • {campaign.diagnosis}
              </p>
            </div>
          </div>

          {/* Patient Official Bank Details & QR Code Section */}
          <div className="bg-slate-900 text-white rounded-2xl p-4 space-y-3 shadow-inner">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <QrCodeIcon className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-slate-100">Patient QR Code & Bank Details</span>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                Direct Escrow Account
              </span>
            </div>

            <div className="grid sm:grid-cols-3 gap-3 items-center">
              {/* QR Code Container */}
              <div className="flex flex-col items-center justify-center bg-white p-2.5 rounded-xl border border-slate-700 text-center shrink-0">
                <img
                  src={paymentDetails.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${encodeURIComponent(paymentDetails.upiId || 'patient@upi')}&pn=${encodeURIComponent(campaign.patientName)}&cu=INR`}
                  alt="Patient Donation QR Code"
                  className="w-28 h-28 object-contain"
                />
                <span className="text-[9px] font-bold text-slate-700 mt-1">Scan with GPay / PhonePe / Paytm</span>
              </div>

              {/* Bank Account Details */}
              <div className="sm:col-span-2 space-y-1.5 text-xs">
                {paymentDetails.upiId && (
                  <div className="bg-slate-800/80 p-2 rounded-lg flex items-center justify-between border border-slate-700">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block">UPI ID</span>
                      <span className="font-mono text-xs font-bold text-emerald-400">{paymentDetails.upiId}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(paymentDetails.upiId!, "UPI ID")}
                      className="bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1 transition-colors"
                    >
                      {copiedField === "UPI ID" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === "UPI ID" ? "Copied" : "Copy"}</span>
                    </button>
                  </div>
                )}

                {paymentDetails.accountNumber && (
                  <div className="bg-slate-800/80 p-2 rounded-lg flex items-center justify-between border border-slate-700">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block">A/C No ({paymentDetails.bankName || 'Hospital Bank'})</span>
                      <span className="font-mono text-xs font-bold text-amber-300">{paymentDetails.accountNumber}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(paymentDetails.accountNumber!, "A/C No")}
                      className="bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1 transition-colors"
                    >
                      {copiedField === "A/C No" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === "A/C No" ? "Copied" : "Copy"}</span>
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-1.5 text-[10px] text-slate-300">
                  <div className="bg-slate-800/50 p-1.5 rounded border border-slate-700/60">
                    <span className="text-slate-400 block text-[9px]">IFSC CODE</span>
                    <span className="font-mono font-bold text-slate-200">{paymentDetails.ifscCode || 'UTIB0000812'}</span>
                  </div>
                  <div className="bg-slate-800/50 p-1.5 rounded border border-slate-700/60 truncate">
                    <span className="text-slate-400 block text-[9px]">A/C HOLDER</span>
                    <span className="font-bold text-slate-200 truncate block">{paymentDetails.accountHolderName || campaign.patientName}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Amount Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              Donation Amount (₹) *
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              {quickAmounts.map((amt) => (
                <button
                  type="button"
                  key={amt}
                  onClick={() => {
                    setAmount(amt);
                    setCustomAmount("");
                  }}
                  className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                    amount === amt && !customAmount
                      ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                      : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                  }`}
                >
                  ₹{(amt ?? 0).toLocaleString("en-IN")}
                </button>
              ))}
            </div>

            <div className="relative pt-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                Custom ₹
              </span>
              <input
                type="number"
                value={customAmount}
                onChange={(e) => {
                  setCustomAmount(e.target.value);
                  setAmount(0);
                }}
                placeholder="Enter custom amount (e.g. 10000)"
                className="w-full pl-20 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:bg-white transition-all font-bold"
              />
            </div>
          </div>

          {/* Transaction UTR / Ref Number & Payment Method Input */}
          <div className="bg-amber-50/80 border border-amber-200 p-3.5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-amber-950 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-amber-700" />
                Transaction ID / UTR Ref Number *
              </label>
              <span className="text-[10px] bg-amber-200 text-amber-900 font-bold px-2 py-0.5 rounded">
                Required for Automated Credit
              </span>
            </div>

            <input
              type="text"
              required
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder="e.g. 428190881234 or UPI/123456789"
              className="w-full px-3 py-2 text-xs bg-white border border-amber-300 rounded-xl focus:outline-none focus:border-amber-600 font-mono font-bold tracking-wider uppercase text-amber-950"
            />
            <p className="text-[11px] text-amber-800">
              Found on your UPI app (Google Pay / PhonePe / Paytm / BHIM) or Bank SMS after sending the payment.
            </p>

            {/* Payment Mode Selector */}
            <div className="grid grid-cols-4 gap-1.5 pt-1 text-[11px]">
              {["UPI", "GPay/PhonePe", "Netbanking", "Card"].map((mode) => (
                <button
                  type="button"
                  key={mode}
                  onClick={() => setPaymentMode(mode)}
                  className={`py-1.5 rounded-lg font-bold border transition-all ${
                    paymentMode === mode
                      ? "bg-amber-600 text-white border-amber-600"
                      : "bg-white text-slate-700 border-amber-200 hover:bg-amber-100/50"
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            {/* Upload Payment Proof Screenshot (Optional / Encouraged) */}
            <div className="pt-2 border-t border-amber-200/80 flex items-center justify-between gap-3 text-xs">
              <div className="flex-1">
                <span className="font-bold text-amber-950 block">Upload Payment Proof Screenshot</span>
                <span className="text-[10px] text-amber-800">Attach receipt/screenshot for instant public ledger display</span>
              </div>

              {proofFile ? (
                <div className="flex items-center gap-2 bg-white border border-amber-300 p-1.5 rounded-xl">
                  <img src={proofFile.dataUrl} alt="Proof" className="w-9 h-9 object-cover rounded" />
                  <button
                    type="button"
                    onClick={() => setProofFile(null)}
                    className="text-rose-600 font-bold text-xs p-1"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <label className="bg-amber-700 hover:bg-amber-800 text-white font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shrink-0 transition-colors">
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Attach Proof</span>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleProofUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          {/* Donor Info Inputs */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={donorName}
                onChange={(e) => setDonorName(e.target.value)}
                placeholder="e.g. Rajesh Verma"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={donorEmail}
                onChange={(e) => setDonorEmail(e.target.value)}
                placeholder="For receipt delivery"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 block mb-1">
              Encouraging Message (Optional)
            </label>
            <input
              type="text"
              value={donorMessage}
              onChange={(e) => setDonorMessage(e.target.value)}
              placeholder="e.g. Wishing you a speedy recovery!"
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* 80G Tax Receipt Checkbox */}
          <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl space-y-2 text-xs">
            <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={want80G}
                onChange={(e) => setWant80G(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500"
              />
              <span>Generate 80G Tax Exemption Receipt (50% Tax Exemption)</span>
            </label>

            {want80G && (
              <input
                type="text"
                value={panNumber}
                onChange={(e) => setPanNumber(e.target.value.toUpperCase())}
                placeholder="Enter PAN Number (e.g. ABCDE1234F)"
                maxLength={10}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg uppercase font-mono tracking-wider focus:outline-none focus:border-emerald-500"
              />
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 rounded-2xl shadow-lg shadow-emerald-600/30 transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
          >
            {isProcessing ? (
              <span>Verifying Transaction & Updating Campaign Total...</span>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>
                  Submit & Confirm ₹{((customAmount ? parseInt(customAmount, 10) || 0 : amount) ?? 0).toLocaleString("en-IN")} Direct Donation
                </span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

