import React, { useState, useEffect } from "react";
import { 
  X, 
  ShieldAlert, 
  Lock, 
  KeyRound, 
  Database, 
  Users, 
  FileCheck, 
  Building, 
  Activity, 
  Smartphone, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw,
  LogOut,
  Search,
  Plus,
  Trash2,
  Edit2,
  Download,
  Upload,
  Check,
  XCircle,
  FileSpreadsheet,
  HardDrive,
  Sparkles,
  Building2,
  QrCode,
  RotateCcw,
  Tv,
  Image as ImageIcon,
  Video,
  Music,
  ExternalLink,
  Megaphone
} from "lucide-react";
import { authService } from "../services/authService";
import { UserAccount, AuditLog, PatientCampaign, AdSponsor } from "../types";
import { initialCampaigns, initialSponsors } from "../data/mockData";

interface SuperAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdminAuthenticated: (adminUser: UserAccount) => void;
  campaigns?: PatientCampaign[];
  onUpdateCampaigns?: (updatedCampaigns: PatientCampaign[]) => void;
}

export const SuperAdminModal: React.FC<SuperAdminModalProps> = ({
  isOpen,
  onClose,
  onAdminAuthenticated,
  campaigns = [],
  onUpdateCampaigns,
}) => {
  const [step, setStep] = useState<"auth" | "dashboard">("auth");
  const [password, setPassword] = useState<string>("SuperSecretAdmin2026!");
  const [twoFactorCode, setTwoFactorCode] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Active Admin View Tab
  const [activeTab, setActiveTab] = useState<"audit_logs" | "users" | "campaigns" | "ads_manager" | "backup">("audit_logs");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Audit logs & database collections
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => authService.getAuditLogs());
  
  // Local editable collections for super admin
  const [dbUsers, setDbUsers] = useState<UserAccount[]>(() => {
    try {
      const stored = localStorage.getItem("hopebridge_users_v2");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [dbCampaigns, setDbCampaigns] = useState<PatientCampaign[]>(() => {
    if (campaigns && campaigns.length > 0) return campaigns;
    try {
      const stored = localStorage.getItem("hopebridge_campaigns");
      return stored ? JSON.parse(stored) : initialCampaigns;
    } catch {
      return initialCampaigns;
    }
  });

  // Local Watch Ads Sponsors Collection
  const [dbSponsors, setDbSponsors] = useState<AdSponsor[]>(() => {
    try {
      const stored = localStorage.getItem("hopebridge_sponsors");
      return stored ? JSON.parse(stored) : initialSponsors;
    } catch {
      return initialSponsors;
    }
  });

  // Sponsor Ad Editor State
  const [isAddingSponsor, setIsAddingSponsor] = useState<boolean>(false);
  const [editingSponsor, setEditingSponsor] = useState<AdSponsor | null>(null);
  const [sponsorForm, setSponsorForm] = useState<Partial<AdSponsor>>({
    brandName: "",
    campaignTitle: "",
    category: "Healthcare & Wellness",
    videoDurationSeconds: 15,
    payoutPerView: 35,
    bannerText: "",
    callToAction: "Visit Offer",
    logoUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80",
    imageUrl: "",
    videoUrl: "",
    audioUrl: "",
    externalLink: "",
    adType: "hybrid"
  });

  // Keep dbCampaigns synchronized with parent campaigns prop
  useEffect(() => {
    if (campaigns) {
      setDbCampaigns(campaigns);
    }
  }, [campaigns]);

  // Modal actions
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [isAddingUser, setIsAddingUser] = useState<boolean>(false);
  const [newUserForm, setNewUserForm] = useState({
    name: "",
    email: "",
    mobile: "",
    role: "supporter" as any,
    password: "password123"
  });

  // Manufacturer Form State for Super Admin
  const [isManufacturing, setIsManufacturing] = useState<boolean>(false);
  const [manufactureForm, setManufactureForm] = useState({
    patientName: "",
    patientAge: "7",
    diagnosis: "",
    hospitalName: "",
    requiredAmount: "850000",
    patientPhoto: "https://images.unsplash.com/photo-1543332164-6e82f355badc?auto=format&fit=crop&w=600&q=80",
    upiId: "",
    accountNumber: "",
    ifscCode: "UTIB0000812",
    bankName: "Axis Bank Escrow Branch",
    autoVerify: true,
  });

  const [deleteConfirmId, setDeleteConfirmId] = useState<{ id: string; type: "user" | "campaign" | "clear_all_campaigns" } | null>(null);
  const [adminNotification, setAdminNotification] = useState<string | null>(null);

  if (!isOpen) return null;

  const showNotification = (msg: string) => {
    setAdminNotification(msg);
    setTimeout(() => setAdminNotification(null), 3500);
  };

  const persistCampaignsUpdate = (updated: PatientCampaign[]) => {
    setDbCampaigns(updated);
    if (onUpdateCampaigns) {
      onUpdateCampaigns(updated);
    }
    try {
      localStorage.setItem("hopebridge_campaigns", JSON.stringify(updated));
    } catch (e) {
      console.warn("Storage write error:", e);
    }
  };

  const persistSponsorsUpdate = (updated: AdSponsor[]) => {
    setDbSponsors(updated);
    try {
      localStorage.setItem("hopebridge_sponsors", JSON.stringify(updated));
    } catch (e) {
      console.warn("Sponsors write error:", e);
    }
  };

  const handleSaveSponsor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sponsorForm.brandName || !sponsorForm.campaignTitle) {
      alert("Please provide Brand Name and Campaign Title");
      return;
    }

    if (editingSponsor) {
      const updated = dbSponsors.map((s) =>
        s.id === editingSponsor.id
          ? {
              ...s,
              ...sponsorForm,
              videoDurationSeconds: Number(sponsorForm.videoDurationSeconds) || 15,
              payoutPerView: Number(sponsorForm.payoutPerView) || 35,
            } as AdSponsor
          : s
      );
      persistSponsorsUpdate(updated);
      setEditingSponsor(null);
      showNotification(`Watch Ad Campaign "${sponsorForm.brandName}" updated successfully!`);
    } else {
      const newSponsor: AdSponsor = {
        id: `sp-${Date.now()}`,
        brandName: sponsorForm.brandName || "New Ad Sponsor",
        logoUrl: sponsorForm.logoUrl || "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80",
        campaignTitle: sponsorForm.campaignTitle || "Support Patient Healthcare",
        videoDurationSeconds: Number(sponsorForm.videoDurationSeconds) || 15,
        payoutPerView: Number(sponsorForm.payoutPerView) || 35,
        bannerText: sponsorForm.bannerText || "Watch this ad banner to generate patient funds.",
        callToAction: sponsorForm.callToAction || "Learn More",
        category: sponsorForm.category || "Healthcare & Wellness",
        imageUrl: sponsorForm.imageUrl || "",
        videoUrl: sponsorForm.videoUrl || "",
        audioUrl: sponsorForm.audioUrl || "",
        externalLink: sponsorForm.externalLink || "",
        adType: (sponsorForm.adType as any) || "hybrid",
      };
      const updated = [newSponsor, ...dbSponsors];
      persistSponsorsUpdate(updated);
      setIsAddingSponsor(false);
      showNotification(`Watch Ad Campaign "${newSponsor.brandName}" created & published!`);
    }

    setSponsorForm({
      brandName: "",
      campaignTitle: "",
      category: "Healthcare & Wellness",
      videoDurationSeconds: 15,
      payoutPerView: 35,
      bannerText: "",
      callToAction: "Visit Offer",
      logoUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80",
      imageUrl: "",
      videoUrl: "",
      audioUrl: "",
      externalLink: "",
      adType: "hybrid"
    });
  };

  const handleDeleteSponsor = (sponsorId: string) => {
    const updated = dbSponsors.filter((s) => s.id !== sponsorId);
    persistSponsorsUpdate(updated);
    showNotification("Watch Ad campaign removed permanently.");
  };

  const handleRestoreSponsors = () => {
    persistSponsorsUpdate(initialSponsors);
    showNotification("Restored default Watch Ad sponsor campaigns.");
  };

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setIsSubmitting(true);

    setTimeout(() => {
      const res = authService.loginSuperAdmin(password, twoFactorCode);
      setIsSubmitting(false);

      if (!res.success || !res.user) {
        setErrorMsg(res.error || "Authentication failed.");
      } else {
        setStep("dashboard");
        setAuditLogs(authService.getAuditLogs());
        onAdminAuthenticated(res.user);
      }
    }, 500);
  };

  const handleRefreshLogs = () => {
    setAuditLogs(authService.getAuditLogs());
  };

  // User database operations
  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    const res = authService.registerUser({
      name: newUserForm.name,
      email: newUserForm.email,
      mobile: newUserForm.mobile,
      password: newUserForm.password,
      role: newUserForm.role
    });

    if (res.success && res.user) {
      setDbUsers((prev) => [res.user!, ...prev]);
      setIsAddingUser(false);
      setNewUserForm({ name: "", email: "", mobile: "", role: "supporter", password: "password123" });
      showNotification(`User ${res.user.name} created successfully.`);
    } else {
      alert(res.error || "Failed to create user.");
    }
  };

  const handleDeleteUser = (userId: string) => {
    const updated = dbUsers.filter((u) => u.id !== userId);
    setDbUsers(updated);
    try {
      localStorage.setItem("hopebridge_users_v2", JSON.stringify(updated));
    } catch {}
    authService.logAudit({
      userId: "usr-000-admin",
      userName: "HopeBridge Executive Owner",
      userRole: "super_admin",
      action: `DELETE_USER_${userId}`,
      ipAddress: "127.0.0.1",
      deviceInfo: navigator.userAgent || "Web Browser",
      status: "SUCCESS"
    });
    setDeleteConfirmId(null);
    showNotification("User account permanently removed from database.");
  };

  // Campaign database operations
  const handleApproveCampaign = (campaignId: string) => {
    const updated = dbCampaigns.map((c) =>
      c.id === campaignId
        ? {
            ...c,
            verifiedBadge: true,
            status: "verified_active" as const,
          }
        : c
    );
    persistCampaignsUpdate(updated);
    authService.logAudit({
      userId: "usr-000-admin",
      userName: "HopeBridge Executive Owner",
      userRole: "super_admin",
      action: `APPROVE_CAMPAIGN_${campaignId}`,
      ipAddress: "127.0.0.1",
      deviceInfo: navigator.userAgent || "Web Browser",
      status: "SUCCESS"
    });
    showNotification("Patient campaign approved & updated on all dashboards!");
  };

  const handleRejectCampaign = (campaignId: string) => {
    const updated = dbCampaigns.map((c) =>
      c.id === campaignId ? { ...c, verifiedBadge: false, status: "rejected" as const } : c
    );
    persistCampaignsUpdate(updated);
    showNotification("Patient campaign marked as Rejected.");
  };

  const handleDeleteCampaign = (campaignId: string) => {
    const updated = dbCampaigns.filter((c) => c.id !== campaignId);
    persistCampaignsUpdate(updated);
    setDeleteConfirmId(null);
    showNotification("Patient record removed & auto-updated across all dashboards!");
  };

  const handleManufactureCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    const reqAmt = Number(manufactureForm.requiredAmount) || 500000;
    const name = manufactureForm.patientName || "Master Patient";
    const hospital = manufactureForm.hospitalName || "AIIMS Specialty Hospital";
    const condition = manufactureForm.diagnosis || "Critical ICU Healthcare Treatment";
    const newId = `p-${Date.now()}`;
    const cleanUpi = manufactureForm.upiId || `${name.toLowerCase().replace(/[^a-z0-9]/g, "")}@upi`;
    
    const manufactured: PatientCampaign = {
      id: newId,
      patientName: name,
      patientAge: Number(manufactureForm.patientAge) || 8,
      gender: "Male",
      guardianName: "Parent / Guardian",
      contactPhone: "+91 9876543210",
      diagnosis: condition,
      category: "Emergency",
      hospitalName: hospital,
      hospitalCity: "New Delhi",
      doctorName: "Dr. A. K. Malhotra",
      doctorRegNo: "MCI-98124",
      requiredAmount: reqAmt,
      collectedAmount: 0,
      adRevenueAmount: 0,
      directDonationAmount: 0,
      adWatchCount: 0,
      shareCount: 0,
      verifiedBadge: manufactureForm.autoVerify,
      status: manufactureForm.autoVerify ? "verified_active" : "pending_verification",
      emergencyPriority: true,
      story: `${condition} treatment required at ${hospital}. Auto-verified and escrow protected by Super Admin Vault.`,
      patientPhoto: manufactureForm.patientPhoto || "https://images.unsplash.com/photo-1543332164-6e82f355badc?auto=format&fit=crop&w=600&q=80",
      coverPhoto: manufactureForm.patientPhoto || "https://images.unsplash.com/photo-1543332164-6e82f355badc?auto=format&fit=crop&w=600&q=80",
      documents: [],
      treatmentBreakdown: [
        { id: `tr-1-${Date.now()}`, name: "Primary Surgery & ICU Stay", cost: Math.round(reqAmt * 0.7), category: "ICU Stay" },
        { id: `tr-2-${Date.now()}`, name: "Specialty Medication & Rehab", cost: Math.round(reqAmt * 0.3), category: "Medication/Gene Therapy" },
      ],
      verificationReport: {
        agentId: "ADM-001",
        agentName: "Super Admin Direct System",
        agentPhone: "+91 9800000000",
        visitTimestamp: new Date().toLocaleDateString(),
        gpsLocation: {
          lat: 28.6139,
          lng: 77.2090,
          addressName: "New Delhi Medical Zone"
        },
        hospitalAdmissionNo: "HOSP-DL-2026-901",
        homeVisitCompleted: true,
        hospitalBedVerified: true,
        doctorConfirmed: true,
        doctorRegNo: "MCI-98124",
        auditScore: 99,
        reportSummary: "Auto-manufactured and verified directly by Super Admin Vault.",
        photos: []
      },
      updates: [
        {
          id: `u-init-${Date.now()}`,
          date: new Date().toLocaleDateString(),
          title: "Super Admin Registered Campaign",
          content: "Patient campaign successfully added to active healthcare ledger.",
          author: "Super Admin Vault",
          role: "Hospital"
        }
      ],
      donorList: [],
      paymentDetails: {
        upiId: cleanUpi,
        accountNumber: manufactureForm.accountNumber || "9210200481203",
        ifscCode: manufactureForm.ifscCode || "UTIB0000812",
        bankName: manufactureForm.bankName || "Axis Bank Escrow",
        accountHolderName: `${hospital} - A/C ${name}`,
        qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${encodeURIComponent(cleanUpi)}&pn=${encodeURIComponent(name)}&cu=INR`,
        extraNotes: "Super Admin Verified Direct Escrow Account."
      },
      createdAt: new Date().toLocaleDateString(),
    };

    const updated = [manufactured, ...dbCampaigns];
    persistCampaignsUpdate(updated);
    setIsManufacturing(false);
    setManufactureForm({
      patientName: "",
      patientAge: "7",
      diagnosis: "",
      hospitalName: "",
      requiredAmount: "850000",
      patientPhoto: "https://images.unsplash.com/photo-1543332164-6e82f355badc?auto=format&fit=crop&w=600&q=80",
      upiId: "",
      accountNumber: "",
      ifscCode: "UTIB0000812",
      bankName: "Axis Bank Escrow Branch",
      autoVerify: true,
    });
    showNotification(`Patient campaign "${name}" manufactured & published to all dashboards!`);
  };

  const handleRestoreDefaults = () => {
    persistCampaignsUpdate(initialCampaigns);
    showNotification("Restored standard sample patient campaigns across all dashboards!");
  };

  const handleClearAllCampaigns = () => {
    persistCampaignsUpdate([]);
    setDeleteConfirmId(null);
    showNotification("All patient campaigns cleared & updated across all dashboards!");
  };

  // Backup & Export
  const handleExportJSON = () => {
    const backupData = {
      timestamp: new Date().toISOString(),
      platform: "HopeBridge Verified Healthcare Ledger",
      users: dbUsers,
      campaigns: dbCampaigns,
      auditLogs: auditLogs
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hopebridge_db_backup_${Date.now()}.json`;
    a.click();
    showNotification("Database Backup downloaded successfully!");
  };

  const handleRestoreBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed.users && parsed.campaigns) {
          setDbUsers(parsed.users);
          setDbCampaigns(parsed.campaigns);
          localStorage.setItem("hopebridge_users_v2", JSON.stringify(parsed.users));
          localStorage.setItem("hopebridge_campaigns", JSON.stringify(parsed.campaigns));
          showNotification("Database restored successfully from backup file!");
        } else {
          alert("Invalid backup file format.");
        }
      } catch {
        alert("Failed to parse backup JSON file.");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-60 bg-slate-950/90 backdrop-blur-lg flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full p-6 sm:p-8 shadow-2xl text-slate-100 relative overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  HopeBridge Executive Super Admin Vault
                </h2>
                <span className="text-[10px] bg-rose-500/20 text-rose-400 font-mono font-bold px-2 py-0.5 rounded border border-rose-500/30">
                  RESTRICTED ACCESS
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Encrypted Owner Management Console • Role-Based Access Control • Anti-Duplicate Guard
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Admin Banner Notification */}
        {adminNotification && (
          <div className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs px-4 py-2 rounded-xl mt-3 flex items-center justify-between animate-pulse">
            <span className="font-semibold">{adminNotification}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
        )}

        {/* STEP 1: AUTHENTICATION FORM */}
        {step === "auth" ? (
          <form onSubmit={handleAdminAuth} className="max-w-md mx-auto space-y-4 py-8">
            <div className="text-center space-y-1 mb-6">
              <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 mx-auto flex items-center justify-center text-amber-400 mb-2">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Owner 2FA Challenge</h3>
              <p className="text-xs text-slate-400">
                Enter your Super Admin Password and Authenticator 2FA code.
              </p>
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-rose-300 text-xs font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Admin Master Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl text-xs font-mono text-white outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-bold text-slate-300">
                  2FA Authenticator Code
                </label>
                <span className="text-[10px] text-amber-400 font-mono">Use demo code: 123456</span>
              </div>
              <input
                type="text"
                required
                maxLength={6}
                value={twoFactorCode}
                onChange={(e) => setTwoFactorCode(e.target.value)}
                placeholder="123456"
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl text-sm font-mono text-center tracking-widest text-amber-400 outline-none"
              />
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                Verified Admin Device: macOS Chrome (Encrypted)
              </span>
              <span className="text-emerald-400 font-bold">Trusted</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-3 rounded-2xl shadow-lg transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>Verifying Hardware Token...</span>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Unlock Super Admin Vault</span>
                </>
              )}
            </button>
          </form>
        ) : (
          /* STEP 2: SUPER ADMIN DASHBOARD */
          <div className="space-y-4 pt-4 overflow-y-auto pr-1 flex-1">
            {/* Top Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 mb-1">
                  <span className="text-xs font-semibold">Total Accounts</span>
                  <Users className="w-4 h-4 text-teal-400" />
                </div>
                <span className="text-lg font-bold text-white">{dbUsers.length} Users</span>
                <span className="text-[10px] text-emerald-400 block mt-0.5">Anti-Duplicate Guard</span>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 mb-1">
                  <span className="text-xs font-semibold">Patient Campaigns</span>
                  <Database className="w-4 h-4 text-purple-400" />
                </div>
                <span className="text-lg font-bold text-white">{dbCampaigns.length} Active</span>
                <span className="text-[10px] text-purple-400 block mt-0.5">100% Escrow Protected</span>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 mb-1">
                  <span className="text-xs font-semibold">Hospital Nodes</span>
                  <Building className="w-4 h-4 text-emerald-400" />
                </div>
                <span className="text-lg font-bold text-white">4 Hospitals</span>
                <span className="text-[10px] text-emerald-400 block mt-0.5">Direct Billing APIs</span>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl">
                <div className="flex items-center justify-between text-slate-400 mb-1">
                  <span className="text-xs font-semibold">Audit Logs</span>
                  <Activity className="w-4 h-4 text-amber-400" />
                </div>
                <span className="text-lg font-bold text-white">{auditLogs.length} Events</span>
                <span className="text-[10px] text-amber-400 block mt-0.5">Security Active</span>
              </div>
            </div>

            {/* Dashboard Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab("audit_logs")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeTab === "audit_logs"
                      ? "bg-amber-500 text-slate-950 shadow"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Audit Logs</span>
                </button>

                <button
                  onClick={() => setActiveTab("users")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeTab === "users"
                      ? "bg-amber-500 text-slate-950 shadow"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Users DB ({dbUsers.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab("campaigns")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeTab === "campaigns"
                      ? "bg-amber-500 text-slate-950 shadow"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Patient Ledger ({dbCampaigns.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab("ads_manager")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeTab === "ads_manager"
                      ? "bg-purple-600 text-white shadow"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  <Tv className="w-3.5 h-3.5 text-purple-300" />
                  <span>Watch Ads Manager ({dbSponsors.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab("backup")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeTab === "backup"
                      ? "bg-amber-500 text-slate-950 shadow"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  <HardDrive className="w-3.5 h-3.5" />
                  <span>Backup & Restore</span>
                </button>
              </div>

              {/* Search box for database collections */}
              <div className="relative w-48 sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Filter records..."
                  className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl pl-8 pr-3 py-1.5 outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* TAB 1: AUDIT LOGS */}
            {activeTab === "audit_logs" && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-amber-400" />
                      Real-Time Security & Database Audit Log
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Tracking all authentication attempts, duplicate checks, and master database operations.
                    </p>
                  </div>
                  <button
                    onClick={handleRefreshLogs}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>

                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-bold tracking-wider sticky top-0">
                      <tr>
                        <th className="p-2.5">Timestamp</th>
                        <th className="p-2.5">User / Account</th>
                        <th className="p-2.5">Action</th>
                        <th className="p-2.5">IP Address</th>
                        <th className="p-2.5">Device</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                      {auditLogs
                        .filter(
                          (l) =>
                            !searchTerm ||
                            l.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            l.action.toLowerCase().includes(searchTerm.toLowerCase())
                        )
                        .map((log) => (
                          <tr key={log.id} className="hover:bg-slate-900/50">
                            <td className="p-2.5 text-slate-400">
                              {new Date(log.timestamp).toLocaleTimeString()}
                            </td>
                            <td className="p-2.5 text-white font-sans font-bold">
                              {log.userName}
                              <span className="text-[9px] text-slate-400 font-mono block">
                                [{log.userRole}]
                              </span>
                            </td>
                            <td className="p-2.5 text-amber-300 font-semibold">{log.action}</td>
                            <td className="p-2.5 text-slate-400">{log.ipAddress}</td>
                            <td className="p-2.5 text-slate-400 truncate max-w-[120px]">
                              {log.deviceInfo}
                            </td>
                            <td className="p-2.5">
                              <span
                                className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${
                                  log.status === "SUCCESS"
                                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                                    : log.status === "FAILED"
                                    ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                                    : "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                }`}
                              >
                                {log.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 2: USERS DATABASE MANAGEMENT */}
            {activeTab === "users" && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Users className="w-4 h-4 text-teal-400" />
                      User Accounts Collection
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Manage registered supporters, patients, hospital nodes, NGOs & field agents.
                    </p>
                  </div>
                  <button
                    onClick={() => setIsAddingUser(!isAddingUser)}
                    className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add New User</span>
                  </button>
                </div>

                {/* Add New User Form */}
                {isAddingUser && (
                  <form onSubmit={handleCreateUser} className="bg-slate-900 border border-teal-500/30 p-4 rounded-xl space-y-3">
                    <h4 className="text-xs font-bold text-teal-300">Create Unique User Record</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <input
                        type="text"
                        required
                        placeholder="Full Name"
                        value={newUserForm.name}
                        onChange={(e) => setNewUserForm({ ...newUserForm, name: e.target.value })}
                        className="p-2 bg-slate-950 border border-slate-700 rounded-lg text-white outline-none"
                      />
                      <input
                        type="email"
                        required
                        placeholder="Email Address"
                        value={newUserForm.email}
                        onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                        className="p-2 bg-slate-950 border border-slate-700 rounded-lg text-white outline-none"
                      />
                      <input
                        type="tel"
                        required
                        placeholder="Mobile Number"
                        value={newUserForm.mobile}
                        onChange={(e) => setNewUserForm({ ...newUserForm, mobile: e.target.value })}
                        className="p-2 bg-slate-950 border border-slate-700 rounded-lg text-white outline-none"
                      />
                      <select
                        value={newUserForm.role}
                        onChange={(e) => setNewUserForm({ ...newUserForm, role: e.target.value as any })}
                        className="p-2 bg-slate-950 border border-slate-700 rounded-lg text-white outline-none"
                      >
                        <option value="supporter">Supporter</option>
                        <option value="patient">Patient</option>
                        <option value="hospital">Hospital Node</option>
                        <option value="ngo">NGO Partner</option>
                        <option value="field_agent">Field Agent</option>
                      </select>
                    </div>
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingUser(false)}
                        className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-xs"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-3 py-1 bg-teal-600 text-white font-bold rounded-lg text-xs"
                      >
                        Save Account
                      </button>
                    </div>
                  </form>
                )}

                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-bold tracking-wider sticky top-0">
                      <tr>
                        <th className="p-2.5">ID</th>
                        <th className="p-2.5">Name</th>
                        <th className="p-2.5">Contact</th>
                        <th className="p-2.5">Role</th>
                        <th className="p-2.5">Created</th>
                        <th className="p-2.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                      {dbUsers
                        .filter(
                          (u) =>
                            !searchTerm ||
                            u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            u.email.toLowerCase().includes(searchTerm.toLowerCase())
                        )
                        .map((u) => (
                          <tr key={u.id} className="hover:bg-slate-900/50">
                            <td className="p-2.5 text-slate-500 font-mono">{u.id}</td>
                            <td className="p-2.5 font-sans font-bold text-white">{u.name}</td>
                            <td className="p-2.5 text-slate-300">
                              {u.email}
                              <span className="text-[10px] text-slate-500 block">{u.mobile}</span>
                            </td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-teal-300 border border-slate-700 uppercase font-bold">
                                {u.role}
                              </span>
                            </td>
                            <td className="p-2.5 text-slate-400">{u.createdAt}</td>
                            <td className="p-2.5 text-right">
                              {u.role !== "super_admin" && (
                                <button
                                  onClick={() => setDeleteConfirmId({ id: u.id, type: "user" })}
                                  className="text-rose-400 hover:text-rose-300 font-bold p-1 rounded hover:bg-rose-500/10"
                                  title="Delete User"
                                >
                                  <Trash2 className="w-4 h-4 inline" />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 3: PATIENT CAMPAIGNS & APPROVALS */}
            {activeTab === "campaigns" && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Database className="w-4 h-4 text-purple-400" />
                      Patient Medical Ledger & Auto-Manufacturer
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Manufacture patient records, approve pending registrations, or auto-sync all platform dashboards.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setIsManufacturing(!isManufacturing)}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{isManufacturing ? "Close Manufacturer" : "Manufacture Patient"}</span>
                    </button>

                    <button
                      onClick={handleRestoreDefaults}
                      title="Restore default sample patient campaigns"
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-teal-300 font-semibold text-xs rounded-xl border border-slate-700 flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-teal-400" />
                      <span>Restore Default Patients</span>
                    </button>

                    {dbCampaigns.length > 0 && (
                      <button
                        onClick={() => setDeleteConfirmId({ id: "all", type: "clear_all_campaigns" })}
                        className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 font-semibold text-xs rounded-xl border border-rose-800/80 flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        <span>Clear All Patients</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Super Admin Patient Manufacturer Form */}
                {isManufacturing && (
                  <form onSubmit={handleManufactureCampaign} className="bg-slate-900 border border-amber-500/40 p-4 sm:p-5 rounded-2xl space-y-4 animate-fade-in">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                          Super Admin Automatic Patient Manufacturer
                        </h4>
                      </div>
                      <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded font-mono border border-amber-500/30">
                        AUTO-SAVED TO ALL DASHBOARDS
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Patient Name *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Ramesh Kumar"
                          value={manufactureForm.patientName}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, patientName: e.target.value })}
                          className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Patient Age
                        </label>
                        <input
                          type="number"
                          value={manufactureForm.patientAge}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, patientAge: e.target.value })}
                          className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Required Goal Amount (₹) *
                        </label>
                        <input
                          type="number"
                          required
                          placeholder="e.g. 650000"
                          value={manufactureForm.requiredAmount}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, requiredAmount: e.target.value })}
                          className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-bold outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Diagnosis / Medical Condition *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Brain Tumor Surgery & ICU Care"
                          value={manufactureForm.diagnosis}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, diagnosis: e.target.value })}
                          className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Hospital Node *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. AIIMS New Delhi"
                          value={manufactureForm.hospitalName}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, hospitalName: e.target.value })}
                          className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Direct Hospital UPI ID
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. aiims.escrow@axisbank"
                          value={manufactureForm.upiId}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, upiId: e.target.value })}
                          className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-slate-300 font-mono outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                      <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                        <input
                          type="checkbox"
                          checked={manufactureForm.autoVerify}
                          onChange={(e) => setManufactureForm({ ...manufactureForm, autoVerify: e.target.checked })}
                          className="w-4 h-4 accent-amber-500 rounded"
                        />
                        <span className="font-semibold text-amber-400">
                          Auto-Verify & Assign Super Admin Verified Badge
                        </span>
                      </label>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setIsManufacturing(false)}
                          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow cursor-pointer"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Manufacture & Publish Record</span>
                        </button>
                      </div>
                    </div>
                  </form>
                )}

                {dbCampaigns.length === 0 ? (
                  <div className="text-center py-12 bg-slate-900/50 border border-dashed border-slate-800 rounded-2xl space-y-3">
                    <Database className="w-10 h-10 text-slate-600 mx-auto" />
                    <h4 className="text-sm font-bold text-slate-300">Patient Ledger is Empty</h4>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      All patient records have been cleared. Click "Manufacture Patient" to create a new record, or click "Restore Default Patients" to restore the sample campaigns.
                    </p>
                    <button
                      onClick={handleRestoreDefaults}
                      className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl inline-flex items-center gap-2 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Restore Default Patient Campaigns</span>
                    </button>
                  </div>
                ) : (
                  <div className="overflow-x-auto max-h-80">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-bold tracking-wider sticky top-0">
                        <tr>
                          <th className="p-2.5">Patient / ID</th>
                          <th className="p-2.5">Condition</th>
                          <th className="p-2.5">Hospital</th>
                          <th className="p-2.5">Target</th>
                          <th className="p-2.5">Status</th>
                          <th className="p-2.5 text-right">Verification Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                        {dbCampaigns
                          .filter(
                            (c) =>
                              !searchTerm ||
                              c.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              c.diagnosis.toLowerCase().includes(searchTerm.toLowerCase())
                          )
                          .map((c) => (
                            <tr key={c.id} className="hover:bg-slate-900/50">
                              <td className="p-2.5 font-sans font-bold text-white">
                                {c.patientName}
                                <span className="text-[10px] text-slate-500 font-mono block">{c.id}</span>
                              </td>
                              <td className="p-2.5 text-slate-300 font-sans">{c.diagnosis}</td>
                              <td className="p-2.5 text-slate-400 font-sans">{c.hospitalName}</td>
                              <td className="p-2.5 text-emerald-400 font-bold">₹{(c?.requiredAmount ?? 0).toLocaleString()}</td>
                              <td className="p-2.5">
                                {c.verifiedBadge || c.status === "verified_active" ? (
                                  <span className="px-2 py-0.5 rounded text-[9px] bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                                    VERIFIED
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded text-[9px] bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30">
                                    PENDING
                                  </span>
                                )}
                              </td>
                              <td className="p-2.5 text-right flex items-center justify-end gap-1.5">
                                {!c.verifiedBadge && c.status !== "verified_active" && (
                                  <button
                                    onClick={() => handleApproveCampaign(c.id)}
                                    className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[10px] flex items-center gap-1 cursor-pointer"
                                  >
                                    <Check className="w-3 h-3" /> Approve
                                  </button>
                                )}
                                <button
                                  onClick={() => setDeleteConfirmId({ id: c.id, type: "campaign" })}
                                  className="text-rose-400 hover:text-rose-300 font-bold p-1 rounded hover:bg-rose-500/10 cursor-pointer"
                                  title="Delete Patient Record"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB: WATCH ADS MANAGER */}
            {activeTab === "ads_manager" && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-5">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Tv className="w-4 h-4 text-purple-400" />
                      Watch Ads Ad Inventory & Media Manager
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Super Admin can post/edit video clips, custom banners (any size), photo ads, audio tracks, and action links for patient ad fundraising.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={handleRestoreSponsors}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reset Defaults</span>
                    </button>

                    <button
                      onClick={() => {
                        setEditingSponsor(null);
                        setSponsorForm({
                          brandName: "",
                          campaignTitle: "",
                          category: "Healthcare & Wellness",
                          videoDurationSeconds: 15,
                          payoutPerView: 35,
                          bannerText: "",
                          callToAction: "Visit Offer",
                          logoUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80",
                          imageUrl: "",
                          videoUrl: "",
                          audioUrl: "",
                          externalLink: "",
                          adType: "hybrid"
                        });
                        setIsAddingSponsor(true);
                      }}
                      className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Post New Ad Campaign</span>
                    </button>
                  </div>
                </div>

                {/* Form Modal for Creating / Editing Ad Campaign */}
                {(isAddingSponsor || editingSponsor) && (
                  <form onSubmit={handleSaveSponsor} className="bg-slate-900 border border-purple-500/40 p-4 sm:p-5 rounded-2xl space-y-4 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-2">
                        <Megaphone className="w-4 h-4" />
                        {editingSponsor ? `Edit Ad Campaign: ${editingSponsor.brandName}` : "Create & Publish New Watch Ad Campaign"}
                      </h4>
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingSponsor(false);
                          setEditingSponsor(null);
                        }}
                        className="p-1 text-slate-400 hover:text-white"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Brand / Sponsor Name *</label>
                        <input
                          type="text"
                          required
                          value={sponsorForm.brandName || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, brandName: e.target.value })}
                          placeholder="e.g. Apollo Pharmacy / Tech Brand"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Category</label>
                        <input
                          type="text"
                          value={sponsorForm.category || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, category: e.target.value })}
                          placeholder="e.g. Healthcare, Tech, Retail"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div className="sm:col-span-2 lg:col-span-1">
                        <label className="block text-slate-300 font-semibold mb-1">Campaign Title *</label>
                        <input
                          type="text"
                          required
                          value={sponsorForm.campaignTitle || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, campaignTitle: e.target.value })}
                          placeholder="e.g. Health Screening Awareness Drive"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Ad Duration (Seconds)</label>
                        <input
                          type="number"
                          min={5}
                          max={60}
                          value={sponsorForm.videoDurationSeconds || 15}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, videoDurationSeconds: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Payout Per View (₹)</label>
                        <input
                          type="number"
                          min={1}
                          value={sponsorForm.payoutPerView || 35}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, payoutPerView: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Ad Media Type</label>
                        <select
                          value={sponsorForm.adType || "hybrid"}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, adType: e.target.value as any })}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        >
                          <option value="hybrid">Hybrid (Image + Video + Link)</option>
                          <option value="image">Photo Banner (Any Size)</option>
                          <option value="video">Video Clip</option>
                          <option value="audio">Audio Track</option>
                          <option value="link">External Action Link</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">Photo Banner Image URL (Any Dimension/Size)</label>
                        <input
                          type="url"
                          value={sponsorForm.imageUrl || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, imageUrl: e.target.value })}
                          placeholder="https://images.unsplash.com/... or image link"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Sponsor Logo URL</label>
                        <input
                          type="url"
                          value={sponsorForm.logoUrl || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, logoUrl: e.target.value })}
                          placeholder="https://..."
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">Video Clip / Embed URL</label>
                        <input
                          type="url"
                          value={sponsorForm.videoUrl || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, videoUrl: e.target.value })}
                          placeholder="https://www.youtube.com/embed/... or MP4 video link"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Audio Track URL</label>
                        <input
                          type="url"
                          value={sponsorForm.audioUrl || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, audioUrl: e.target.value })}
                          placeholder="https://... MP3 audio clip"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-300 font-semibold mb-1">External Action / Promo Link URL</label>
                        <input
                          type="url"
                          value={sponsorForm.externalLink || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, externalLink: e.target.value })}
                          placeholder="https://www.brand-website.com/offer"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Button Call to Action Text</label>
                        <input
                          type="text"
                          value={sponsorForm.callToAction || "Visit Offer"}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, callToAction: e.target.value })}
                          placeholder="e.g. Visit Offer, Learn More"
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>

                      <div className="sm:col-span-2 lg:col-span-3">
                        <label className="block text-slate-300 font-semibold mb-1">Banner Description / Promo Message</label>
                        <textarea
                          rows={2}
                          value={sponsorForm.bannerText || ""}
                          onChange={(e) => setSponsorForm({ ...sponsorForm, bannerText: e.target.value })}
                          placeholder="e.g. Special offer for viewers supporting medical patients..."
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-purple-500"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingSponsor(false);
                          setEditingSponsor(null);
                        }}
                        className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow cursor-pointer flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>{editingSponsor ? "Update Campaign" : "Publish Ad Campaign"}</span>
                      </button>
                    </div>
                  </form>
                )}

                {/* List of Active Watch Ad Sponsors */}
                <div className="grid sm:grid-cols-2 gap-4">
                  {dbSponsors.map((sponsor) => (
                    <div
                      key={sponsor.id}
                      className="bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-2xl p-4 space-y-3 transition-all relative flex flex-col justify-between"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <img
                              src={sponsor.logoUrl}
                              alt={sponsor.brandName}
                              referrerPolicy="no-referrer"
                              className="w-12 h-12 rounded-xl object-cover bg-slate-800 shrink-0 border border-slate-700"
                            />
                            <div>
                              <span className="text-[10px] font-bold text-purple-400 block uppercase">
                                {sponsor.category}
                              </span>
                              <h4 className="text-sm font-bold text-white">
                                {sponsor.brandName}
                              </h4>
                              <p className="text-xs text-slate-400 font-medium">
                                {sponsor.campaignTitle}
                              </p>
                            </div>
                          </div>

                          <span className="text-xs font-black text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-2.5 py-1 rounded-lg shrink-0">
                            +₹{sponsor.payoutPerView} / {sponsor.videoDurationSeconds}s
                          </span>
                        </div>

                        {/* Banner Photo Preview if provided */}
                        {sponsor.imageUrl && (
                          <div className="rounded-xl overflow-hidden bg-slate-950 border border-slate-800 max-h-36 relative">
                            <img
                              src={sponsor.imageUrl}
                              alt={sponsor.brandName}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                            <span className="absolute bottom-1 right-1 bg-slate-900/90 text-white text-[9px] font-bold px-2 py-0.5 rounded border border-slate-700">
                              Photo Banner
                            </span>
                          </div>
                        )}

                        <p className="text-xs text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 italic">
                          "{sponsor.bannerText}"
                        </p>

                        {/* Media indicators */}
                        <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold text-slate-400">
                          {sponsor.videoUrl && (
                            <span className="bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded flex items-center gap-1">
                              <Video className="w-3 h-3" /> Video Clip
                            </span>
                          )}
                          {sponsor.audioUrl && (
                            <span className="bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded flex items-center gap-1">
                              <Music className="w-3 h-3" /> Audio
                            </span>
                          )}
                          {sponsor.externalLink && (
                            <span className="bg-teal-950 text-teal-300 border border-teal-800 px-2 py-0.5 rounded flex items-center gap-1">
                              <ExternalLink className="w-3 h-3" /> Promo Link
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800 mt-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingSponsor(sponsor);
                            setSponsorForm({ ...sponsor });
                            setIsAddingSponsor(false);
                          }}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-amber-400" />
                          <span>Edit</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteSponsor(sponsor.id)}
                          className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 text-xs font-bold rounded-xl border border-rose-800/80 transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: BACKUP & RESTORE */}
            {activeTab === "backup" && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-amber-400" />
                    Database Backup, Restore & Data Exports
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Export full JSON database snapshots, download audit logs, or restore database from backup.
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  {/* Backup Card */}
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                      <Download className="w-4 h-4" />
                      <span>Export Full Database JSON</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Creates a complete, encrypted offline backup containing all users, patients, and audit logs.
                    </p>
                    <button
                      onClick={handleExportJSON}
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download JSON Backup</span>
                    </button>
                  </div>

                  {/* Restore Card */}
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
                    <div className="flex items-center gap-2 text-teal-400 font-bold text-xs">
                      <Upload className="w-4 h-4" />
                      <span>Restore Database Snapshot</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Upload a previously exported HopeBridge JSON backup file to restore database state.
                    </p>
                    <label className="w-full py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer">
                      <Upload className="w-4 h-4" />
                      <span>Upload & Restore</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleRestoreBackup}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Confirmation Modal for Delete */}
            {deleteConfirmId && (
              <div className="fixed inset-0 z-70 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 max-w-sm w-full space-y-4 text-center">
                  <AlertTriangle className="w-10 h-10 text-rose-500 mx-auto animate-bounce" />
                  <h4 className="text-sm font-bold text-white">
                    {deleteConfirmId.type === "clear_all_campaigns"
                      ? "Clear All Patient Campaigns?"
                      : "Confirm Permanent Deletion"}
                  </h4>
                  <p className="text-xs text-slate-300">
                    {deleteConfirmId.type === "clear_all_campaigns"
                      ? "Are you sure you want to remove ALL patient records from the database? All dashboards will be cleared."
                      : `Are you sure you want to delete this ${deleteConfirmId.type} record from the database? This action cannot be undone.`}
                  </p>
                  <div className="flex justify-center gap-3">
                    <button
                      onClick={() => setDeleteConfirmId(null)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        if (deleteConfirmId.type === "user") {
                          handleDeleteUser(deleteConfirmId.id);
                        } else if (deleteConfirmId.type === "clear_all_campaigns") {
                          handleClearAllCampaigns();
                        } else {
                          handleDeleteCampaign(deleteConfirmId.id);
                        }
                      }}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                    >
                      {deleteConfirmId.type === "clear_all_campaigns" ? "Clear All Records" : "Permanently Delete"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-800 shrink-0">
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Database Integrity Guard: 100% Unique ID Enforcement Active
              </span>
              <button
                onClick={() => {
                  authService.logout();
                  setStep("auth");
                  onClose();
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Lock Super Admin Vault</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
