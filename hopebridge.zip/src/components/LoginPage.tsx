import React, { useState } from "react";
import { HopeBridgeLogo } from "./HopeBridgeLogo";
import { 
  Heart, 
  Lock, 
  Mail, 
  Phone, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  ArrowLeft, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  Building2, 
  Sparkles,
  KeyRound,
  X,
  ChevronRight
} from "lucide-react";
import { authService } from "../services/authService";
import { triggerOfficialGoogleSignIn } from "../services/googleAuth";
import { UserAccount, UserRole } from "../types";

interface LoginPageProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessLogin: (user: UserAccount) => void;
  onOpenSuperAdmin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  isOpen,
  onClose,
  onSuccessLogin,
  onOpenSuperAdmin,
}) => {
  const [mode, setMode] = useState<"login" | "register">("login");

  // Form State
  const [identifier, setIdentifier] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Google OAuth State
  const [isGoogleLoading, setIsGoogleLoading] = useState<boolean>(false);

  // Registration Extra State
  const [regName, setRegName] = useState<string>("");
  const [regEmail, setRegEmail] = useState<string>("");
  const [regMobile, setRegMobile] = useState<string>("");
  const [regPassword, setRegPassword] = useState<string>("");
  const [regRole, setRegRole] = useState<UserRole>("supporter");

  // Status & Feedback State
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setIsSubmitting(true);

    setTimeout(() => {
      const res = authService.loginUser(identifier, password);
      setIsSubmitting(false);

      if (!res.success || !res.user) {
        setErrorMessage(res.error || "Login failed. Please verify your credentials.");
      } else {
        setSuccessMessage(`Welcome back, ${res.user.name}! Redirecting...`);
        setTimeout(() => {
          onSuccessLogin(res.user);
          onClose();
        }, 600);
      }
    }, 400);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");
    setIsSubmitting(true);

    setTimeout(() => {
      const res = authService.registerUser({
        name: regName,
        email: regEmail,
        mobile: regMobile,
        password: regPassword,
        role: regRole,
      });
      setIsSubmitting(false);

      if (!res.success || !res.user) {
        setErrorMessage(res.error || "Registration failed.");
      } else {
        setSuccessMessage("Account created successfully! Redirecting...");
        setTimeout(() => {
          onSuccessLogin(res.user);
          onClose();
        }, 700);
      }
    }, 500);
  };

  const handleOfficialGoogleSignIn = async () => {
    setErrorMessage("");
    setSuccessMessage("");
    setIsGoogleLoading(true);

    try {
      // Triggers official Google Identity Services popup / Google OAuth window
      const profile = await triggerOfficialGoogleSignIn();
      const res = authService.loginOrRegisterGoogleUser(profile);
      setIsGoogleLoading(false);

      if (res.success && res.user) {
        setSuccessMessage(`Signed in as ${res.user.name} (${res.user.email}) via Google.`);
        setTimeout(() => {
          onSuccessLogin(res.user!);
          onClose();
        }, 600);
      } else {
        setErrorMessage(res.error || "Google authentication failed.");
      }
    } catch (err: any) {
      setIsGoogleLoading(false);
      const msg = err?.message || "";
      if (msg.toLowerCase().includes("closed") || msg.toLowerCase().includes("cancel")) {
        setErrorMessage("");
        setSuccessMessage("");
      } else {
        console.error("Official Google Sign-In Error:", err);
        setErrorMessage(msg || "Google Sign-In was canceled or encountered an error.");
      }
    }
  };


  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-white min-h-screen w-full flex flex-col justify-between p-6 sm:p-12 animate-fade-in antialiased selection:bg-teal-600 selection:text-white">
      
      {/* Top Header Bar */}
      <div className="max-w-xl mx-auto w-full flex items-center justify-between pb-6 shrink-0">
        <button
          onClick={onClose}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 transition-colors bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-2xl cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Landing Page</span>
        </button>

        <button 
          onClick={onOpenSuperAdmin}
          title="Secure Admin Vault Access"
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-amber-600 font-mono font-bold cursor-pointer transition-colors"
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Admin Vault</span>
        </button>
      </div>

      {/* Main Full-Screen Borderless Container */}
      <div className="max-w-md mx-auto w-full my-auto space-y-6">
        
        {/* PROMINENT LOGO DISPLAY */}
        <div className="text-center space-y-3 flex flex-col items-center">
          <HopeBridgeLogo 
            size="lg" 
            layout="vertical" 
            onClick={onClose} 
          />

          <div className="pt-2">
            <h2 className="text-xl font-bold text-slate-900">
              {mode === "login" ? "Account Sign In" : "Register HopeBridge Account"}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {mode === "login"
                ? "Access verified patient cases, hospital accounts & contribution tracking."
                : "Join thousands of verified donors, patients & hospitals across India."}
            </p>
          </div>
        </div>

        {/* Notifications */}
        {errorMessage && (
          <div className="p-4 bg-rose-50 rounded-2xl text-rose-800 text-xs font-medium flex items-start gap-3">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold block text-rose-900">Security Guard</span>
              {errorMessage}
            </div>
          </div>
        )}

        {successMessage && (
          <div className="p-4 bg-emerald-50 rounded-2xl text-emerald-800 text-xs font-medium flex items-center gap-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* LOGIN FORM */}
        {mode === "login" ? (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1.5">
                Email Address or Mobile Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="anita.sharma@example.com or +91 9876543210"
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-2xl text-xs font-medium text-slate-900 transition-all outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1.5">
                Account Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-11 pr-11 py-3 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-2xl text-xs font-medium text-slate-900 transition-all outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-600 select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-slate-300 text-teal-700 focus:ring-teal-600 w-4 h-4"
                />
                <span className="font-medium">Remember Session</span>
              </label>
              <button
                type="button"
                onClick={() => alert("Password reset link sent to your registered contact.")}
                className="text-teal-800 font-bold hover:underline"
              >
                Forgot Password?
              </button>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-teal-800 hover:bg-teal-900 text-white font-bold py-3.5 rounded-2xl shadow-xl shadow-teal-800/20 transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? (
                <span>Verifying Credentials...</span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Sign In Securely</span>
                </>
              )}
            </button>

            <div className="relative my-6 text-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-100"></div>
              </div>
              <span className="relative bg-white px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Or Continue With
              </span>
            </div>

            {/* Google OAuth Login */}
            <button
              type="button"
              onClick={handleOfficialGoogleSignIn}
              disabled={isSubmitting || isGoogleLoading}
              className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-200/80 text-slate-800 font-bold py-3 px-4 rounded-2xl transition-all text-xs flex items-center justify-center gap-3 cursor-pointer shadow-2xs group disabled:opacity-60"
            >
              <svg className="w-4 h-4 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{isGoogleLoading ? "Opening Google Sign-In..." : "Continue with Google"}</span>
            </button>

            <div className="pt-2 text-center text-xs text-slate-600">
              Don't have a HopeBridge account?{" "}
              <button
                type="button"
                onClick={() => {
                  setErrorMessage("");
                  setMode("register");
                }}
                className="text-teal-800 font-bold hover:underline cursor-pointer"
              >
                Register New Account
              </button>
            </div>
          </form>
        ) : (
          /* REGISTRATION FORM */
          <form onSubmit={handleRegisterSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="e.g. Priya Nair"
                className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-xl text-xs font-medium text-slate-900 transition-all outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Email Address * (Unique Verification)
              </label>
              <input
                type="email"
                required
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                placeholder="priya.nair@example.com"
                className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-xl text-xs font-medium text-slate-900 transition-all outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Mobile Phone Number * (Unique Verification)
              </label>
              <input
                type="tel"
                required
                value={regMobile}
                onChange={(e) => setRegMobile(e.target.value)}
                placeholder="+91 98765 00000"
                className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-xl text-xs font-medium text-slate-900 transition-all outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Account Password *
              </label>
              <input
                type="password"
                required
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-xl text-xs font-medium text-slate-900 transition-all outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Account Role
              </label>
              <select
                value={regRole}
                onChange={(e) => setRegRole(e.target.value as UserRole)}
                className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white border border-slate-200 focus:border-teal-600 rounded-xl text-xs font-medium text-slate-900 transition-all outline-none"
              >
                <option value="supporter">Donor & Ad Supporter</option>
                <option value="patient">Patient Family / Guardian</option>
                <option value="hospital">Hospital Administration Node</option>
                <option value="ngo">NGO Partner</option>
                <option value="field_agent">Field Verification Agent</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-teal-800 hover:bg-teal-900 text-white font-bold py-3.5 rounded-2xl shadow-xl shadow-teal-800/20 transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 mt-2"
            >
              {isSubmitting ? (
                <span>Checking Database Uniqueness...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Create Account</span>
                </>
              )}
            </button>

            <div className="pt-2 text-center text-xs text-slate-600">
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => {
                  setErrorMessage("");
                  setMode("login");
                }}
                className="text-teal-800 font-bold hover:underline cursor-pointer"
              >
                Sign In
              </button>
            </div>
          </form>
        )}

      </div>

      {/* Footer Security Badge */}
      <div className="max-w-md mx-auto w-full pt-6 text-center text-xs text-slate-400 font-medium shrink-0 flex items-center justify-center gap-1.5">
        <ShieldCheck className="w-4 h-4 text-emerald-600" />
        <span>HopeBridge 256-Bit SSL Encrypted & Anti-Duplicate Protected</span>
      </div>

    </div>
  );
};
