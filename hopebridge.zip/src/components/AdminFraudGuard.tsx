import React, { useState } from "react";
import { PatientCampaign } from "../types";
import { 
  ShieldAlert, 
  ShieldCheck, 
  Tv, 
  Heart, 
  AlertTriangle, 
  CheckCircle2, 
  Activity, 
  Users, 
  Lock,
  Sparkles,
  BarChart3,
  Sliders
} from "lucide-react";

interface AdminFraudGuardProps {
  campaigns: PatientCampaign[];
  totalAdRevenue: number;
  totalDirectDonations: number;
  totalAdsWatched: number;
}

export const AdminFraudGuard: React.FC<AdminFraudGuardProps> = ({
  campaigns,
  totalAdRevenue,
  totalDirectDonations,
  totalAdsWatched,
}) => {
  const [splitPatient, setSplitPatient] = useState<number>(95);
  const [splitOps, setSplitOps] = useState<number>(3);
  const [splitAdmin, setSplitAdmin] = useState<number>(2);

  const pendingVerificationCount = campaigns.filter(
    (c) => c.status === "pending_verification"
  ).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Admin Top Header */}
      <div className="bg-white border border-slate-200 text-slate-900 p-6 rounded-3xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-700 border border-rose-200 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Platform Control & AI Fraud Prevention Desk</h2>
            <p className="text-xs text-slate-500">
              Monitoring Ad Pool Integrity • Field Audit Logs • 95/3/2 Financial Split Guard
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="bg-emerald-100 text-emerald-800 font-bold text-xs px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" /> AI Guard Active
          </span>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Ad Revenue Pool Disbursed
          </span>
          <span className="text-2xl font-black text-purple-700 block">
            ₹{((totalAdRevenue || 0) / 100000).toFixed(1)} Lakhs
          </span>
          <span className="text-[11px] text-slate-500 flex items-center gap-1 pt-1">
            <Tv className="w-3.5 h-3.5 text-purple-600" />
            {(totalAdsWatched ?? 0).toLocaleString()} Ad Views Validated
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Direct Voluntary Donations
          </span>
          <span className="text-2xl font-black text-emerald-700 block">
            ₹{(totalDirectDonations / 100000).toFixed(1)} Lakhs
          </span>
          <span className="text-[11px] text-slate-500 flex items-center gap-1 pt-1">
            <Heart className="w-3.5 h-3.5 text-emerald-600 fill-current" />
            100% Tax 80G Receipts Issued
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Physical Field Verification Pass Rate
          </span>
          <span className="text-2xl font-black text-slate-900 block">
            98.4%
          </span>
          <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1 pt-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Zero Unverified Cases Live
          </span>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Pending Field Agent Audits
          </span>
          <span className="text-2xl font-black text-amber-600 block">
            {pendingVerificationCount} Cases
          </span>
          <span className="text-[11px] text-slate-500 flex items-center gap-1 pt-1">
            <Activity className="w-3.5 h-3.5 text-amber-500" /> Agents En Route
          </span>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Left: AI Fraud Detection Rules Monitor */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 space-y-5 shadow-sm">
          <div className="flex items-center justify-between border-b pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <h3 className="text-sm font-bold text-slate-900">
                Automated AI Fraud & Duplicate Detection Rules
              </h3>
            </div>
            <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded-full">
              Real-time Scan
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-800 block">
                  Aadhaar Government Checksum Validator
                </span>
                <span className="text-[11px] text-slate-500">
                  Verifies 12-digit Aadhaar Verhoeff algorithm & UIDAI digital structure
                </span>
              </div>
              <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-1 rounded">
                ACTIVE (0 Violations)
              </span>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-800 block">
                  Duplicate Image Search Engine
                </span>
                <span className="text-[11px] text-slate-500">
                  Scans reverse-image hash database to prevent copied internet patient photos
                </span>
              </div>
              <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-1 rounded">
                ACTIVE (0 Violations)
              </span>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-800 block">
                  Hospital Billing Estimate Anomaly Detection
                </span>
                <span className="text-[11px] text-slate-500">
                  Flags cost quotes that exceed standard disease treatment benchmarks by &gt;40%
                </span>
              </div>
              <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-1 rounded">
                ACTIVE (0 Violations)
              </span>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-800 block">
                  Medical Council Registration Lookup
                </span>
                <span className="text-[11px] text-slate-500">
                  Validates attending doctor MCI/NMC license numbers
                </span>
              </div>
              <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-1 rounded">
                ACTIVE (100% Match)
              </span>
            </div>
          </div>
        </div>

        {/* Right: Revenue Distribution Configuration */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-6 space-y-5 shadow-sm">
          <div className="flex items-center gap-2 border-b pb-3">
            <Sliders className="w-5 h-5 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Revenue Split Model (Sustainable Platform Policy)
            </h3>
          </div>

          <div className="space-y-4 text-xs">
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-2">
              <div className="flex justify-between font-bold text-emerald-950">
                <span>Direct Patient Hospital Escrow:</span>
                <span className="text-emerald-700 text-base">{splitPatient}%</span>
              </div>
              <input
                type="range"
                min={90}
                max={98}
                value={splitPatient}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setSplitPatient(val);
                  setSplitOps(100 - val - splitAdmin);
                }}
                className="w-full accent-emerald-600"
              />
              <p className="text-[11px] text-emerald-800">
                Transferred directly to verified hospital accounts to pay surgery & ICU invoices.
              </p>
            </div>

            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl space-y-1">
              <div className="flex justify-between font-bold text-amber-950">
                <span>Field Verification & Ops:</span>
                <span className="text-amber-700 font-bold">{splitOps}%</span>
              </div>
              <p className="text-[11px] text-amber-800">
                Funds travel allowances & verification kits for physical field agents.
              </p>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-1">
              <div className="flex justify-between font-bold text-slate-900">
                <span>Platform Tech & Server Costs:</span>
                <span className="text-slate-700 font-bold">{splitAdmin}%</span>
              </div>
              <p className="text-[11px] text-slate-600">
                Maintains cloud servers, payment gateway fees, and bandwidth.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
