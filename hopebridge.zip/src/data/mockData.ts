import { PatientCampaign, TransparencyLedgerEntry, AdSponsor, UserSupportProfile } from "../types";

export const initialSponsors: AdSponsor[] = [
  {
    id: "sp-1",
    brandName: "Apollo Pharmacy & Wellness",
    logoUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=150&auto=format&fit=crop&q=80",
    campaignTitle: "Preventative Cardiac Care & Health Screening",
    videoDurationSeconds: 15,
    payoutPerView: 35,
    bannerText: "Get 20% off comprehensive health checkups at Apollo Pharmacy",
    callToAction: "Book Free Consultation",
    category: "Healthcare & Wellness"
  },
  {
    id: "sp-2",
    brandName: "Tata Trusts Healthcare Mission",
    logoUrl: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=150&auto=format&fit=crop&q=80",
    campaignTitle: "Early Cancer Detection Awareness Drive",
    videoDurationSeconds: 15,
    payoutPerView: 40,
    bannerText: "Early detection saves 90% of oncology cases. Learn signs today.",
    callToAction: "Download Screening Guide",
    category: "Social Impact & Health"
  },
  {
    id: "sp-3",
    brandName: "Mankind Pharma Cares",
    logoUrl: "https://images.unsplash.com/photo-1631815588090-d4bfec5b1cdb?w=150&auto=format&fit=crop&q=80",
    campaignTitle: "Essential Pediatric Nutrition & Rare Disease Aid",
    videoDurationSeconds: 12,
    payoutPerView: 30,
    bannerText: "Supporting families battling rare pediatric genetic disorders across India.",
    callToAction: "Learn More About Rare Diseases",
    category: "Pharmaceuticals"
  },
  {
    id: "sp-4",
    brandName: "Max Bupa Health Protection",
    logoUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=150&auto=format&fit=crop&q=80",
    campaignTitle: "Cashless Critical Illness Medical Coverage",
    videoDurationSeconds: 15,
    payoutPerView: 50,
    bannerText: "Zero co-pay critical illness cover for organ transplants and ICU admissions.",
    callToAction: "Check Free Eligibility",
    category: "Insurance & Finance"
  }
];

export const initialCampaigns: PatientCampaign[] = [
  {
    id: "camp-1",
    patientName: "Baby Aarav Sharma",
    patientAge: 2,
    gender: "Male",
    guardianName: "Rajesh Sharma (Father)",
    contactPhone: "+91 98765 43210",
    diagnosis: "Spinal Muscular Atrophy (SMA Type 1) - Urgent Zolgensma Gene Therapy",
    category: "SMA",
    hospitalName: "Fortis Memorial Research Institute",
    hospitalCity: "Gurugram, NCR",
    doctorName: "Dr. Anupam Sachdeva",
    doctorRegNo: "MCI-34892",
    requiredAmount: 16000000, // ₹1.6 Crore (16M)
    collectedAmount: 11840000, // ₹1.18 Crore
    adRevenueAmount: 4200000,  // ₹42 Lakhs from ads!
    directDonationAmount: 7640000,
    adWatchCount: 120000,
    shareCount: 18450,
    verifiedBadge: true,
    status: "verified_active",
    emergencyPriority: true,
    story: "Baby Aarav was diagnosed with Spinal Muscular Atrophy (SMA Type 1) at 14 months old. SMA is a rare genetic disease that causes rapid loss of motor neurons, making it difficult to breathe or swallow independently. The doctor has prescribed Zolgensma, a one-time gene therapy injection. With your ad views and direct support, Aarav has reached 74% of his goal. Every 15-second ad you watch contributes ₹35 directly into Fortis Hospital's account for Aarav's dose.",
    patientPhoto: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=800&auto=format&fit=crop&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=1200&auto=format&fit=crop&q=80",
    treatmentBreakdown: [
      { id: "t1", name: "Zolgensma Gene Therapy Dose (Imported)", cost: 14500000, category: "Medication/Gene Therapy" },
      { id: "t2", name: "ICU Admission & Pediatric Ventilation (14 Days)", cost: 950000, category: "ICU Stay" },
      { id: "t3", name: "Post-Infusion Immunosuppressant Monitoring", cost: 550000, category: "Post-Op Rehab" }
    ],
    verificationReport: {
      agentId: "agt-101",
      agentName: "Suresh Kumar (Senior Field Auditor)",
      agentPhone: "+91 91234 56789",
      visitTimestamp: "2026-07-21 11:30 AM",
      gpsLocation: {
        lat: 28.4595,
        lng: 77.0266,
        addressName: "Fortis Hospital, Sector 44, Gurugram, Haryana"
      },
      hospitalAdmissionNo: "FMRI-ICU-2026-8812",
      homeVisitCompleted: true,
      hospitalBedVerified: true,
      doctorConfirmed: true,
      doctorRegNo: "MCI-34892",
      auditScore: 100,
      reportSummary: "Physically visited Fortis Memorial Research Institute. Verified Aarav in Pediatric ICU Bed #4. Cross-checked estimate invoice with Fortis billing desk. Verified father's Aadhaar & original doctor prescription stamp.",
      photos: [
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=600&auto=format&fit=crop&q=80"
      ]
    },
    documents: [
      { id: "doc-1", title: "Aadhaar Card - Aarav Sharma", type: "Aadhaar", url: "#", uploadDate: "2026-07-15", verified: true },
      { id: "doc-2", title: "Fortis Medical Estimate (₹1.6 Cr)", type: "Hospital Estimate", url: "#", uploadDate: "2026-07-16", verified: true },
      { id: "doc-3", title: "Doctor Prescription - Dr. Anupam Sachdeva", type: "Doctor Prescription", url: "#", uploadDate: "2026-07-16", verified: true },
      { id: "doc-4", title: "Genetic Test Diagnosis Report (SMN1 Exon Deletion)", type: "Diagnosis Report", url: "#", uploadDate: "2026-07-16", verified: true }
    ],
    updates: [
      {
        id: "up-1",
        date: "2026-07-24",
        title: "Weight Check Passed & Gene Therapy Application Filed",
        content: "Aarav completed his routine liver function tests today at Fortis. Dr. Sachdeva confirmed that Aarav's organ health is optimal for the infusion once the final drug import license arrives.",
        author: "Fortis Pediatric Desk",
        role: "Hospital"
      },
      {
        id: "up-2",
        date: "2026-07-20",
        title: "Ad Watchers Generated Over ₹42 Lakhs!",
        content: "We are deeply moved! Over 120,000 citizens watched ads for Aarav without spending a rupee. Thank you HopeBridge community!",
        author: "Rajesh Sharma (Father)",
        role: "Family"
      }
    ],
    donorList: [
      { id: "d-1", name: "Ad Watcher Pool (120,000 Views)", amount: 4200000, type: "ad", timestamp: "2026-07-25 08:30 AM", adsWatchedCount: 120000 },
      { id: "d-2", name: "Anand Mahindra CSR Support", amount: 2500000, type: "direct", timestamp: "2026-07-23 04:15 PM", message: "Sending prayers and strength to little Aarav!", transactionId: "UTR-882103948" },
      { id: "d-3", name: "Priya Venkatesh", amount: 10000, type: "direct", timestamp: "2026-07-24 02:20 PM", message: "Get well soon baby Aarav!", transactionId: "UPI-918230192" }
    ],
    paymentDetails: {
      upiId: "fortis.aarav@upi",
      accountNumber: "926010048123901",
      ifscCode: "UTIB0000812",
      bankName: "Axis Bank (Fortis Escrow Branch)",
      accountHolderName: "Fortis Hospitals Ltd - A/C Baby Aarav",
      qrCodeUrl: "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=fortis.aarav@upi&pn=Fortis%20Hospital%20Aarav&cu=INR",
      extraNotes: "100% Direct Hospital Escrow Account. Zero platform deduction."
    },
    createdAt: "2026-07-15"
  },
  {
    id: "camp-2",
    patientName: "Ananya Deshmukh",
    patientAge: 8,
    gender: "Female",
    guardianName: "Sunil Deshmukh (Father)",
    contactPhone: "+91 97654 32109",
    diagnosis: "Relapsed Acute Lymphoblastic Leukemia - CAR-T Cell Immunotherapy",
    category: "Cancer",
    hospitalName: "Tata Memorial Hospital & ACTREC",
    hospitalCity: "Mumbai, Maharashtra",
    doctorName: "Dr. Brijesh Arora",
    doctorRegNo: "MCI-19823",
    requiredAmount: 4500000, // ₹45 Lakhs
    collectedAmount: 3250000, // ₹32.5 Lakhs
    adRevenueAmount: 1420000, // ₹14.2 Lakhs from ad watching
    directDonationAmount: 1830000,
    adWatchCount: 38000,
    shareCount: 9200,
    verifiedBadge: true,
    status: "verified_active",
    emergencyPriority: true,
    story: "Ananya, an 8-year-old bright student from Pune, suffered a relapse of Acute Lymphoblastic Leukemia after 2 years of chemotherapy. Doctors at Tata Memorial Mumbai recommended indigenous CAR-T Cell Therapy (NexCAR19). Her father works as a schoolbus driver and has exhausted all savings. Through HopeBridge ad-watching, thousands of students and employees are supporting her daily.",
    patientPhoto: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=800&auto=format&fit=crop&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=1200&auto=format&fit=crop&q=80",
    treatmentBreakdown: [
      { id: "t1", name: "NexCAR19 Cell Infusion & Manufacturing", cost: 3000000, category: "Surgery" },
      { id: "t2", name: "Lymphodepleting Chemotherapy & ICU Stay", cost: 1000000, category: "ICU Stay" },
      { id: "t3", name: "Bone Marrow Biopsy & Cytokine Monitoring", cost: 500000, category: "Diagnostics" }
    ],
    verificationReport: {
      agentId: "agt-102",
      agentName: "Priya Nair (Mumbai Field Lead)",
      agentPhone: "+91 98111 22233",
      visitTimestamp: "2026-07-22 02:15 PM",
      gpsLocation: {
        lat: 19.0028,
        lng: 72.8427,
        addressName: "Tata Memorial Hospital, Parel, Mumbai"
      },
      hospitalAdmissionNo: "TMH-ONCO-2026-4401",
      homeVisitCompleted: true,
      hospitalBedVerified: true,
      doctorConfirmed: true,
      doctorRegNo: "MCI-19823",
      auditScore: 98,
      reportSummary: "Met Dr. Brijesh Arora at Tata Memorial. Verified patient in Ward 5A. Validated estimate letterhead and verified father's income certificate.",
      photos: [
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600&auto=format&fit=crop&q=80"
      ]
    },
    documents: [
      { id: "doc-1", title: "Aadhaar Card - Ananya Deshmukh", type: "Aadhaar", url: "#", uploadDate: "2026-07-18", verified: true },
      { id: "doc-2", title: "Tata Memorial Cost Estimate", type: "Hospital Estimate", url: "#", uploadDate: "2026-07-18", verified: true }
    ],
    updates: [
      {
        id: "up-1",
        date: "2026-07-23",
        title: "T-Cell Harvest Completed Successfully",
        content: "Doctors at ACTREC Kharghar successfully collected Ananya's T-cells for CAR-T modification. Processing will take 12 days.",
        author: "Tata Memorial Desk",
        role: "Hospital"
      }
    ],
    donorList: [
      { id: "d-1", name: "Ad Watcher Pool (38,000 Views)", amount: 1420000, type: "ad", timestamp: "2026-07-25 07:45 AM", adsWatchedCount: 38000 },
      { id: "d-2", name: "Anonymous Corporate Supporter", amount: 500000, type: "direct", timestamp: "2026-07-21 11:00 AM", transactionId: "UTR-554109823" }
    ],
    paymentDetails: {
      upiId: "tatamemorial.ananya@upi",
      accountNumber: "8820109482103",
      ifscCode: "SBIN0001802",
      bankName: "State Bank of India (Parel Branch)",
      accountHolderName: "Tata Memorial Trust - Patient Ananya",
      qrCodeUrl: "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=tatamemorial.ananya@upi&pn=Tata%20Memorial%20Ananya&cu=INR",
      extraNotes: "100% Verified Tata Memorial Cancer Hospital Account"
    },
    createdAt: "2026-07-18"
  },
  {
    id: "camp-3",
    patientName: "Master Rohan Kumar",
    patientAge: 5,
    gender: "Male",
    guardianName: "Sunita Kumar (Mother)",
    contactPhone: "+91 91234 88776",
    diagnosis: "Congenital Heart Defect - Complex Open Heart VSD Repair",
    category: "Cardiac",
    hospitalName: "Narayana Institute of Cardiac Sciences",
    hospitalCity: "Bengaluru, Karnataka",
    doctorName: "Dr. Devi Shetty",
    doctorRegNo: "MCI-11029",
    requiredAmount: 850000, // ₹8.5 Lakhs
    collectedAmount: 680000, // ₹6.8 Lakhs
    adRevenueAmount: 390000, // ₹3.9 Lakhs from ads
    directDonationAmount: 290000,
    adWatchCount: 11500,
    shareCount: 4100,
    verifiedBadge: true,
    status: "verified_active",
    emergencyPriority: true,
    story: "Rohan was born with a severe ventricular septal defect (hole in heart) that causes extreme breathing distress and blue spells. He urgently needs corrective open-heart surgery at Narayana Health Bengaluru. His mother is a domestic worker. You can help Rohan undergo surgery this week simply by watching ads or donating.",
    patientPhoto: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=800&auto=format&fit=crop&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=1200&auto=format&fit=crop&q=80",
    treatmentBreakdown: [
      { id: "t1", name: "Open Heart Patch Closure Surgery & Bypass Machine", cost: 550000, category: "Surgery" },
      { id: "t2", name: "Pediatric Cardiac ICU & Ventilator (5 Days)", cost: 200000, category: "ICU Stay" },
      { id: "t3", name: "Post-Op Echocardiogram & Medications", cost: 100000, category: "Diagnostics" }
    ],
    verificationReport: {
      agentId: "agt-103",
      agentName: "Karthik R (Bengaluru Field Officer)",
      agentPhone: "+91 94444 55566",
      visitTimestamp: "2026-07-23 10:00 AM",
      gpsLocation: {
        lat: 12.8256,
        lng: 77.6917,
        addressName: "Narayana Health City, Bommasandra, Bengaluru"
      },
      hospitalAdmissionNo: "NH-CARDIAC-8902",
      homeVisitCompleted: true,
      hospitalBedVerified: true,
      doctorConfirmed: true,
      doctorRegNo: "MCI-11029",
      auditScore: 100,
      reportSummary: "Met Pediatric Cardiac Team at Narayana Health. Verified echocardiogram reports confirming large VSD. Estimate verified.",
      photos: []
    },
    documents: [
      { id: "doc-1", title: "Narayana Health Estimate Letter", type: "Hospital Estimate", url: "#", uploadDate: "2026-07-20", verified: true }
    ],
    updates: [],
    donorList: [
      { id: "d-1", name: "Ad Watcher Community", amount: 390000, type: "ad", timestamp: "2026-07-25 08:00 AM", adsWatchedCount: 11500 }
    ],
    paymentDetails: {
      upiId: "narayana.rohan@upi",
      accountNumber: "5010029381029",
      ifscCode: "HDFC0000184",
      bankName: "HDFC Bank (Narayana Health Branch)",
      accountHolderName: "Narayana Hrudayalaya Ltd - Patient Rohan",
      qrCodeUrl: "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=narayana.rohan@upi&pn=Narayana%20Health%20Rohan&cu=INR",
      extraNotes: "100% Direct Pediatric Cardiac Ward Escrow Account."
    },
    createdAt: "2026-07-20"
  },
  {
    id: "camp-4",
    patientName: "Meera Devi",
    patientAge: 34,
    gender: "Female",
    guardianName: "Ramesh Chand (Husband)",
    contactPhone: "+91 98999 11223",
    diagnosis: "Acute End-Stage Liver Failure - Living Donor Liver Transplant",
    category: "Transplant",
    hospitalName: "Medanta - The Medicity",
    hospitalCity: "Gurugram, Haryana",
    doctorName: "Dr. Arvinder Singh Soin",
    doctorRegNo: "MCI-22104",
    requiredAmount: 2800000, // ₹28 Lakhs
    collectedAmount: 1890000,
    adRevenueAmount: 850000,
    directDonationAmount: 1040000,
    adWatchCount: 24000,
    shareCount: 5600,
    verifiedBadge: true,
    status: "verified_active",
    emergencyPriority: false,
    story: "Meera Devi, a mother of two young children, was struck by sudden viral hepatitis leading to acute liver failure. Her younger brother has been cleared as a matching living liver donor. The transplant team at Medanta Gurugram requires ₹28 Lakhs for the dual surgery (donor & recipient).",
    patientPhoto: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&auto=format&fit=crop&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1200&auto=format&fit=crop&q=80",
    treatmentBreakdown: [
      { id: "t1", name: "Dual Hepatectomy & Liver Transplant Surgery", cost: 1800000, category: "Surgery" },
      { id: "t2", name: "Isolation ICU & Immunosuppressant Therapy", cost: 700000, category: "ICU Stay" },
      { id: "t3", name: "Donor Recovery & Post-Op Care", cost: 300000, category: "Post-Op Rehab" }
    ],
    documents: [],
    updates: [],
    donorList: [],
    paymentDetails: {
      upiId: "medanta.meera@upi",
      accountNumber: "00181040029103",
      ifscCode: "ICIC0000018",
      bankName: "ICICI Bank (Medanta Gurugram)",
      accountHolderName: "Global Health Ltd - A/C Meera Devi",
      qrCodeUrl: "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=medanta.meera@upi&pn=Medanta%20Meera%20Devi&cu=INR",
      extraNotes: "Verified Medanta Liver Transplant Escrow Account."
    },
    createdAt: "2026-07-19"
  }
];

export const initialLedger: TransparencyLedgerEntry[] = [
  {
    id: "tx-1001",
    timestamp: "2026-07-25 08:45:12",
    patientId: "camp-1",
    patientName: "Baby Aarav Sharma",
    type: "AD_REVENUE",
    grossAmount: 35,
    patientFund95: 33.25,
    ops3: 1.05,
    admin2: 0.70,
    transactionHash: "0x8f192a...c4e1",
    sponsorName: "Apollo Pharmacy",
    paymentMode: "Ad Network Settlement"
  },
  {
    id: "tx-1002",
    timestamp: "2026-07-25 08:42:01",
    patientId: "camp-2",
    patientName: "Ananya Deshmukh",
    type: "DIRECT_DONATION",
    grossAmount: 2500,
    patientFund95: 2375,
    ops3: 75,
    admin2: 50,
    transactionHash: "UPI-428190-8812",
    sponsorName: "Direct Donor (Siddharth M.)",
    paymentMode: "Razorpay UPI"
  },
  {
    id: "tx-1003",
    timestamp: "2026-07-24 16:30:00",
    patientId: "camp-1",
    patientName: "Baby Aarav Sharma",
    type: "HOSPITAL_DISBURSAL",
    grossAmount: 2500000,
    patientFund95: 2500000,
    ops3: 0,
    admin2: 0,
    transactionHash: "NEFT-FORTIS-20260724",
    sponsorName: "HopeBridge Escrow -> Fortis Memorial",
    paymentMode: "Direct Escrow NEFT"
  }
];

export const initialUserProfile: UserSupportProfile = {
  name: "Community Supporter",
  adsWatched: 12,
  adRevenueGenerated: 420,
  directDonationsGiven: 1000,
  campaignsShared: 8,
  impactPoints: 640,
  badges: ["Verified Ad Supporter", "Life Saver Tier I", "Community Ambassador"]
};
