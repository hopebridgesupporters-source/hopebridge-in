import { UserAccount, UserRole, AuditLog } from "../types";

const USERS_STORAGE_KEY = "hopebridge_users_v2";
const CURRENT_SESSION_KEY = "hopebridge_current_user_v2";
const AUDIT_LOGS_KEY = "hopebridge_audit_logs_v2";

// Initial seed accounts for authentic system verification
const DEFAULT_ACCOUNTS: UserAccount[] = [
  {
    id: "usr-001-sup",
    name: "Anita Sharma",
    email: "anita.sharma@example.com",
    mobile: "+91 9876543210",
    passwordHash: "password123",
    role: "supporter",
    createdAt: "2026-01-15",
    lastLogin: new Date().toISOString(),
    isVerified: true,
  },
  {
    id: "usr-002-pat",
    name: "Rajesh Kumar (Father of Aarav)",
    email: "rajesh.kumar@example.com",
    mobile: "+91 9812345678",
    passwordHash: "password123",
    role: "patient",
    aadhaar: "1234-5678-9012",
    createdAt: "2026-02-10",
    lastLogin: new Date().toISOString(),
    isVerified: true,
  },
  {
    id: "usr-003-hos",
    name: "Fortis Healthcare Hospital Board",
    email: "desk@fortis.org",
    mobile: "+91 9988776655",
    passwordHash: "fortis123",
    role: "hospital",
    hospitalRegNo: "HOSP-KA-2024-8891",
    createdAt: "2025-11-01",
    lastLogin: new Date().toISOString(),
    isVerified: true,
  },
  {
    id: "usr-004-agt",
    name: "Vikram Sethi (Senior Verification Agent)",
    email: "vikram.agent@hopebridge.org",
    mobile: "+91 9123456789",
    passwordHash: "agent123",
    role: "field_agent",
    createdAt: "2025-12-05",
    lastLogin: new Date().toISOString(),
    isVerified: true,
  },
  {
    id: "usr-005-ngo",
    name: "Child Heart Care Foundation NGO",
    email: "contact@childheartngo.org",
    mobile: "+91 9833445566",
    passwordHash: "ngo12345",
    role: "ngo",
    ngoRegNo: "NGO-IND-88219-B",
    createdAt: "2025-08-20",
    lastLogin: new Date().toISOString(),
    isVerified: true,
  },
  {
    id: "usr-000-admin",
    name: "HopeBridge Executive Owner",
    email: "admin@hopebridge.org",
    mobile: "+91 9900000000",
    passwordHash: "SuperSecretAdmin2026!",
    role: "super_admin",
    createdAt: "2025-01-01",
    lastLogin: new Date().toISOString(),
    twoFactorEnabled: true,
    deviceVerified: true,
    isVerified: true,
  }
];

class AuthService {
  private getUsers(): UserAccount[] {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      if (!stored) {
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(DEFAULT_ACCOUNTS));
        return DEFAULT_ACCOUNTS;
      }
      return JSON.parse(stored);
    } catch {
      return DEFAULT_ACCOUNTS;
    }
  }

  private saveUsers(users: UserAccount[]) {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (e) {
      console.error("Failed to persist users:", e);
    }
  }

  public getAuditLogs(): AuditLog[] {
    try {
      const stored = localStorage.getItem(AUDIT_LOGS_KEY);
      return stored ? JSON.parse(stored) : [
        {
          id: "log-1",
          timestamp: new Date().toISOString(),
          userId: "usr-000-admin",
          userName: "HopeBridge Executive Owner",
          userRole: "super_admin",
          action: "SUPER_ADMIN_2FA_LOGIN_SUCCESS",
          ipAddress: "157.34.112.90",
          deviceInfo: "Chrome 122.0 (macOS)",
          status: "SUCCESS"
        }
      ];
    } catch {
      return [];
    }
  }

  public logAudit(log: Omit<AuditLog, "id" | "timestamp">) {
    try {
      const logs = this.getAuditLogs();
      const newEntry: AuditLog = {
        id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        timestamp: new Date().toISOString(),
        ...log
      };
      const updated = [newEntry, ...logs.slice(0, 99)]; // keep latest 100
      localStorage.setItem(AUDIT_LOGS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error("Audit log error:", e);
    }
  }

  /**
   * Database Validation Checks before creation
   */
  public checkDuplicates(data: {
    email?: string;
    mobile?: string;
    aadhaar?: string;
    hospitalRegNo?: string;
    ngoRegNo?: string;
  }): { isDuplicate: boolean; field?: string; message?: string } {
    const users = this.getUsers();

    const cleanEmail = data.email?.trim().toLowerCase();
    const cleanMobile = data.mobile?.trim().replace(/\s+/g, '');
    const cleanAadhaar = data.aadhaar?.trim().replace(/\s+/g, '');
    const cleanHosp = data.hospitalRegNo?.trim().toLowerCase();
    const cleanNgo = data.ngoRegNo?.trim().toLowerCase();

    for (const u of users) {
      if (cleanEmail && u.email.toLowerCase() === cleanEmail) {
        return {
          isDuplicate: true,
          field: "Email",
          message: "An account with this Email already exists. Please sign in."
        };
      }
      if (cleanMobile && u.mobile.replace(/\s+/g, '') === cleanMobile) {
        return {
          isDuplicate: true,
          field: "Mobile",
          message: "An account with this Mobile Number already exists. Please sign in."
        };
      }
      if (cleanAadhaar && u.aadhaar && u.aadhaar.replace(/\s+/g, '') === cleanAadhaar) {
        return {
          isDuplicate: true,
          field: "Aadhaar",
          message: "A patient account with this Aadhaar number already exists."
        };
      }
      if (cleanHosp && u.hospitalRegNo && u.hospitalRegNo.toLowerCase() === cleanHosp) {
        return {
          isDuplicate: true,
          field: "Hospital Reg",
          message: "A hospital profile with this Registration Number already exists."
        };
      }
      if (cleanNgo && u.ngoRegNo && u.ngoRegNo.toLowerCase() === cleanNgo) {
        return {
          isDuplicate: true,
          field: "NGO Reg",
          message: "An NGO profile with this Registration Number already exists."
        };
      }
    }

    return { isDuplicate: false };
  }

  /**
   * Register a new unique account
   */
  public registerUser(data: {
    name: string;
    email: string;
    mobile: string;
    password: string;
    role?: UserRole;
    aadhaar?: string;
    hospitalRegNo?: string;
    ngoRegNo?: string;
  }): { success: boolean; user?: UserAccount; error?: string } {
    // 1. Sanitize inputs
    const name = data.name.trim();
    const email = data.email.trim().toLowerCase();
    const mobile = data.mobile.trim();
    const password = data.password.trim();
    const role: UserRole = data.role || "supporter";

    if (!name || name.length < 2) {
      return { success: false, error: "Please enter a valid full name." };
    }
    if (!email || !email.includes("@")) {
      return { success: false, error: "Please provide a valid email address." };
    }
    if (!mobile || mobile.length < 8) {
      return { success: false, error: "Please provide a valid contact phone number." };
    }
    if (!password || password.length < 6) {
      return { success: false, error: "Password must be at least 6 characters long." };
    }

    // 2. Database validation check for duplicates
    const dupCheck = this.checkDuplicates({
      email,
      mobile,
      aadhaar: data.aadhaar,
      hospitalRegNo: data.hospitalRegNo,
      ngoRegNo: data.ngoRegNo
    });

    if (dupCheck.isDuplicate) {
      return { success: false, error: dupCheck.message };
    }

    // 3. Create unique user account
    const newUserId = `usr-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const newUser: UserAccount = {
      id: newUserId,
      name,
      email,
      mobile,
      passwordHash: password, // In production encrypted server-side
      role,
      aadhaar: data.aadhaar,
      hospitalRegNo: data.hospitalRegNo,
      ngoRegNo: data.ngoRegNo,
      createdAt: new Date().toISOString().split("T")[0],
      lastLogin: new Date().toISOString(),
      isVerified: true
    };

    const users = this.getUsers();
    users.push(newUser);
    this.saveUsers(users);

    this.logAudit({
      userId: newUser.id,
      userName: newUser.name,
      userRole: newUser.role,
      action: `ACCOUNT_CREATED_${role.toUpperCase()}`,
      ipAddress: "127.0.0.1",
      deviceInfo: navigator.userAgent || "Web Browser",
      status: "SUCCESS"
    });

    // Automatically sign in
    this.setCurrentSession(newUser);

    return { success: true, user: newUser };
  }

  /**
   * Login with email/mobile + password
   */
  public loginUser(identifier: string, password: string): { success: boolean; user?: UserAccount; error?: string } {
    const cleanId = identifier.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanId || !cleanPass) {
      return { success: false, error: "Please enter your Email/Mobile and Password." };
    }

    const users = this.getUsers();
    const matchedUser = users.find((u) => {
      const matchEmail = u.email.toLowerCase() === cleanId;
      const matchMobile = u.mobile.replace(/\s+/g, '') === cleanId.replace(/\s+/g, '');
      return matchEmail || matchMobile;
    });

    if (!matchedUser) {
      this.logAudit({
        userId: "UNKNOWN",
        userName: cleanId,
        userRole: "supporter",
        action: "LOGIN_FAILED_NOT_FOUND",
        ipAddress: "127.0.0.1",
        deviceInfo: navigator.userAgent || "Web Browser",
        status: "FAILED"
      });
      return { success: false, error: "No account found with this Email or Mobile Number. Please register." };
    }

    if (matchedUser.passwordHash !== cleanPass) {
      this.logAudit({
        userId: matchedUser.id,
        userName: matchedUser.name,
        userRole: matchedUser.role,
        action: "LOGIN_FAILED_WRONG_PASSWORD",
        ipAddress: "127.0.0.1",
        deviceInfo: navigator.userAgent || "Web Browser",
        status: "FAILED"
      });
      return { success: false, error: "Incorrect password. Please try again or click Forgot Password." };
    }

    // Update last login
    matchedUser.lastLogin = new Date().toISOString();
    this.saveUsers(users);

    this.logAudit({
      userId: matchedUser.id,
      userName: matchedUser.name,
      userRole: matchedUser.role,
      action: "LOGIN_SUCCESSFUL",
      ipAddress: "127.0.0.1",
      deviceInfo: navigator.userAgent || "Web Browser",
      status: "SUCCESS"
    });

    this.setCurrentSession(matchedUser);
    return { success: true, user: matchedUser };
  }

  /**
   * Official Google OAuth 2.0 / GIS Profile Authentication
   * Stores user in local/server database, logs in existing user or registers new user without duplicates.
   */
  public loginOrRegisterGoogleUser(profile: {
    sub: string;
    name: string;
    email: string;
    picture?: string;
  }): { success: boolean; user?: UserAccount; error?: string } {
    if (!profile || !profile.email) {
      return { success: false, error: "Invalid Google profile data returned." };
    }

    const users = this.getUsers();
    const cleanEmail = profile.email.trim().toLowerCase();

    // Check if account already exists with this email or Google UID
    let existingUser = users.find(
      (u) => u.email.toLowerCase() === cleanEmail || (u as any).googleUid === profile.sub
    );

    if (existingUser) {
      existingUser.lastLogin = new Date().toISOString();
      if (profile.picture) {
        existingUser.avatarUrl = profile.picture;
      }
      if (profile.name && (!existingUser.name || existingUser.name === "User")) {
        existingUser.name = profile.name;
      }
      (existingUser as any).googleUid = profile.sub;

      this.saveUsers(users);

      this.logAudit({
        userId: existingUser.id,
        userName: existingUser.name,
        userRole: existingUser.role,
        action: "GOOGLE_OAUTH_LOGIN_SUCCESS",
        ipAddress: "127.0.0.1",
        deviceInfo: navigator.userAgent || "Web Browser",
        status: "SUCCESS"
      });

      this.setCurrentSession(existingUser);
      return { success: true, user: existingUser };
    }

    // Register new unique user from Google profile
    const newUserId = `usr-g-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const newUser: UserAccount = {
      id: newUserId,
      name: profile.name || cleanEmail.split("@")[0],
      email: cleanEmail,
      mobile: "",
      role: "supporter",
      avatarUrl: profile.picture,
      createdAt: new Date().toISOString().split("T")[0],
      lastLogin: new Date().toISOString(),
      isVerified: true
    };
    (newUser as any).googleUid = profile.sub;

    users.push(newUser);
    this.saveUsers(users);

    this.logAudit({
      userId: newUser.id,
      userName: newUser.name,
      userRole: newUser.role,
      action: "GOOGLE_OAUTH_REGISTER_SUCCESS",
      ipAddress: "127.0.0.1",
      deviceInfo: navigator.userAgent || "Web Browser",
      status: "SUCCESS"
    });

    this.setCurrentSession(newUser);
    return { success: true, user: newUser };
  }


  /**
   * Super Admin Hidden Login with 2FA
   */
  public loginSuperAdmin(password: string, twoFactorCode: string): { success: boolean; user?: UserAccount; error?: string } {
    const users = this.getUsers();
    const superAdmin = users.find((u) => u.role === "super_admin");

    if (!superAdmin) {
      return { success: false, error: "Super Admin configuration error." };
    }

    if (superAdmin.passwordHash !== password.trim()) {
      this.logAudit({
        userId: superAdmin.id,
        userName: superAdmin.name,
        userRole: "super_admin",
        action: "SUPER_ADMIN_PASSWORD_FAILED",
        ipAddress: "127.0.0.1",
        deviceInfo: navigator.userAgent || "Web Browser",
        status: "BLOCKED"
      });
      return { success: false, error: "Invalid Super Admin credentials." };
    }

    // 2FA check (code is '123456' or '889900' for demo)
    if (twoFactorCode !== "123456" && twoFactorCode !== "889900") {
      this.logAudit({
        userId: superAdmin.id,
        userName: superAdmin.name,
        userRole: "super_admin",
        action: "SUPER_ADMIN_2FA_FAILED",
        ipAddress: "127.0.0.1",
        deviceInfo: navigator.userAgent || "Web Browser",
        status: "FAILED"
      });
      return { success: false, error: "Invalid 2FA Authenticator Code. Use 123456." };
    }

    superAdmin.lastLogin = new Date().toISOString();
    this.saveUsers(users);

    this.logAudit({
      userId: superAdmin.id,
      userName: superAdmin.name,
      userRole: "super_admin",
      action: "SUPER_ADMIN_2FA_LOGIN_SUCCESS",
      ipAddress: "127.0.0.1",
      deviceInfo: navigator.userAgent || "Web Browser",
      status: "SUCCESS"
    });

    this.setCurrentSession(superAdmin);
    return { success: true, user: superAdmin };
  }

  public getCurrentSession(): UserAccount | null {
    try {
      const stored = localStorage.getItem(CURRENT_SESSION_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  }

  public setCurrentSession(user: UserAccount | null) {
    if (!user) {
      localStorage.removeItem(CURRENT_SESSION_KEY);
    } else {
      localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(user));
    }
  }

  public logout() {
    const user = this.getCurrentSession();
    if (user) {
      this.logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: "LOGOUT",
        ipAddress: "127.0.0.1",
        deviceInfo: navigator.userAgent || "Web Browser",
        status: "SUCCESS"
      });
    }
    localStorage.removeItem(CURRENT_SESSION_KEY);
  }
}

export const authService = new AuthService();
